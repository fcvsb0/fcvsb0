package dev.fcvsb.store.storage;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StorePlugin;
import dev.fcvsb.store.coupon.Coupon;
import dev.fcvsb.store.coupon.CouponManager;
import dev.fcvsb.store.log.PurchaseLog;
import dev.fcvsb.store.log.PurchaseLogger;
import dev.fcvsb.store.wishlist.WishlistManager;
import dev.fcvsb.store.restock.RestockNotifier;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Flat-file persistence.
 *
 * plugins/Store/data/
 *   players/<uuid>.yml    coins + purchaseCounts
 *   coupons.json
 *   purchases.json
 */
public class DataStorage {

    private static File playersDir;
    private static File couponsFile;
    private static File logsFile;
    private static File wishlistFile;
    private static File restockFile;
    private static File giftsFile;
    private static File giftcardsFile;
    private static File dailyDealsFile;
    private static File subscriptionsFile;
    private static final Logger LOG = Logger.getLogger("Store");

    // ── Init ──────────────────────────────────────────────────────────────

    public static void init(StorePlugin plugin) {
        File dataDir  = new File(plugin.getDataFolder(), "data");
        playersDir    = new File(dataDir, "players");
        couponsFile   = new File(dataDir, "coupons.json");
        logsFile      = new File(dataDir, "purchases.json");
        wishlistFile  = new File(dataDir, "wishlists.json");
        restockFile   = new File(dataDir, "restock_subs.json");
        giftsFile     = new File(dataDir, "pending_gifts.json");
        giftcardsFile  = new File(dataDir, "giftcards.json");
        dailyDealsFile     = new File(dataDir, "daily_deals.json");
        subscriptionsFile  = new File(dataDir, "subscriptions.json");
        playersDir.mkdirs();
    }

    public static boolean isReady() { return playersDir != null; }

    // ── Load / Save all ───────────────────────────────────────────────────

    public static void loadAll() {
        loadCoupons();
        loadLogs();
        loadWishlists();
        loadRestockSubs();
        loadGifts();
        loadGiftCards();
        loadDailyDeals();
        loadSubscriptions();
    }

    public static void saveAll() {
        saveAllPlayers();
        saveCoupons();
        saveLogs();
        saveWishlists();
        saveRestockSubs();
        saveGifts();
        saveGiftCards();
        saveDailyDeals();
        saveSubscriptions();
    }

    // ── PlayerData (YAML — reliable, no custom parser) ────────────────────

    public static void savePlayer(UUID uuid, PlayerData data) {
        if (playersDir == null) {
            LOG.warning("[Store] savePlayer called but playersDir is null!");
            return;
        }
        playersDir.mkdirs();
        File f = new File(playersDir, uuid + ".yml");
        try {
            // Build file manually — YamlConfiguration interprets dots as nested paths
            // so we write raw YAML lines to preserve item IDs like "crates.trophy-key"
            StringBuilder sb = new StringBuilder();
            sb.append("coins: ").append(data.getCoins()).append("\n");
            String rankId = dev.fcvsb.store.rank.RankManager.getSavedRankId(uuid);
            if (rankId != null && !rankId.isEmpty())
                sb.append("rank: ").append(rankId).append("\n");
            sb.append("purchases:\n");
            Map<String, Integer> counts = data.getPurchaseCounts();
            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                // Wrap key in quotes to preserve dots literally
                sb.append("  \"").append(e.getKey().replace("\\", "\\\\").replace("\"", "\\\"")).append("\": ").append(e.getValue()).append("\n");
            }
            Files.write(f.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
            LOG.info("[Store] Saved player " + uuid + " — " + data.getCoins() + " coins, " + counts.size() + " purchase records");
        } catch (IOException e) {
            LOG.warning("[Store] Failed to save player " + uuid + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void loadPlayer(UUID uuid, PlayerData data) {
        if (playersDir == null) return;
        File f = new File(playersDir, uuid + ".yml");
        if (!f.exists()) return;
        try {
            // Parse manually to handle quoted keys with dots
            List<String> lines = Files.readAllLines(f.toPath(), StandardCharsets.UTF_8);
            boolean inPurchases = false;
            for (String line : lines) {
                if (line.startsWith("coins:")) {
                    String val = line.substring(6).trim();
                    try { data.setCoins(Integer.parseInt(val)); } catch (NumberFormatException ignored) {}
                    inPurchases = false;
                } else if (line.startsWith("rank:")) {
                    String rankId = line.substring(5).trim();
                    dev.fcvsb.store.rank.RankManager.loadPlayerRank(uuid, rankId);
                    inPurchases = false;
                } else if (line.startsWith("purchases:")) {
                    inPurchases = true;
                } else if (inPurchases && line.startsWith("  ")) {
                    String entry = line.trim();
                    // Format: "some.key": 3  OR  some-key: 3
                    int colon = entry.lastIndexOf(':');
                    if (colon < 0) continue;
                    String rawKey = entry.substring(0, colon).trim();
                    String rawVal = entry.substring(colon + 1).trim();
                    // Strip surrounding quotes from key
                    if (rawKey.startsWith("\"") && rawKey.endsWith("\""))
                        rawKey = rawKey.substring(1, rawKey.length() - 1).replace("\\", "\\").replace("\\\"", "\"");
                    int count = 0;
                    try { count = Integer.parseInt(rawVal); } catch (NumberFormatException ignored) {}
                    if (!rawKey.isEmpty() && count > 0)
                        data.incrementPurchaseCount(rawKey, count);
                }
            }
            LOG.info("[Store] Loaded player " + uuid + " — " + data.getCoins() + " coins");
        } catch (Exception e) {
            LOG.warning("[Store] Failed to load player " + uuid + ": " + e.getMessage());
        }
    }

    private static void saveAllPlayers() {
        for (Map.Entry<UUID, PlayerData> e : PlayerData.getAll().entrySet())
            savePlayer(e.getKey(), e.getValue());
    }

    // ── Coupons ───────────────────────────────────────────────────────────

    public static void saveCoupons() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            List<Coupon> list = new ArrayList<>(CouponManager.getAll());
            for (int i = 0; i < list.size(); i++) {
                Coupon c = list.get(i);
                sb.append("  {");
                sb.append("\"code\":").append(jq(c.getCode())).append(",");
                sb.append("\"discount\":").append(c.getDiscountPct()).append(",");
                sb.append("\"expireAt\":").append(c.getExpireAt()).append(",");
                sb.append("\"maxUses\":").append(c.getMaxUses()).append(",");
                sb.append("\"playerMaxUses\":").append(c.getPlayerMaxUses()).append(",");
                sb.append("\"usedBy\":{");
                List<java.util.Map.Entry<UUID,Integer>> used = new ArrayList<>(c.getUsedBy().entrySet());
                for (int j = 0; j < used.size(); j++) {
                    sb.append(jq(used.get(j).getKey().toString())).append(":").append(used.get(j).getValue());
                    if (j < used.size() - 1) sb.append(",");
                }
                sb.append("}}");
                if (i < list.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("]\n");
            write(couponsFile, sb.toString());
        } catch (Exception e) {
            LOG.warning("[Store] Failed to save coupons: " + e.getMessage());
        }
    }

    public static void loadCoupons() {
        if (!couponsFile.exists()) return;
        try {
            String json = read(couponsFile);
            for (String obj : objects(json)) {
                String code   = str(obj, "code");
                int discount  = num(obj, "discount");
                long expireAt = lng(obj, "expireAt");
                int maxUses   = num(obj, "maxUses");
                if (code == null || discount < 0) continue;
                int playerMaxUses = num(obj, "playerMaxUses");
                Coupon c = CouponManager.create(code, discount, expireAt, Math.max(0, maxUses), Math.max(0, playerMaxUses));
                // Load per-player use counts from usedBy object
                String usedByStr = strBlock(obj, "usedBy");
                if (usedByStr != null) {
                    for (String entry : usedByStr.replaceAll("[{} ]","").split(",")) {
                        if (entry.isEmpty()) continue;
                        String[] kv = entry.split(":");
                        if (kv.length != 2) continue;
                        try {
                            UUID uid = UUID.fromString(kv[0].replace("\"","").trim());
                            int cnt  = Integer.parseInt(kv[1].trim());
                            c.addUse(uid, cnt);
                        } catch (Exception ignored) {}
                    }
                }
            }
            LOG.info("[Store] Loaded " + CouponManager.getAll().size() + " coupon(s).");
        } catch (Exception e) {
            LOG.warning("[Store] Failed to load coupons: " + e.getMessage());
        }
    }

    // ── Purchase logs ─────────────────────────────────────────────────────

    public static void saveLogs() {
        try {
            List<PurchaseLog> logs = new ArrayList<>(PurchaseLogger.getGlobal());
            StringBuilder sb = new StringBuilder("[\n");
            for (int i = 0; i < logs.size(); i++) {
                PurchaseLog l = logs.get(i);
                sb.append("  {");
                sb.append("\"player\":").append(jq(l.getPlayerName())).append(",");
                sb.append("\"item\":").append(jq(l.getItemName())).append(",");
                sb.append("\"category\":").append(jq(l.getCategory())).append(",");
                sb.append("\"origPrice\":").append(l.getOriginalPrice()).append(",");
                sb.append("\"saleDisc\":").append(l.getSaleDiscount()).append(",");
                sb.append("\"coupon\":").append(l.getCouponCode() != null ? jq(l.getCouponCode()) : "null").append(",");
                sb.append("\"couponDisc\":").append(l.getCouponDiscount()).append(",");
                sb.append("\"finalPaid\":").append(l.getFinalPaid()).append(",");
                sb.append("\"giftRecip\":").append(l.getGiftRecipient() != null ? jq(l.getGiftRecipient()) : "null").append(",");
                sb.append("\"giftFee\":").append(l.getGiftFee()).append(",");
                sb.append("\"time\":").append(l.getTimestamp());
                sb.append("}");
                if (i < logs.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("]\n");
            write(logsFile, sb.toString());
        } catch (Exception e) {
            LOG.warning("[Store] Failed to save logs: " + e.getMessage());
        }
    }

    public static void loadLogs() {
        if (!logsFile.exists()) return;
        try {
            String json = read(logsFile);
            List<String> objs = objects(json);
            Collections.reverse(objs);
            for (String obj : objs) {
                String player  = str(obj, "player");
                String item    = str(obj, "item");
                String cat     = str(obj, "category");
                int origPrice  = num(obj, "origPrice");
                int saleDisc   = num(obj, "saleDisc");
                String coupon  = str(obj, "coupon");
                int couponDisc = num(obj, "couponDisc");
                int finalPaid  = num(obj, "finalPaid");
                String giftRec = str(obj, "giftRecip");
                int giftFee    = num(obj, "giftFee");
                long time      = lng(obj, "time");
                if (player == null || item == null) continue;
                PurchaseLogger.recordRaw(new PurchaseLog(
                        player, item, cat != null ? cat : "",
                        Math.max(0, origPrice), Math.max(0, saleDisc),
                        coupon, Math.max(0, couponDisc),
                        Math.max(0, finalPaid),
                        giftRec, Math.max(0, giftFee),
                        time > 0 ? time : System.currentTimeMillis()));
            }
            LOG.info("[Store] Loaded " + objs.size() + " log(s).");
        } catch (Exception e) {
            LOG.warning("[Store] Failed to load logs: " + e.getMessage());
        }
    }

    // ── Wishlists ─────────────────────────────────────────────────────────

    public static void saveWishlists() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            for (Map.Entry<UUID, Set<String>> e : WishlistManager.getAll().entrySet()) {
                if (e.getValue().isEmpty()) continue;
                sb.append("  {\"uuid\":").append(jq(e.getKey().toString())).append(",\"items\":[");
                List<String> items = new ArrayList<>(e.getValue());
                for (int i = 0; i < items.size(); i++) {
                    sb.append(jq(items.get(i)));
                    if (i < items.size() - 1) sb.append(",");
                }
                sb.append("]},\n");
            }
            sb.append("]\n");
            write(wishlistFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save wishlists: " + e.getMessage()); }
    }

    public static void loadWishlists() {
        if (!wishlistFile.exists()) return;
        try {
            String json = read(wishlistFile);
            for (String obj : objects(json)) {
                String uuidStr = str(obj, "uuid");
                if (uuidStr == null) continue;
                UUID uuid = tryUUID(uuidStr);
                if (uuid == null) continue;
                int as = obj.indexOf("\"items\":[");
                if (as < 0) continue;
                int ae = obj.indexOf(']', as);
                String arr = obj.substring(as + 9, ae).trim();
                if (arr.isEmpty()) continue;
                for (String part : arr.split(",")) {
                    String id = part.trim();
                    if (id.startsWith("\"") && id.endsWith("\"")) id = id.substring(1, id.length()-1);
                    if (!id.isEmpty()) WishlistManager.get(uuid).add(id);
                }
            }
        } catch (Exception e) { LOG.warning("[Store] Failed to load wishlists: " + e.getMessage()); }
    }

    // ── Restock subscriptions ─────────────────────────────────────────────

    public static void saveRestockSubs() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            for (Map.Entry<String, Set<UUID>> e : RestockNotifier.getAll().entrySet()) {
                if (e.getValue().isEmpty()) continue;
                sb.append("  {\"item\":").append(jq(e.getKey())).append(",\"subs\":[");
                List<UUID> subs = new ArrayList<>(e.getValue());
                for (int i = 0; i < subs.size(); i++) {
                    sb.append(jq(subs.get(i).toString()));
                    if (i < subs.size() - 1) sb.append(",");
                }
                sb.append("]},\n");
            }
            sb.append("]\n");
            write(restockFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save restock subs: " + e.getMessage()); }
    }

    public static void loadRestockSubs() {
        if (!restockFile.exists()) return;
        try {
            String json = read(restockFile);
            Map<String, Set<UUID>> data = new HashMap<>();
            for (String obj : objects(json)) {
                String itemId = str(obj, "item");
                if (itemId == null) continue;
                int as = obj.indexOf("\"subs\":[");
                if (as < 0) continue;
                int ae = obj.indexOf(']', as);
                String arr = obj.substring(as + 8, ae).trim();
                Set<UUID> uuids = new HashSet<>();
                if (!arr.isEmpty()) {
                    for (String part : arr.split(",")) {
                        String u = part.trim();
                        if (u.startsWith("\"") && u.endsWith("\"")) u = u.substring(1, u.length()-1);
                        UUID uuid = tryUUID(u);
                        if (uuid != null) uuids.add(uuid);
                    }
                }
                data.put(itemId, uuids);
            }
            RestockNotifier.loadAll(data);
        } catch (Exception e) { LOG.warning("[Store] Failed to load restock subs: " + e.getMessage()); }
    }

    // ── Daily Deals ───────────────────────────────────────────────────────

    public static void saveDailyDeals() {
        try {
            StringBuilder sb = new StringBuilder("{\n");
            sb.append("  \"resetAt\":").append(dev.fcvsb.store.daily.DailyDealManager.getResetAt()).append(",\n");
            sb.append("  \"paused\":").append(dev.fcvsb.store.daily.DailyDealManager.isPaused()).append(",\n");
            sb.append("  \"pausedAt\":").append(dev.fcvsb.store.daily.DailyDealManager.getPausedAt()).append(",\n");
            sb.append("  \"deals\":[\n");
            java.util.List<dev.fcvsb.store.daily.DailyDeal> list =
                    new java.util.ArrayList<>(dev.fcvsb.store.daily.DailyDealManager.getActive());
            for (int i = 0; i < list.size(); i++) {
                dev.fcvsb.store.daily.DailyDeal d = list.get(i);
                sb.append("    {")
                  .append("\"id\":").append(jq(d.getProductId())).append(",")
                  .append("\"orig\":").append(d.getOriginalPrice()).append(",")
                  .append("\"deal\":").append(d.getDealPrice()).append(",")
                  .append("\"pct\":").append(d.getDiscountPct())
                  .append("}");
                if (i < list.size()-1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  ]\n}\n");
            write(dailyDealsFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save daily deals: " + e.getMessage()); }
    }

    public static void loadDailyDeals() {
        if (!dailyDealsFile.exists()) return;
        try {
            String json = read(dailyDealsFile);
            long resetAt = lng(json, "resetAt");
            int as = json.indexOf("\"deals\":[");
            int ae = json.lastIndexOf(']');
            java.util.Map<String, dev.fcvsb.store.daily.DailyDeal> deals = new java.util.LinkedHashMap<>();
            if (as >= 0 && ae > as) {
                String arr = json.substring(as + 9, ae);
                for (String obj : objects(arr)) {
                    String id   = str(obj, "id");
                    int orig    = num(obj, "orig");
                    int deal    = num(obj, "deal");
                    int pct     = num(obj, "pct");
                    if (id != null)
                        deals.put(id, new dev.fcvsb.store.daily.DailyDeal(id, orig, deal, pct));
                }
            }
            boolean paused = json.contains("\"paused\":true");
            long pausedAt = lng(json, "pausedAt");
            dev.fcvsb.store.daily.DailyDealManager.loadState(deals, resetAt, paused, pausedAt);
        } catch (Exception e) { LOG.warning("[Store] Failed to load daily deals: " + e.getMessage()); }
    }

    // ── Subscriptions ─────────────────────────────────────────────────────

    public static void saveSubscriptions() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            java.util.List<dev.fcvsb.store.subscription.ActiveSubscription> list =
                    new java.util.ArrayList<>(dev.fcvsb.store.subscription.SubscriptionManager.getAll());
            for (int i = 0; i < list.size(); i++) {
                dev.fcvsb.store.subscription.ActiveSubscription s = list.get(i);
                sb.append("  {")
                  .append("\"id\":").append(jq(s.getId())).append(",")
                  .append("\"playerUUID\":").append(jq(s.getPlayerUUID().toString())).append(",")
                  .append("\"playerName\":").append(jq(s.getPlayerName())).append(",")
                  .append("\"productId\":").append(jq(s.getProductId())).append(",")
                  .append("\"productName\":").append(jq(s.getProductName())).append(",")
                  .append("\"startedAt\":").append(s.getStartedAt()).append(",")
                  .append("\"expiresAt\":").append(s.getExpiresAt()).append(",")
                  .append("\"warned24h\":").append(s.isWarned24h()).append(",")
                  .append("\"expired\":").append(s.isExpired())
                  .append("}");
                if (i < list.size()-1) sb.append(",");
                sb.append("\n");
            }
            sb.append("]\n");
            write(subscriptionsFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save subscriptions: " + e.getMessage()); }
    }

    public static void loadSubscriptions() {
        if (!subscriptionsFile.exists()) return;
        try {
            String json = read(subscriptionsFile);
            for (String obj : objects(json)) {
                String id         = str(obj, "id");
                String playerUUID = str(obj, "playerUUID");
                String playerName = str(obj, "playerName");
                String productId  = str(obj, "productId");
                String productName= str(obj, "productName");
                long   startedAt  = lng(obj, "startedAt");
                long   expiresAt  = lng(obj, "expiresAt");
                boolean warned    = obj.contains("\"warned24h\":true");
                boolean expired   = obj.contains("\"expired\":true");
                if (id != null && playerUUID != null)
                    dev.fcvsb.store.subscription.SubscriptionManager.loadRaw(
                            id, java.util.UUID.fromString(playerUUID), playerName,
                            productId, productName, startedAt, expiresAt, warned, expired);
            }
        } catch (Exception e) { LOG.warning("[Store] Failed to load subscriptions: " + e.getMessage()); }
    }

    // ── GiftCards ─────────────────────────────────────────────────────────

    public static void saveGiftCards() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            List<dev.fcvsb.store.giftcard.GiftCard> list =
                    new ArrayList<>(dev.fcvsb.store.giftcard.GiftCardManager.getAll());
            for (int i = 0; i < list.size(); i++) {
                dev.fcvsb.store.giftcard.GiftCard g = list.get(i);
                sb.append("  {");
                sb.append("\"id\":").append(jq(g.getId())).append(",");
                sb.append("\"createdBy\":").append(jq(g.getCreatedBy().toString())).append(",");
                sb.append("\"owner\":").append(g.getOwner() != null ? jq(g.getOwner().toString()) : "null").append(",");
                sb.append("\"reason\":").append(jq(g.getReason() != null ? g.getReason() : "")).append(",");
                sb.append("\"coins\":").append(g.getCoins()).append(",");
                sb.append("\"expireAt\":").append(g.getExpireAt()).append(",");
                sb.append("\"redeemedBy\":").append(g.getRedeemedBy() != null ? jq(g.getRedeemedBy().toString()) : "null");
                sb.append("}");
                if (i < list.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("]\n");
            write(giftcardsFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save giftcards: " + e.getMessage()); }
    }

    public static void loadGiftCards() {
        if (!giftcardsFile.exists()) return;
        try {
            String json = read(giftcardsFile);
            for (String obj : objects(json)) {
                String id        = str(obj, "id");
                String createdBy = str(obj, "createdBy");
                String owner     = str(obj, "owner");
                String reason    = str(obj, "reason");
                int    coins     = num(obj, "coins");
                long   expireAt  = lng(obj, "expireAt");
                String redeemed  = str(obj, "redeemedBy");
                if (id == null || createdBy == null || coins < 0) continue;
                try {
                    UUID staff     = UUID.fromString(createdBy);
                    UUID ownerUUID = owner != null ? tryUUID(owner) : null;
                    dev.fcvsb.store.giftcard.GiftCard gc =
                            dev.fcvsb.store.giftcard.GiftCardManager.createRaw(
                                    id, staff, ownerUUID, reason != null ? reason : "", coins, expireAt);
                    if (redeemed != null) {
                        try { gc.redeem(UUID.fromString(redeemed)); } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception e) { LOG.warning("[Store] Failed to load giftcards: " + e.getMessage()); }
    }

    // ── Pending Gifts ─────────────────────────────────────────────────────

    public static void saveGifts() {
        try {
            StringBuilder sb = new StringBuilder("[\n");
            boolean first = true;
            for (dev.fcvsb.store.gift.PendingGift g : dev.fcvsb.store.gift.PendingGiftManager.getAll().values()) {
                if (g.isClaimed()) continue;
                if (!first) sb.append(",\n");
                first = false;
                sb.append("  {")
                  .append("\"id\":").append(jq(g.getId())).append(",")
                  .append("\"senderUUID\":").append(jq(g.getSenderUUID().toString())).append(",")
                  .append("\"senderName\":").append(jq(g.getSenderName())).append(",")
                  .append("\"recipientUUID\":").append(jq(g.getRecipientUUID().toString())).append(",")
                  .append("\"recipientName\":").append(jq(g.getRecipientName())).append(",")
                  .append("\"itemId\":").append(jq(g.getItemId())).append(",")
                  .append("\"itemName\":").append(jq(g.getItemName())).append(",")
                  .append("\"message\":").append(g.getMessage() != null ? jq(g.getMessage()) : "null").append(",")
                  .append("\"createdAt\":").append(g.getCreatedAt()).append(",")
                  .append("\"approved\":").append(g.isApproved()).append(",")
                  .append("\"pricePaid\":").append(g.getRefundAmount())
                  .append("}");
            }
            sb.append("\n]\n");
            write(giftsFile, sb.toString());
        } catch (Exception e) { LOG.warning("[Store] Failed to save pending gifts: " + e.getMessage()); }
    }

    public static void loadGifts() {
        if (!giftsFile.exists()) return;
        try {
            String json = read(giftsFile);
            for (String obj : objects(json)) {
                String id            = str(obj, "id");
                String senderUUID    = str(obj, "senderUUID");
                String senderName    = str(obj, "senderName");
                String recipientUUID = str(obj, "recipientUUID");
                String recipientName = str(obj, "recipientName");
                String itemId        = str(obj, "itemId");
                String itemName      = str(obj, "itemName");
                String message       = str(obj, "message");
                long   createdAt     = lng(obj, "createdAt");
                if (id == null || senderUUID == null || recipientUUID == null) continue;
                UUID su = tryUUID(senderUUID);
                UUID ru = tryUUID(recipientUUID);
                if (su == null || ru == null) continue;
                dev.fcvsb.store.gift.PendingGift g = new dev.fcvsb.store.gift.PendingGift(
                        id, su, senderName, ru, recipientName,
                        itemId, itemName, message, createdAt);
                if (obj.contains("\"approved\":true")) g.setApproved();
                g.setPricePaid((int) lng(obj, "pricePaid"));
                dev.fcvsb.store.gift.PendingGiftManager.loadRaw(g);
            }
        } catch (Exception e) { LOG.warning("[Store] Failed to load pending gifts: " + e.getMessage()); }
    }

    // ── Tiny JSON helpers ─────────────────────────────────────────────────

    private static String jq(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /** Extracts a raw {...} object value for a given key */
    private static String strBlock(String json, String key) {
        String search = "\"" + key + "\":";
        int i = json.indexOf(search);
        if (i < 0) return null;
        int s = i + search.length();
        while (s < json.length() && json.charAt(s) == ' ') s++;
        if (s >= json.length() || json.charAt(s) != '{') return null;
        int depth = 0, e = s;
        while (e < json.length()) {
            if (json.charAt(e) == '{') depth++;
            else if (json.charAt(e) == '}') { depth--; if (depth == 0) { e++; break; } }
            e++;
        }
        return json.substring(s, e);
    }

    private static String str(String json, String key) {
        String search = "\"" + key + "\":";
        int i = json.indexOf(search);
        if (i < 0) return null;
        int s = i + search.length();
        while (s < json.length() && json.charAt(s) == ' ') s++;
        if (s >= json.length() || json.charAt(s) != '"') return null; // null or non-string
        int e = s + 1;
        while (e < json.length() && !(json.charAt(e) == '"' && json.charAt(e-1) != '\\')) e++;
        return json.substring(s + 1, e);
    }

    private static int num(String json, String key) {
        String search = "\"" + key + "\":";
        int i = json.indexOf(search);
        if (i < 0) return -1;
        int s = i + search.length();
        while (s < json.length() && json.charAt(s) == ' ') s++;
        int e = s;
        while (e < json.length() && (Character.isDigit(json.charAt(e)) || json.charAt(e) == '-')) e++;
        try { return Integer.parseInt(json.substring(s, e)); } catch (Exception ex) { return -1; }
    }

    private static long lng(String json, String key) {
        String search = "\"" + key + "\":";
        int i = json.indexOf(search);
        if (i < 0) return 0;
        int s = i + search.length();
        while (s < json.length() && json.charAt(s) == ' ') s++;
        int e = s;
        while (e < json.length() && (Character.isDigit(json.charAt(e)) || json.charAt(e) == '-')) e++;
        try { return Long.parseLong(json.substring(s, e)); } catch (Exception ex) { return 0; }
    }

    private static List<String> array(String json, String key) {
        List<String> result = new ArrayList<>();
        String search = "\"" + key + "\":[";
        int start = json.indexOf(search);
        if (start < 0) return result;
        int s = start + search.length();
        int e = json.indexOf(']', s);
        if (e < 0) return result;
        String inner = json.substring(s, e).trim();
        if (inner.isEmpty()) return result;
        for (String part : inner.split(",")) {
            String v = part.trim();
            if (v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length()-1);
            if (!v.isEmpty()) result.add(v);
        }
        return result;
    }

    private static List<String> objects(String json) {
        List<String> result = new ArrayList<>();
        int depth = 0, start = -1;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '{') { if (depth++ == 0) start = i; }
            else if (c == '}') { if (--depth == 0 && start >= 0) { result.add(json.substring(start, i+1)); start = -1; } }
        }
        return result;
    }

    private static String read(File f) throws IOException {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    private static void write(File f, String content) throws IOException {
        Files.write(f.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    private static UUID tryUUID(String s) {
        try { return UUID.fromString(s); } catch (Exception e) { return null; }
    }
}
