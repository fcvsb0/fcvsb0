package dev.fcvsb.store.command;

import dev.fcvsb.store.sale.SaleManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SaleCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("store.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("cancel")) {
            if (!SaleManager.isActive()) {
                sender.sendMessage(ChatColor.RED + "There is no active sale.");
                return true;
            }
            SaleManager.cancel();
            sender.sendMessage(ChatColor.GREEN + "Sale cancelled.");
            Bukkit.broadcastMessage(ChatColor.GOLD + "[Sale] " + ChatColor.RED + "The sale has ended!");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /sale <time> <percentage>");
            sender.sendMessage(ChatColor.GRAY  + "Example: /sale 1d2h30m 20");
            sender.sendMessage(ChatColor.YELLOW + "         /sale cancel");
            return true;
        }

        long duration = SaleManager.parseDuration(args[0]);
        if (duration < 0) {
            sender.sendMessage(ChatColor.RED + "Invalid time format. Use: 1d, 2h, 30m, 10s");
            return true;
        }

        int pct;
        try {
            pct = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Invalid percentage.");
            return true;
        }

        if (pct < 1 || pct > 99) {
            sender.sendMessage(ChatColor.RED + "Percentage must be between 1 and 99.");
            return true;
        }

        SaleManager.start(duration, pct);

        String msg = ChatColor.GOLD + "[Sale] " + ChatColor.GREEN + "Sale of "
                + ChatColor.YELLOW + pct + "%" + ChatColor.GREEN + " started for "
                + ChatColor.WHITE + SaleManager.formatDuration(duration)
                + ChatColor.GREEN + "! Use " + ChatColor.YELLOW + "/coinshop" + ChatColor.GREEN + " to see the prices!";

        Bukkit.broadcastMessage(msg);
        sender.sendMessage(ChatColor.GREEN + "Sale started: " + pct + "% for " + SaleManager.formatDuration(duration));
        return true;
    }
}
