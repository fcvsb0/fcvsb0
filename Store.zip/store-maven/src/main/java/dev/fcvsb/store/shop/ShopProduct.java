package dev.fcvsb.store.shop;

import dev.fcvsb.store.Lang;
import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.StoreItem;
import dev.fcvsb.store.sale.SaleManager;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ShopProduct implements StoreItem {

    private final String       id;
    private final String       categoryId;
    private final int          slot;
    private final String       name;
    private final Material     material;
    private final short        materialData;
    private final boolean      enchanted;
    private final List<String> lore;
    private       int          price;
    private final boolean      oneTime;
    private final int          maxStack;    // lifetime purchase limit per player (0 = unlimited)
    private final int          cartLimit;   // max qty per cart transaction (0 = unlimited)
    private       int          stock;       // server-wide stock (-1 = disabled)
    private final List<String> commands;
    private final boolean      broadcast;
    private final String       broadcastMsg;
    private final boolean      giftable;
    private final int          giftFeeOverride;
    private final boolean      wishlistAdd;
    private final boolean      dailyDealEligible;
    // Subscription
    private final String       requiredRank;     // rank id required to purchase ("" = none)
    private final boolean      isRank;           // is this product a rank upgrade?
    private final String       rankNext;         // id of next rank product ("" = top rank)
    private final boolean      subscription;     // is this a membership product?
    private final long         subDurationMs;    // duration in ms (0 if not subscription)
    private final List<String> subExpireCommands;// commands on expiry

    public ShopProduct(String id, String categoryId, int slot, String name,
                       Material material, short materialData, boolean enchanted,
                       List<String> lore, int price, boolean oneTime, int maxStack,
                       int cartLimit, int stock,
                       List<String> commands, boolean broadcast, String broadcastMsg,
                       boolean giftable, int giftFeeOverride, boolean wishlistAdd, boolean dailyDealEligible,
                       boolean subscription, long subDurationMs, List<String> subExpireCommands,
                       String requiredRank, boolean isRank, String rankNext) {
        this.id              = id;
        this.categoryId      = categoryId;
        this.slot            = slot;
        this.name            = name;
        this.material        = material;
        this.materialData    = materialData;
        this.enchanted       = enchanted;
        this.lore            = lore;
        this.price           = price;
        this.oneTime         = oneTime;
        this.maxStack        = maxStack;
        this.cartLimit       = cartLimit;
        this.stock           = stock;
        this.commands        = commands;
        this.broadcast       = broadcast;
        this.broadcastMsg    = broadcastMsg;
        this.giftable        = giftable;
        this.wishlistAdd       = wishlistAdd;
        this.dailyDealEligible  = dailyDealEligible;
        this.subscription       = subscription;
        this.subDurationMs      = subDurationMs;
        this.subExpireCommands  = subExpireCommands != null ? subExpireCommands : new java.util.ArrayList<>();
        this.giftFeeOverride  = giftFeeOverride;
        this.requiredRank     = requiredRank != null ? requiredRank : "";
        this.isRank           = isRank;
        this.rankNext         = rankNext != null ? rankNext : "";
    }

    // ── Accessors ─────────────────────────────────────────────────────────
    public int          getSlot()       { return slot; }
    public String       getCategoryId() { return categoryId; }
    public List<String> getCommands()   { return commands; }
    public void         setPrice(int p) { this.price = p; }
    public void         setStock(int s) { this.stock = s; }

    // ── StoreItem ─────────────────────────────────────────────────────────
    @Override public String  getId()          { return id; }
    @Override public String  getDisplayName() { return ChatColor.translateAlternateColorCodes('&', name); }
    @Override public String  getCategory()    { return "Shop/" + categoryId; }
    @Override public boolean isPurchasableOneTime()   { return oneTime; }
    @Override public int     getPurchasableMaxStack() { return maxStack; }
    @Override public int     getCartLimit()           { return cartLimit; }
    @Override public int     getStock()               { return stock; }
    @Override
    public String  getRequiredRank()        { return requiredRank; }
    public boolean           isRankProduct()          { return isRank; }
    public String            getRankNext()            { return rankNext; }
    @Override public int     getPrice(Player player)  { return price; }
    @Override public boolean isGiftable()             { return giftable; }
    public boolean isWishlistAdd()                    { return wishlistAdd; }
    public boolean isDailyDealEligible()             { return dailyDealEligible; }
    public boolean   isSubscription()         { return subscription; }
    public long      getSubDurationMs()       { return subDurationMs; }
    public List<String> getSubExpireCommands() { return subExpireCommands; }
    public Material  getMaterial()     { return material; }
    public short     getMaterialData() { return materialData; }
    public boolean   isEnchanted()     { return enchanted; }
    @Override public int     getGiftFeePercent()      { return giftFeeOverride; }

    @Override
    public int getDiscount(Player player) { return SaleManager.applyDiscount(price); }

    @Override
    public boolean playerOwns(Player player) {
        if (!oneTime) return false;
        return PlayerData.get(player.getUniqueId()).getPurchaseCount(id) > 0;
    }

    @Override
    public void grant(Player player) {
        // Decrease stock
        if (stock > 0) stock--;
        for (String cmd : commands) {
            org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(),
                    cmd.replace("<player>", player.getName()));
        }
        player.sendMessage(ChatColor.GREEN + "You received " + getDisplayName() + ChatColor.GREEN + "!");
    }

    @Override
    public String getBroadcastMessage(Player player, int amount) {
        if (!broadcast) return null;
        if (broadcastMsg != null && !broadcastMsg.isEmpty()) {
            return ChatColor.translateAlternateColorCodes('&', broadcastMsg
                    .replace("<player>", player.getName())
                    .replace("<item>",   cleanDisplayName(name))
                    .replace("<amount>", String.valueOf(amount))
                    .replace("<price>",  String.valueOf(price)));
        }
        return Lang.get("broadcast_purchase",
                "%player%", player.getName(),
                "%item%",   cleanDisplayName(name),
                "%amount%", String.valueOf(amount),
                "%price%",  String.valueOf(price));
    }

    @Override
    public ItemStack getDisplayItem(Player player, StoreCart cart) {
        boolean blocked  = player != null && !canPurchase(player, 1);
        int     discount = player != null ? getDiscount(player) : 0;
        int     net      = price - discount;
        int     pct      = SaleManager.getPercentage();
        boolean showGift = giftable && StoreConfig.isGiftFeeEnabled();
        int     giftFee  = giftFeeOverride >= 0 ? giftFeeOverride : StoreConfig.getGlobalGiftFee();
        int     inCart   = cart != null ? cart.getItems().getOrDefault(this, 0) : 0;

        List<String> builtLore = new ArrayList<>();
        for (String line : lore) {
            String resolved = line
                .replace("<currency-price>", String.valueOf(net))
                .replace("<price>",          String.valueOf(net))
                .replace("<base-price>",     String.valueOf(price))
                .replace("<original-price>", String.valueOf(price))
                .replace("<discount>",       String.valueOf(discount))
                .replace("<discount-pct>",   String.valueOf(pct))
                .replace("<sale-pct>",       String.valueOf(pct))
                .replace("<currency-name>",  "coins")
                .replace("<currency>",       "coins");
            builtLore.add(ChatColor.translateAlternateColorCodes('&', resolved));
        }

        // Stock — only shown when stock system is active (stock >= 0)
        if (stock >= 0) {
            builtLore.add("\u00a78\u25b8 Stock: " + (stock == 0 ? "\u00a7cOut of stock" : "\u00a7a" + stock));
        }

        // Required rank badge
        if (requiredRank != null && !requiredRank.isEmpty()) {
            dev.fcvsb.store.shop.ShopProduct rr = dev.fcvsb.store.rank.RankManager.getById(requiredRank);
            String rankDisplay = rr != null ? ChatColor.translateAlternateColorCodes('&', rr.getDisplayName()) : requiredRank;
            boolean hasRank = player == null || dev.fcvsb.store.rank.RankManager.hasRank(player.getUniqueId(), requiredRank);
            builtLore.add(" ");
            builtLore.add((hasRank ? "\u00a7a\u2714 Requires rank: " : "\u00a7c\u274c Requires rank: ") + rankDisplay);
        }

        if (blocked) {
            // Only show generic reason if not already shown via requiredRank badge
            String reason = getPurchaseBlockedReason(player, 1);
            if (reason != null && (requiredRank == null || requiredRank.isEmpty())) {
                builtLore.add(" ");
                builtLore.add(reason);
            }
        }

        if (showGift && !blocked) {
            builtLore.add(" ");
            builtLore.add("\u00a7d\u25b8 Giftable \u00a78(+" + giftFee + "% gift fee)");
        }

        // Subscription badge
        if (subscription) {
            builtLore.add(" ");
            if (!dev.fcvsb.store.StoreConfig.isSubscriptionsEnabled()) {
                builtLore.add("\u00a7c\u00bb Memberships are currently disabled.");
            } else {
                builtLore.add("\u00a76\u00bb \u00a7eMembership \u00a77\u2014 lasts \u00a7f" + dev.fcvsb.store.sale.SaleManager.formatDuration(subDurationMs));
                if (player != null && dev.fcvsb.store.subscription.SubscriptionManager.hasActiveSub(player.getUniqueId(), id)) {
                    java.util.List<dev.fcvsb.store.subscription.ActiveSubscription> subs =
                            dev.fcvsb.store.subscription.SubscriptionManager.getForPlayer(player.getUniqueId());
                    for (dev.fcvsb.store.subscription.ActiveSubscription s : subs) {
                        if (s.getProductId().equals(id)) {
                            builtLore.add("\u00a7a\u2714 Active \u00a77\u2014 expires in \u00a7f" + s.formatTimeLeft());
                        }
                    }
                }
            }
        }

        builtLore.add(" ");
        if (cart != null) {
            builtLore.add(cart.contains(this)
                    ? "\u00a7cClick to remove from cart"
                    : "\u00a7eClick to add to cart");
        }

        // Stack size reflects quantity in cart.
        // Minecraft caps stacks at 64, so for qty > 64 we show x<qty> in the name.
        int displayAmt = inCart > 0 ? Math.min(inCart, 64) : 1;

        String displayName;
        if (blocked) {
            displayName = "\u00a7c\u00a7m" + cleanDisplayName(name);
        } else {
            displayName = ChatColor.translateAlternateColorCodes('&', name);
            if (inCart > 64) {
                // Append quantity badge when it exceeds the Minecraft stack limit
                displayName += " \u00a78(\u00a7ex" + inCart + "\u00a78)";
            }
        }

        return ItemBuilder.of(blocked ? Material.REDSTONE_BLOCK : material, materialData)
                .name(displayName)
                .loreRaw(builtLore)
                .amount(displayAmt)
                .build();
    }

    /** Strips §k obfuscated sections then strips all color. */
    public static String cleanDisplayName(String raw) {
        String t = ChatColor.translateAlternateColorCodes('&', raw);
        t = t.replaceAll("\u00a7k[^\u00a7]*", "");
        return ChatColor.stripColor(t).trim();
    }

    @Override public boolean equals(Object o) { return o instanceof ShopProduct && Objects.equals(id, ((ShopProduct) o).id); }
    @Override public int     hashCode()       { return Objects.hash(id); }
}
