package dev.fcvsb.store.shop;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Subcategoría dentro de una ShopCategory.
 *
 * YAML dentro del archivo de la categoría:
 *
 *   subcategories:
 *     simbolos:
 *       slot: 20          # slot dentro del menú de la categoría padre
 *       name: "&e&lSímbolos"
 *       material: NETHER_STAR
 *       material-data: 0
 *       lore:
 *         - "&7Prefixes de símbolos"
 *         - "&eClick para ver"
 *       products:
 *         star:
 *           slot: 13
 *           name: "&e★"
 *           ...
 */
public class ShopSubCategory {

    private final String       id;
    private final String       parentId;
    private final int          slot;
    private final String       name;
    private final Material     material;
    private final short        materialData;
    private final List<String> lore;

    private final Map<Integer, ShopProduct> products = new LinkedHashMap<>();

    public ShopSubCategory(String id, String parentId, int slot, String name,
                           Material material, short materialData, List<String> lore) {
        this.id           = id;
        this.parentId     = parentId;
        this.slot         = slot;
        this.name         = name;
        this.material     = material;
        this.materialData = materialData;
        this.lore         = lore;
    }

    public void addProduct(ShopProduct p) { products.put(p.getSlot(), p); }

    public String              getId()          { return id; }
    public String              getParentId()    { return parentId; }
    public int                 getSlot()        { return slot; }
    public String              getName()        { return name; }
    public Material            getMaterial()    { return material; }
    public short               getMaterialData(){ return materialData; }
    public List<String>        getLore()        { return lore; }
    public Map<Integer, ShopProduct> getProducts() { return products; }
    public List<ShopProduct>   getProductList() { return new ArrayList<>(products.values()); }
}
