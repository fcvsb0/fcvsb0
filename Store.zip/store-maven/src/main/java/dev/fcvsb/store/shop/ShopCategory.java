package dev.fcvsb.store.shop;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ShopCategory {

    private final String       id;
    private final int          slot;
    private final String       name;
    private final Material     material;
    private final short        materialData;
    private final List<String> lore;

    // Productos directos (sin subcategoría)
    private final Map<Integer, ShopProduct>    products      = new LinkedHashMap<>();
    // Subcategorías: slot → subcategoría
    private final Map<Integer, ShopSubCategory> subCategories = new LinkedHashMap<>();

    public ShopCategory(String id, int slot, String name,
                        Material material, short materialData, List<String> lore) {
        this.id           = id;
        this.slot         = slot;
        this.name         = name;
        this.material     = material;
        this.materialData = materialData;
        this.lore         = lore;
    }

    public void addProduct(ShopProduct p)          { products.put(p.getSlot(), p); }
    public void addSubCategory(ShopSubCategory sub) { subCategories.put(sub.getSlot(), sub); }

    public String              getId()             { return id; }
    public int                 getSlot()           { return slot; }
    public String              getName()           { return name; }
    public Material            getMaterial()       { return material; }
    public short               getMaterialData()   { return materialData; }
    public List<String>        getLore()           { return lore; }
    public Map<Integer, ShopProduct>     getProducts()      { return products; }
    public Map<Integer, ShopSubCategory> getSubCategories() { return subCategories; }
    public List<ShopProduct>   getProductList()    { return new ArrayList<>(products.values()); }
    public boolean             hasSubCategories()  { return !subCategories.isEmpty(); }
}
