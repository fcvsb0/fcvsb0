package dev.fcvsb.store.menu;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import java.util.Arrays;
import java.util.ArrayList;
import dev.fcvsb.store.sale.SaleManager;
import dev.fcvsb.store.coupon.Coupon;
import dev.fcvsb.store.coupon.CouponManager;
import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 27 slots (3 rows):
 *
 *  0  1  2  3  4  5  6  7  8
 *  9 10 11 [12] 13 [14] 15 16 17
 * 18 19 20 21 [22] 23 24 25 26
 *
 * Slot 12 → Accept
 * Slot 14 → Cancel
 * Slot 22 → Coupon
 */
public class ConfirmMenu extends Menu {

    private static final int SLOT_ACCEPT = 12;
    private static final int SLOT_CANCEL = 14;
    private static final int SLOT_COUPON  = 22;
    private static final int SLOT_MESSAGE = 10; // gift message slot (only in gift mode)

    private final StoreCart cart;
    private final Menu      back;

    public ConfirmMenu(StoreCart cart, Menu back) {
        this.cart = cart;
        this.back = back;
    }

    @Override
    public String title(Player p) {
        return cart.hasGiftTarget()
                ? "\u00a76\u00a7lConfirm Gift?"
                : "\u00a76\u00a7lConfirm Purchase?";
    }

    @Override public int size(Player p) { return 27; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get27());
        Borders.fill(b, 27);

        int total     = cart.getFinalTotal(p);
        int coins     = PlayerData.get(p.getUniqueId()).getCoins();
        int savings   = cart.getCouponSavings(p);
        int giftFee   = cart.getGiftFeeTotal(p);
        boolean canAfford = coins >= total;

        // Slot 12 — Accept
        if (canAfford) {
            List<String> lore = new ArrayList<>();
            if (savings > 0)  lore.add("&7Coupon: &a-" + savings + " coins");
            if (giftFee > 0)  lore.add("&7Gift fee: &6+" + giftFee + " coins");
            lore.add("&7Total: &f" + total + " coins");
            lore.add("&7Remaining: &f" + (coins - total) + " coins");
            lore.add(" ");
            lore.add("&aClick to confirm!");
            if (cart.hasGiftTarget()) lore.add("&d\u25b8 Gifting to: &f" + cart.getGiftTargetName());
            b.put(SLOT_ACCEPT, ItemBuilder.of(Material.WOOL, (short) 5)
                    .name("&a&l\u2714 Accept Purchase")
                    .lore(lore).build());
        } else {
            b.put(SLOT_ACCEPT, ItemBuilder.of(Material.WOOL, (short) 8)
                    .name("&7\u2718 Cannot Purchase")
                    .lore("&cNot enough coins.",
                          "&7Need: &f" + total + " | Have: &f" + coins).build());
        }

        // Slot 14 — Cancel
        b.put(SLOT_CANCEL, ItemBuilder.of(Material.WOOL, (short) 14)
                .name("&c&l\u2718 Cancel")
                .lore("&7Go back to your cart.").build());

        // Slot 22 — Coupon
        b.put(SLOT_COUPON, buildCouponButton(p));

        // Gift message slot — only shown in gift mode
        if (cart.hasGiftTarget()) {
            String msg = cart.getGiftMessage();
            b.put(SLOT_MESSAGE, ItemBuilder.of(Material.BOOK)
                    .name("§d♥ Gift Message")
                    .lore(msg != null && !msg.isEmpty()
                            ? Arrays.asList("§f" + msg, " ", "§7Click to change")
                            : Arrays.asList("§7No message set.", "§7Click to add one."))
                    .build());
        }

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        if (slot == SLOT_ACCEPT) {
            int total = cart.getFinalTotal(p);
            int coins = PlayerData.get(p.getUniqueId()).getCoins();
            if (coins < total) {
                p.sendMessage(ChatColor.RED + "You don't have enough coins!");
                return;
            }
            CartHelper.processPurchase(p, cart);
            p.closeInventory();

        } else if (slot == SLOT_CANCEL) {
            back.open(p);

        } else if (slot == SLOT_MESSAGE && cart.hasGiftTarget()) {
            handleMessageClick(p);
        } else if (slot == SLOT_COUPON) {
            handleCouponClick(p);
        }
    }

    // ── Gift Message ──────────────────────────────────────────────────────

    private void handleMessageClick(Player p) {
        EditorSession.start(p, "Type your gift message (or 'clear' to remove):", null, input -> {
            if (input.equalsIgnoreCase("clear")) {
                cart.setGiftMessage(null);
                p.sendMessage("§7Gift message cleared.");
            } else {
                cart.setGiftMessage(input);
                p.sendMessage("§aGift message set: §f" + input);
            }
            new ConfirmMenu(cart, back).open(p);
        });
    }

    // ── Coupon ────────────────────────────────────────────────────────────

    private void handleCouponClick(Player p) {
        if (StoreConfig.isCouponBlockedDuringSale() && SaleManager.isActive()) {
            p.sendMessage("§cCoupons cannot be used while a sale is active.");
            return;
        }
        Coupon applied = CouponManager.getApplied(p.getUniqueId());
        if (applied != null) {
            CouponManager.clearApplied(p.getUniqueId());
            p.sendMessage(ChatColor.YELLOW + "Coupon " + ChatColor.WHITE + applied.getCode()
                    + ChatColor.YELLOW + " removed.");
            open(p);
            return;
        }
        EditorSession.start(p, "Enter coupon code", this, input -> {
            Coupon c = CouponManager.get(input.trim());
            if (c == null)
                p.sendMessage(ChatColor.RED + "Invalid coupon code: " + input.trim().toUpperCase());
            else if (!c.isValid())
                p.sendMessage(ChatColor.RED + "That coupon has expired or reached its usage limit.");
            else if (!c.canUse(p.getUniqueId())) {
                int max = c.getPlayerMaxUses();
                p.sendMessage(ChatColor.RED + "You have reached the max uses (" + max + ") for this coupon.");
            } else {
                CouponManager.apply(p.getUniqueId(), c);
                p.sendMessage(ChatColor.GREEN + "Coupon " + ChatColor.WHITE + c.getCode()
                        + ChatColor.GREEN + " applied! (" + c.getDiscountPct() + "% off)");
            }
            open(p);
        });
    }

    private ItemStack buildCouponButton(Player p) {
        // Show blocked state if sale is active and config blocks coupons during sale
        if (StoreConfig.isCouponBlockedDuringSale() && SaleManager.isActive()) {
            // Also clear any applied coupon silently
            CouponManager.clearApplied(p.getUniqueId());
            return ItemBuilder.of(Material.BARRIER)
                    .name("&c&lCoupons Disabled")
                    .lore("&7Coupons cannot be used",
                          "&7while a sale is active.").build();
        }
        Coupon applied = CouponManager.getApplied(p.getUniqueId());
        if (applied != null) {
            int savings = cart.getCouponSavings(p);
            return ItemBuilder.of(Material.NAME_TAG)
                    .name("&a&lCoupon Applied!")
                    .lore("&7Code: &f" + applied.getCode(),
                          "&7Discount: &a" + applied.getDiscountPct() + "% off",
                          "&7You save: &a" + savings + " coins",
                          " ",
                          "&eClick &7to remove").build();
        }
        return ItemBuilder.of(Material.NAME_TAG)
                .name("&e&lApply Coupon?")
                .lore("&7Have a coupon code? Click here!",
                      " ",
                      "&8Discount applied to your total.").build();
    }
}
