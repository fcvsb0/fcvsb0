package dev.fcvsb.store.coupon;

import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** /coupon manage — shows all coupons. Click to delete. */
public class CouponManageMenu extends Menu {

    private static final int PAGE_SIZE = 28;
    private static final int[] SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34
    };

    private int page = 0;
    private final Map<Integer, Coupon> slotMap = new HashMap<>();

    @Override public String title(Player p) { return "\u00a78[\u00a7bCoupons\u00a78] \u00a7fManage All Coupons"; }
    @Override public int    size (Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        slotMap.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 54);

        List<Coupon> all = new ArrayList<>(CouponManager.getAll());
        int total = (int) Math.ceil(Math.max(1, all.size()) / (double) PAGE_SIZE);
        int start = page * PAGE_SIZE;

        if (all.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.BARRIER).name("&cNo Coupons")
                    .lore("&7No coupons have been created yet.").build());
        } else {
            for (int i = 0; i < SLOTS.length && (start + i) < all.size(); i++) {
                Coupon c = all.get(start + i);
                b.put(SLOTS[i], buildCoupon(c));
                slotMap.put(SLOTS[i], c);
            }
        }

        // Add new coupon shortcut
        b.put(4, ItemBuilder.of(Material.WOOL, (short) 5)
                .name("&a&l+ New Coupon")
                .lore("&7Click to create a new coupon.").build());

        b.put(49, ItemBuilder.of(Material.PAPER)
                .name("&7Page &f" + (page+1) + " &7of &f" + total)
                .lore("&7Total: &f" + all.size() + " coupons").build());
        if (page > 0)       b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total-1) b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        if (slot == 4) { new CouponCreateMenu().open(p); return; }
        if (slot == 45 && page > 0) { page--; open(p); return; }
        if (slot == 53) { page++; open(p); return; }

        Coupon c = slotMap.get(slot);
        if (c != null) new CouponDeleteMenu(c, this).open(p);
    }

    private ItemStack buildCoupon(Coupon c) {
        Material mat  = !c.isValid() ? Material.BARRIER : Material.NAME_TAG;
        String status = c.isExpired() ? "&c[Expired]" : c.isExhausted() ? "&7[Exhausted]" : "&a[Active]";
        java.util.List<String> lore = new java.util.ArrayList<>();
        lore.add("&7Discount: &f" + c.getDiscountPct() + "%");
        lore.add("&7Total uses: &f" + c.getUseCount() + "/" + (c.getMaxUses() == 0 ? "\u221e" : c.getMaxUses()));
        lore.add("&7Per-player max: &f" + (c.getPlayerMaxUses() == 0 ? "\u221e" : c.getPlayerMaxUses()));
        lore.add("&7Expiry: &f" + c.formatExpiry());
        if (!c.getUsedBy().isEmpty()) {
            lore.add(" ");
            lore.add("&7Used by:");
            int shown = 0;
            for (java.util.UUID uid : c.getUsedBy().keySet()) {
                if (shown >= 8) { lore.add("&8  ...and " + (c.getUsedBy().size() - shown) + " more"); break; }
                String name = Bukkit.getOfflinePlayer(uid).getName();
                int cnt = c.getPlayerUseCount(uid);
                lore.add("&8  \u25b8 &f" + (name != null ? name : uid.toString().substring(0, 8))
                        + " &8x" + cnt);
                shown++;
            }
        }
        lore.add(" ");
        lore.add("&cLeft-click to delete");
        return ItemBuilder.of(mat).name("&b" + c.getCode() + " " + status).lore(lore).build();
    }
}
