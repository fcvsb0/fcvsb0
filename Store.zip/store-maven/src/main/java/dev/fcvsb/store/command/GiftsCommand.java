package dev.fcvsb.store.command;

import dev.fcvsb.store.gift.MyGiftsMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class GiftsCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("\u00a7cPlayers only."); return true; }
        Player p = (Player) sender;

        if (args.length >= 1) {
            if (!p.hasPermission("store.admin")) {
                p.sendMessage(ChatColor.RED + "No permission to view other players' gifts.");
                return true;
            }
            String targetName = args[0];
            Player online = Bukkit.getPlayerExact(targetName);
            UUID   targetUUID;
            String resolvedName;
            if (online != null) {
                targetUUID   = online.getUniqueId();
                resolvedName = online.getName();
            } else {
                @SuppressWarnings("deprecation")
                OfflinePlayer off = Bukkit.getOfflinePlayer(targetName);
                targetUUID   = off.getUniqueId();
                resolvedName = off.getName() != null ? off.getName() : targetName;
            }
            new MyGiftsMenu(targetUUID, resolvedName).open(p);
            return true;
        }

        new MyGiftsMenu().open(p);
        return true;
    }
}
