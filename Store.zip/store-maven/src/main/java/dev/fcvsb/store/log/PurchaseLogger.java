package dev.fcvsb.store.log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * In-memory log of all purchases.
 * Keyed by UUID for per-player lookup, also keeps a global list.
 */
public class PurchaseLogger {

    // Global log (all purchases, newest first)
    private static final List<PurchaseLog> GLOBAL = new ArrayList<>();

    // Per-player log keyed by UUID
    private static final Map<UUID, List<PurchaseLog>> BY_PLAYER = new LinkedHashMap<>();

    public static void record(UUID uuid, PurchaseLog log) {
        GLOBAL.add(0, log);
        BY_PLAYER.computeIfAbsent(uuid, k -> new ArrayList<>()).add(0, log);
    }

    /** Used by DataStorage to restore logs without a UUID index (global list only). */
    public static void recordRaw(PurchaseLog log) {
        GLOBAL.add(log);
    }

    /** All logs for one player (newest first), empty list if none. */
    public static List<PurchaseLog> getForPlayer(UUID uuid) {
        return BY_PLAYER.getOrDefault(uuid, Collections.emptyList());
    }

    /** Global log, newest first. */
    public static List<PurchaseLog> getGlobal() {
        return Collections.unmodifiableList(GLOBAL);
    }

    /** How many purchases a player has made. */
    public static int countFor(UUID uuid) {
        return BY_PLAYER.getOrDefault(uuid, Collections.emptyList()).size();
    }

    /** Total coins actually spent by a player (after all discounts). */
    public static int totalSpentBy(UUID uuid) {
        return BY_PLAYER.getOrDefault(uuid, Collections.emptyList())
                .stream().mapToInt(PurchaseLog::getFinalPaid).sum();
    }

    /** Total coins saved by a player through sales and coupons. */
    public static int totalSavedBy(UUID uuid) {
        return BY_PLAYER.getOrDefault(uuid, Collections.emptyList())
                .stream().mapToInt(PurchaseLog::getTotalSavings).sum();
    }

    /** Total coins earned globally across all purchases. */
    public static int totalRevenue() {
        return GLOBAL.stream().mapToInt(PurchaseLog::getFinalPaid).sum();
    }

    /** Total number of purchases globally. */
    public static int totalPurchases() {
        return GLOBAL.size();
    }

    /**
     * Top N best-selling items by purchase count.
     * Returns a list of entries: itemName -> count, sorted descending.
     */
    public static List<Map.Entry<String, Integer>> topItems(int limit) {
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (PurchaseLog log : GLOBAL)
            counts.merge(log.getItemName(), 1, Integer::sum);
        return counts.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    /**
     * Top N biggest spenders by total coins spent.
     * Returns a list of entries: playerName -> totalSpent, sorted descending.
     */
    public static List<Map.Entry<String, Integer>> topSpenders(int limit) {
        Map<String, Integer> spent = new LinkedHashMap<>();
        for (PurchaseLog log : GLOBAL)
            spent.merge(log.getPlayerName(), log.getFinalPaid(), Integer::sum);
        return spent.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }
}
