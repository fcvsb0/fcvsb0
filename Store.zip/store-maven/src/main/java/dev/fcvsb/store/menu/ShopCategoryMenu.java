package dev.fcvsb.store.menu;

import dev.fcvsb.store.Lang;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.restock.RestockNotifier;
import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.wishlist.WishlistManager;
import dev.fcvsb.store.wishlist.WishlistMenu;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShopCategoryMenu extends Menu {

    private static final int SLOT_BACK     = 4;
    private static final int SLOT_CART     = 40;
    private static final int SLOT_WISHLIST = 36; // only shown in gift mode

    private final ShopCategory               category;
    private final StoreCart                  cart;
    private final Menu                       back;
    private final Map<Integer, ShopProduct>     productSlots = new HashMap<>();
    private final Map<Integer, ShopSubCategory> subSlots     = new HashMap<>();

    public ShopCategoryMenu(ShopCategory category, StoreCart cart, Menu back) {
        this.category = category;
        this.cart     = cart;
        this.back     = back;
    }

    @Override
    public String title(Player p) {
        String base = ChatColor.translateAlternateColorCodes('&', category.getName());
        return cart.hasGiftTarget()
                ? base + " \u00a78| \u00a7aGift for \u00a7f" + cart.getGiftTargetName()
                : base;
    }

    @Override public int size(Player p) { return 45; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        productSlots.clear();
        subSlots.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get());
        Borders.fill(b, 45);

        b.put(SLOT_BACK, Borders.backButton());
        b.put(SLOT_CART, CartHelper.buildCartItem(p, cart));

        // Wishlist shortcut — only in gift mode
        if (cart.hasGiftTarget()) {
            java.util.Set<String> wl = WishlistManager.get(cart.getGiftTargetUUID());
            List<String> wlLore = new ArrayList<>();
            wlLore.add(ChatColor.GRAY + "Items " + cart.getGiftTargetName() + " wants:");
            if (wl.isEmpty()) {
                wlLore.add(ChatColor.GRAY + "  (empty)");
            } else {
                for (String id : wl) wlLore.add(ChatColor.YELLOW + "  ▸ " + ChatColor.WHITE + id);
            }
            wlLore.add(" ");
            wlLore.add(ChatColor.GREEN + "Click to browse their wishlist");
            b.put(SLOT_WISHLIST, ItemBuilder.of(org.bukkit.Material.BOOK)
                    .name(ChatColor.LIGHT_PURPLE + "♥ " + cart.getGiftTargetName() + "'s Wishlist")
                    .lore(wlLore).build());
        }

        for (ShopProduct product : category.getProductList()) {
            int slot = product.getSlot();
            if (slot < 0 || slot >= 45) continue;
            b.put(slot, product.getDisplayItem(p, cart));
            productSlots.put(slot, product);
        }

        for (ShopSubCategory sub : category.getSubCategories().values()) {
            int slot = sub.getSlot();
            if (slot < 0 || slot >= 45) continue;
            b.put(slot, buildSubIcon(sub));
            subSlots.put(slot, sub);
        }
        return b;
    }

    @Override
    public void onMiddleClick(Player p, int slot) {
        if (!StoreConfig.isWishlistEnabled()) return;
        ShopProduct product = productSlots.get(slot);
        if (product == null) return;
        if (!product.isWishlistAdd()) {
            p.sendMessage("\u00a7cThis item cannot be added to your wishlist.");
            return;
        }
        boolean added = WishlistManager.toggle(p.getUniqueId(), product.getId());
                DataStorage.saveWishlists();
        p.sendMessage(added
                ? ChatColor.GREEN + "♥ Added to wishlist: " + ChatColor.WHITE + ShopProduct.cleanDisplayName(product.getDisplayName())
                : ChatColor.YELLOW + "♥ Removed from wishlist: " + ChatColor.WHITE + ShopProduct.cleanDisplayName(product.getDisplayName()));
        refresh(p);
    }

    @Override
    public void onClick(Player p, int slot, boolean rightClick) {
        if (slot == SLOT_BACK) { back.open(p); return; }
        if (slot == SLOT_CART) { CartHelper.handleCartClick(p, cart, this, rightClick); return; }
        if (slot == SLOT_WISHLIST && cart.hasGiftTarget()) { new WishlistMenu(cart.getGiftTargetUUID(), cart.getGiftTargetName()).open(p); return; }

        ShopSubCategory sub = subSlots.get(slot);
        if (sub != null) { new ShopSubCategoryMenu(sub, cart, this).open(p); return; }

        ShopProduct product = productSlots.get(slot);
        if (product == null) return;

        // In gift mode: only allow giftable items
        if (cart.hasGiftTarget() && !product.isGiftable()) {
            p.sendMessage(ChatColor.RED + ShopProduct.cleanDisplayName(product.getDisplayName())
                    + " cannot be gifted.");
            return;
        }

        // Right-click on out-of-stock: subscribe to restock alert
        if (rightClick && product.getStock() == 0) {
            boolean subbed = RestockNotifier.toggle(p.getUniqueId(), product.getId());
            p.sendMessage(subbed
                    ? ChatColor.GREEN + "▸ " + ChatColor.WHITE + "You'll be notified when "
                      + ShopProduct.cleanDisplayName(product.getDisplayName()) + " restocks."
                    : ChatColor.YELLOW + "▸ " + ChatColor.WHITE + "Restock notification removed.");
            open(p);
            return;
        }

        if (!product.canPurchase(p, 1)) {
            String reason = product.getPurchaseBlockedReason(p, 1);
            p.sendMessage(ChatColor.RED + (reason != null ? reason : "You cannot purchase this."));
            return;
        }

        if (cart.contains(product)) {
            cart.removeItem(product);
            p.sendMessage(Lang.get("cart_item_removed", "%item%", ShopProduct.cleanDisplayName(product.getDisplayName())));
        } else {
            // Check cart limit
            int limit   = product.getCartLimit();
            int inCart  = cart.getItems().getOrDefault(product, 0);
            if (limit > 0 && inCart >= limit) {
                p.sendMessage(Lang.get("purchase_cart_limit", "%limit%", limit, "%item%", ShopProduct.cleanDisplayName(product.getDisplayName())));
                return;
            }
            cart.addItem(product, 1);
            if (cart.hasGiftTarget())
                p.sendMessage(Lang.get("cart_item_added_gift", "%item%", ShopProduct.cleanDisplayName(product.getDisplayName()), "%recipient%", cart.getGiftTargetName()));
            else
                p.sendMessage(Lang.get("cart_item_added", "%item%", ShopProduct.cleanDisplayName(product.getDisplayName())));
        }
        refresh(p);
    }

    private ItemStack buildSubIcon(ShopSubCategory sub) {
        List<String> lore = new ArrayList<>(sub.getLore());
        if (lore.isEmpty()) lore.add("&eClick to view");
        return ItemBuilder.of(sub.getMaterial(), sub.getMaterialData())
                .name(sub.getName()).lore(lore).build();
    }
}
