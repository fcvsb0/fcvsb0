package dev.fcvsb.store.menu;

import dev.fcvsb.store.log.PurchaseLogger;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * OP-only stats menu — 54 slots.
 *
 * Row 0: border
 * Col 1  (slots 10,19,28,37): Top Products  #1-#4
 * Col 3  (slots 12,21,30,39): Top Products  #5-#7 + summary
 * Col 5  (slots 14,23,32,41): Top Spenders  #1-#4
 * Col 7  (slots 16,25,34,43): Top Spenders  #5-#7 + totals
 * Row 5: border
 *
 * Simpler layout:
 *   Slots 10-16 (row 1): top 7 products
 *   Slots 19-25 (row 2): top 7 spenders
 *   Slot  22 (row 2 center) replaced by summary paper
 *   Slots 28-34 (row 3): padding / extra
 *   Slot  49: summary
 */
public class StatsMenu extends Menu {

    // Top products: slots in row 1 inner area
    private static final int[] PRODUCT_SLOTS = {10, 11, 12, 13, 14, 15, 16};
    // Top spenders: slots in row 2 inner area
    private static final int[] SPENDER_SLOTS = {19, 20, 21, 22, 23, 24, 25};

    private static final int SLOT_SUMMARY = 49;
    private static final int SLOT_CLOSE   = 45;

    @Override
    public String title(Player p) { return "\u00a78[\u00a76\u00a7lStore Stats\u00a78]"; }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        java.util.Map<Integer, ItemStack> b = new java.util.HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        List<Map.Entry<String, Integer>> topItems   = PurchaseLogger.topItems(7);
        List<Map.Entry<String, Integer>> topSpenders = PurchaseLogger.topSpenders(7);

        // ── Top Products ──────────────────────────────────────────────────
        // Header label
        b.put(1, ItemBuilder.of(Material.GOLD_INGOT)
                .name("&6&lTop Products")
                .lore("&7Best-selling items").build());

        for (int i = 0; i < PRODUCT_SLOTS.length; i++) {
            if (i >= topItems.size()) break;
            Map.Entry<String, Integer> e = topItems.get(i);
            int rank = i + 1;
            b.put(PRODUCT_SLOTS[i], buildRankItem(
                    rankMaterial(rank), rankName(rank), e.getKey(),
                    "&7Sold: &f" + e.getValue() + " time(s)"));
        }

        // ── Top Spenders ──────────────────────────────────────────────────
        b.put(28, ItemBuilder.of(Material.DIAMOND)
                .name("&b&lTop Spenders")
                .lore("&7Players who spent the most").build());

        for (int i = 0; i < SPENDER_SLOTS.length; i++) {
            if (i >= topSpenders.size()) break;
            Map.Entry<String, Integer> e = topSpenders.get(i);
            int rank = i + 1;
            b.put(SPENDER_SLOTS[i], buildRankItem(
                    spenderMaterial(rank), rankName(rank), e.getKey(),
                    "&7Spent: &f" + e.getValue() + " coins"));
        }

        // ── Summary ───────────────────────────────────────────────────────
        int totalPurchases = PurchaseLogger.totalPurchases();
        int totalRevenue   = PurchaseLogger.totalRevenue();
        List<String> sumLore = new ArrayList<>();
        sumLore.add("&7Total purchases: &f" + totalPurchases);
        sumLore.add("&7Total revenue:   &f" + totalRevenue + " coins");
        sumLore.add(" ");
        sumLore.add("&7Top product: &f" + (topItems.isEmpty() ? "None" : topItems.get(0).getKey()));
        sumLore.add("&7Top spender: &f" + (topSpenders.isEmpty() ? "None" : topSpenders.get(0).getKey()));
        b.put(SLOT_SUMMARY, ItemBuilder.of(Material.PAPER).name("&6&lSummary").lore(sumLore).build());

        // ── Close ─────────────────────────────────────────────────────────
        b.put(SLOT_CLOSE, ItemBuilder.of(Material.BARRIER).name("&cClose").lore("&7Close this menu.").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        if (slot == SLOT_CLOSE) p.closeInventory();
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private ItemStack buildRankItem(Material mat, String rankLabel, String name, String detail) {
        return ItemBuilder.of(mat)
                .name(rankLabel + " &f" + name)
                .lore(detail).build();
    }

    private String rankName(int rank) {
        switch (rank) {
            case 1: return "\u00a76\u00a7l#1";
            case 2: return "\u00a77\u00a7l#2";
            case 3: return "\u00a7c\u00a7l#3";
            default: return "\u00a78#" + rank;
        }
    }

    private Material rankMaterial(int rank) {
        switch (rank) {
            case 1: return Material.GOLD_BLOCK;
            case 2: return Material.IRON_BLOCK;
            case 3: return Material.REDSTONE_BLOCK;
            default: return Material.PAPER;
        }
    }

    private Material spenderMaterial(int rank) {
        switch (rank) {
            case 1: return Material.DIAMOND_BLOCK;
            case 2: return Material.GOLD_BLOCK;
            case 3: return Material.IRON_BLOCK;
            default: return Material.PAPER;
        }
    }
}
