package dev.fcvsb.store.editor;

import dev.fcvsb.store.StorePlugin;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class EditorChatListener implements Listener {

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onChat(AsyncPlayerChatEvent event) {
        Player p = event.getPlayer();
        if (!EditorSession.isWaiting(p.getUniqueId())) return;

        event.setCancelled(true);
        final String input = event.getMessage().trim();
        final EditorSession.Pending pending = EditorSession.consume(p.getUniqueId());
        if (pending == null) return;

        if (input.equalsIgnoreCase("cancel")) {
            p.sendMessage(ChatColor.RED + "Cancelled.");
            if (pending.returnMenu != null)
                org.bukkit.Bukkit.getScheduler().runTask(StorePlugin.getInstance(),
                        () -> pending.returnMenu.open(p));
            return;
        }

        org.bukkit.Bukkit.getScheduler().runTask(StorePlugin.getInstance(),
                () -> pending.onInput.accept(input));
    }
}
