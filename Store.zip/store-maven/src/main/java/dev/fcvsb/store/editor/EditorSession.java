package dev.fcvsb.store.editor;

import dev.fcvsb.store.menu.Menu;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class EditorSession {

    public static final class Pending {
        public final String           prompt;
        public final Consumer<String> onInput;
        public final Menu             returnMenu;

        public Pending(String prompt, Consumer<String> onInput, Menu returnMenu) {
            this.prompt     = prompt;
            this.onInput    = onInput;
            this.returnMenu = returnMenu;
        }
    }

    private static final Map<UUID, Pending> SESSIONS = new HashMap<>();

    public static void start(Player p, String prompt, Menu returnMenu, Consumer<String> onInput) {
        SESSIONS.put(p.getUniqueId(), new Pending(prompt, onInput, returnMenu));
        p.closeInventory();
        p.sendMessage("\u00a78\u00bb \u00a7eType in chat: \u00a7f" + prompt);
        p.sendMessage("\u00a78\u00bb \u00a77Type \u00a7ccancel\u00a77 to go back.");
    }

    public static boolean isWaiting(UUID uuid) { return SESSIONS.containsKey(uuid); }
    public static Pending consume(UUID uuid)    { return SESSIONS.remove(uuid); }
}
