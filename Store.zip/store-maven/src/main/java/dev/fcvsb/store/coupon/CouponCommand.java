package dev.fcvsb.store.coupon;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /coupon create  — opens CouponCreateMenu
 * /coupon manage  — opens CouponManageMenu
 */
public class CouponCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
        if (!sender.hasPermission("store.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }

        Player p = (Player) sender;

        if (args.length == 0) { usage(p); return true; }

        switch (args[0].toLowerCase()) {
            case "create": new CouponCreateMenu().open(p); break;
            case "manage": new CouponManageMenu().open(p); break;
            default: usage(p);
        }
        return true;
    }

    private void usage(Player p) {
        p.sendMessage(ChatColor.YELLOW + "Usage:");
        p.sendMessage(ChatColor.GRAY + "  /coupon create");
        p.sendMessage(ChatColor.GRAY + "  /coupon manage");
    }
}
