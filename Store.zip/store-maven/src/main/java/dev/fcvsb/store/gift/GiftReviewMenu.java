package dev.fcvsb.store.gift;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.text.SimpleDateFormat;
import java.util.*;

public class GiftReviewMenu extends Menu {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy HH:mm");

    private static final int SLOT_ACCEPT  = 11;
    private static final int SLOT_INFO    = 13;
    private static final int SLOT_CANCEL  = 15;

    private final PendingGift gift;
    private final Menu        back;

    public GiftReviewMenu(PendingGift gift, Menu back) {
        this.gift = gift;
        this.back = back;
    }

    @Override public String title(Player p) { return "\u00a78\u00bb \u00a7dGift Review \u00a77(OP)"; }
    @Override public int    size (Player p) { return 27; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get27());
        Borders.fill(b, 27);

        // Slot 11 — Accept
        b.put(SLOT_ACCEPT, ItemBuilder.of(Material.EMERALD)
                .name("&a&l✔ Accept Gift")
                .lore("&7Approve this gift so the recipient",
                      "&7can claim it with /gifts.",
                      " ",
                      "&aClick to accept.").build());

        // Slot 13 — Info (not clickable)
        List<String> infoLore = new ArrayList<>();
        infoLore.add("&7From:    &d" + gift.getSenderName());
        infoLore.add("&7To:      &f" + gift.getRecipientName());
        infoLore.add("&7Item:    &f" + gift.getItemName());
        infoLore.add("&7Sent:    &f" + SDF.format(new Date(gift.getCreatedAt())));
        if (gift.getMessage() != null && !gift.getMessage().isEmpty()) {
            infoLore.add(" ");
            infoLore.add("&7Message: &f" + gift.getMessage());
        }
        infoLore.add(" ");
        infoLore.add(gift.isApproved()
                ? "&a✔ Status: &2Approved"
                : "&e⏳ Status: &ePayment Confirmation Pending");
        b.put(SLOT_INFO, ItemBuilder.of(Material.BOOK)
                .name("&e&lTransaction Details")
                .lore(infoLore).build());

        // Slot 15 — Cancel
        b.put(SLOT_CANCEL, ItemBuilder.of(Material.REDSTONE_BLOCK)
                .name("&c&l✗ Cancel Transaction")
                .lore("&7Remove this gift permanently.",
                      "&7The recipient will not receive it.",
                      " ",
                      "&cClick to cancel.").build());

        // Back button
        b.put(18, Borders.backButton());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        if (slot == 18) { back.open(p); return; }

        if (slot == SLOT_ACCEPT) {
            if (gift.isApproved()) {
                p.sendMessage(ChatColor.YELLOW + "This gift is already approved.");
                return;
            }
            gift.setApproved();
            DataStorage.saveGifts();

            p.sendMessage(ChatColor.GREEN + "✔ Gift approved! "
                    + ChatColor.WHITE + gift.getRecipientName()
                    + ChatColor.GREEN + " can now claim "
                    + ChatColor.YELLOW + gift.getItemName()
                    + ChatColor.GREEN + " with /gifts.");

            // Notify recipient if online
            Player recipient = Bukkit.getPlayer(gift.getRecipientUUID());
            if (recipient != null) {
                recipient.sendMessage(ChatColor.LIGHT_PURPLE + "♥ "
                        + ChatColor.WHITE + "Your gift "
                        + ChatColor.YELLOW + gift.getItemName()
                        + ChatColor.WHITE + " from "
                        + ChatColor.LIGHT_PURPLE + gift.getSenderName()
                        + ChatColor.WHITE + " has been approved! Use "
                        + ChatColor.GREEN + "/gifts"
                        + ChatColor.WHITE + " to claim it.");
            }

            back.open(p);
            return;
        }

        if (slot == SLOT_CANCEL) {
            gift.setClaimed(); // mark as claimed so it won't show up

            // Refund coins to sender
            PlayerData senderData = PlayerData.get(gift.getSenderUUID());
            int refund = gift.getRefundAmount();
            if (refund > 0) {
                senderData.addCoins(refund);
                DataStorage.savePlayer(gift.getSenderUUID(), senderData);
                // Notify sender if online
                Player sender = Bukkit.getPlayer(gift.getSenderUUID());
                if (sender != null) {
                    sender.sendMessage(ChatColor.YELLOW + "↩ Your gift of "
                            + ChatColor.WHITE + gift.getItemName()
                            + ChatColor.YELLOW + " was cancelled by staff. "
                            + ChatColor.GREEN + refund + " coins"
                            + ChatColor.YELLOW + " have been refunded.");
                }
            }

            DataStorage.saveGifts();

            p.sendMessage(ChatColor.RED + "✗ Transaction cancelled. "
                    + ChatColor.WHITE + gift.getItemName()
                    + ChatColor.RED + " removed."
                    + (refund > 0 ? ChatColor.YELLOW + " " + refund + " coins refunded to " + ChatColor.WHITE + gift.getSenderName() + ChatColor.YELLOW + "." : ""));

            back.open(p);
        }
    }
}
