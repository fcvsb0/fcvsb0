package dev.fcvsb.store.coupon;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Coupon {

    private final String code;
    private final int    discountPct;    // 1-99
    private final long   expireAt;       // 0 = never
    private final int    maxUses;        // 0 = unlimited (total uses across all players)
    private final int    playerMaxUses;  // 0 = unlimited (uses per individual player)
    private final Map<UUID, Integer> useCountByPlayer = new HashMap<>();

    public Coupon(String code, int discountPct, long expireAt, int maxUses, int playerMaxUses) {
        this.code           = code;
        this.discountPct    = discountPct;
        this.expireAt       = expireAt;
        this.maxUses        = maxUses;
        this.playerMaxUses  = playerMaxUses;
    }

    public String  getCode()           { return code; }
    public int     getDiscountPct()    { return discountPct; }
    public long    getExpireAt()       { return expireAt; }
    public int     getMaxUses()        { return maxUses; }
    public int     getPlayerMaxUses()  { return playerMaxUses; }
    public Map<UUID, Integer> getUsedBy() { return useCountByPlayer; }
    public Set<UUID> getUsedBySet()    { return useCountByPlayer.keySet(); }
    public int     getUseCount()       { return useCountByPlayer.values().stream().mapToInt(i -> i).sum(); }
    public int     getPlayerUseCount(UUID uuid) { return useCountByPlayer.getOrDefault(uuid, 0); }

    public boolean isExpired()    { return expireAt > 0 && System.currentTimeMillis() > expireAt; }
    public boolean isExhausted()  { return maxUses > 0 && getUseCount() >= maxUses; }
    public boolean isValid()      { return !isExpired() && !isExhausted(); }
    public boolean hasUsed(UUID uuid) {
        if (playerMaxUses > 0) return getPlayerUseCount(uuid) >= playerMaxUses;
        return playerMaxUses == 0 && false; // unlimited per player — never blocks on this alone
    }
    public boolean canUse(UUID uuid) {
        if (!isValid()) return false;
        if (playerMaxUses > 0 && getPlayerUseCount(uuid) >= playerMaxUses) return false;
        return true;
    }

    public boolean use(UUID uuid) {
        if (!canUse(uuid)) return false;
        useCountByPlayer.merge(uuid, 1, Integer::sum);
        return true;
    }

    // Used during load to restore persisted counts
    public void addUse(UUID uuid, int count) {
        useCountByPlayer.merge(uuid, count, Integer::sum);
    }

    public String formatExpiry() {
        if (expireAt == 0) return "Never";
        long rem = expireAt - System.currentTimeMillis();
        if (rem <= 0) return "Expired";
        long s = rem / 1000, m = s / 60, h = m / 60, d = h / 24;
        if (d > 0) return d + "d " + (h % 24) + "h";
        if (h > 0) return h + "h " + (m % 60) + "m";
        if (m > 0) return m + "m " + (s % 60) + "s";
        return s + "s";
    }
}
