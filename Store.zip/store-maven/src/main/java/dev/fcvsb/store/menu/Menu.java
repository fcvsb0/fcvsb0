package dev.fcvsb.store.menu;

import dev.fcvsb.store.StorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public abstract class Menu {

    private static final Map<UUID, Menu> OPEN          = new HashMap<>();
    private static final Set<UUID>       TRANSITIONING = new HashSet<>();

    public abstract String title(Player p);
    public abstract int    size (Player p);
    public abstract Map<Integer, ItemStack> buttons(Player p);

    public void onClick(Player p, int slot) {}
    public void onClick(Player p, int slot, boolean rightClick) { onClick(p, slot); }
    public void onMiddleClick(Player p, int slot) {}

    /**
     * Opens menu fresh — use only when transitioning from another menu.
     */
    public final void open(Player p) {
        UUID uuid = p.getUniqueId();
        if (p.getOpenInventory() != null
                && p.getOpenInventory().getTopInventory() != null
                && p.getOpenInventory().getTopInventory().getSize() > 0) {
            TRANSITIONING.add(uuid);
            p.closeInventory();
            final Menu self = this;
            Bukkit.getScheduler().runTaskLater(StorePlugin.getInstance(), () -> {
                TRANSITIONING.remove(uuid);
                self.openNow(p);
            }, 1L);
        } else {
            openNow(p);
        }
    }

    /**
     * Refreshes inventory contents IN PLACE — cursor stays still.
     * Use this when adding/removing cart items without changing menus.
     */
    public final void refresh(Player p) {
        Inventory top = p.getOpenInventory() == null ? null
                : p.getOpenInventory().getTopInventory();
        if (top == null || top.getSize() != size(p)) {
            open(p);
            return;
        }
        top.clear();
        Map<Integer, ItemStack> btns = buttons(p);
        for (Map.Entry<Integer, ItemStack> e : btns.entrySet()) {
            int slot = e.getKey();
            if (slot >= 0 && slot < top.getSize() && e.getValue() != null)
                top.setItem(slot, e.getValue());
        }
        p.updateInventory();
    }

    private void openNow(Player p) {
        Map<Integer, ItemStack> btns = buttons(p);
        Inventory inv = Bukkit.createInventory(null, size(p), title(p));
        for (Map.Entry<Integer, ItemStack> e : btns.entrySet()) {
            if (e.getKey() >= 0 && e.getKey() < inv.getSize() && e.getValue() != null)
                inv.setItem(e.getKey(), e.getValue());
        }
        OPEN.put(p.getUniqueId(), this);
        p.openInventory(inv);
        onOpened(p);
    }

    /** Called after the inventory is opened. Override for post-open logic. */
    protected void onOpened(Player p) {}

    // ── Events ────────────────────────────────────────────────────────────

    public static Menu getOpen(Player p) { return OPEN.get(p.getUniqueId()); }

    public static class MenuEvents implements Listener {

        @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
        public void onClick(InventoryClickEvent e) {
            if (!(e.getWhoClicked() instanceof Player)) return;
            Player p = (Player) e.getWhoClicked();
            Menu   m = OPEN.get(p.getUniqueId());
            if (m == null) return;

            e.setCancelled(true);

            int raw     = e.getRawSlot();
            int guiSize = e.getInventory().getSize();
            if (raw < 0 || raw >= guiSize) return;
            if (e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY) return;

            boolean isRight  = e.isRightClick();
            boolean isMiddle = e.getClick() == ClickType.MIDDLE;
            if (isMiddle) { m.onMiddleClick(p, raw); return; }
            m.onClick(p, raw, isRight);
        }

        @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
        public void onDrag(InventoryDragEvent e) {
            if (!(e.getWhoClicked() instanceof Player)) return;
            if (!OPEN.containsKey(e.getWhoClicked().getUniqueId())) return;
            e.setCancelled(true);
        }

        @EventHandler
        public void onClose(InventoryCloseEvent e) {
            UUID uuid = e.getPlayer().getUniqueId();
            if (!TRANSITIONING.contains(uuid)) OPEN.remove(uuid);
        }
    }
}
