package dev.fcvsb.store.menu;

import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.restock.RestockNotifier;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * OP-only menu to set stock for any product.
 * Shows all products as clickable icons — click to type a new stock value.
 */
public class SetStockMenu extends Menu {

    private int page;

    public SetStockMenu()         { this.page = 0; }
    public SetStockMenu(int page) { this.page = page; }

    private static final int PAGE_SIZE = 28;

    @Override
    public String title(Player p) { return "\u00a78[\u00a76Set Stock\u00a78]"; }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        List<ShopProduct> all = getAllProducts();
        int total = (int) Math.ceil(Math.max(1, all.size()) / (double) PAGE_SIZE);
        int start = page * PAGE_SIZE;

        int[] slots = innerSlots();
        for (int i = 0; i < slots.length; i++) {
            int idx = start + i;
            if (idx >= all.size()) break;
            ShopProduct sp = all.get(idx);
            b.put(slots[i], buildProductItem(sp));
        }

        b.put(49, ItemBuilder.of(Material.PAPER).name("&7Page &f" + (page+1) + " / " + total).build());
        if (page > 0)        b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total-1)  b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        List<ShopProduct> all = getAllProducts();
        int total = (int) Math.ceil(Math.max(1, all.size()) / (double) PAGE_SIZE);

        if (slot == 45 && page > 0)        { new SetStockMenu(page - 1).open(p); return; }
        if (slot == 53 && page < total-1)  { new SetStockMenu(page + 1).open(p); return; }

        int[] slots = innerSlots();
        for (int i = 0; i < slots.length; i++) {
            if (slot != slots[i]) continue;
            int idx = page * PAGE_SIZE + i;
            if (idx >= all.size()) return;
            ShopProduct sp = all.get(idx);

            EditorSession.start(p, "New stock for " + sp.getDisplayName() + " (current: " + stockStr(sp) + ") | -1 = disable | cancel", null, input -> {
                if (input.equalsIgnoreCase("cancel")) {
                    p.sendMessage("\u00a7cCancelled.");
                    new SetStockMenu(page).open(p);
                    return;
                }
                int val;
                try { val = Integer.parseInt(input.trim()); }
                catch (NumberFormatException e) {
                    p.sendMessage("\u00a7cInvalid number. Cancelled.");
                    new SetStockMenu(page).open(p);
                    return;
                }
                int oldStock = sp.getStock();
                sp.setStock(val);

                // Notify subscribers if restocked from 0
                if (oldStock == 0 && val > 0)
                    RestockNotifier.notifyRestock(sp.getId(), sp.getDisplayName(), val);

                p.sendMessage("\u00a7a\u25b8 Stock for \u00a7f" + sp.getDisplayName()
                        + "\u00a7a set to \u00a7f" + stockStr(sp));
                new SetStockMenu(page).open(p);
            });
            return;
        }
    }

    private ItemStack buildProductItem(ShopProduct sp) {
        String stockLine;
        if      (sp.getStock() < 0)  stockLine = "&7Stock: &8Disabled";
        else if (sp.getStock() == 0) stockLine = "&cOut of stock";
        else                         stockLine = "&7Stock: &f" + sp.getStock();

        ItemStack base = sp.getDisplayItem(null, null);
        Material mat   = (base != null) ? base.getType() : Material.PAPER;
        short    data  = (base != null) ? base.getDurability() : 0;

        return ItemBuilder.of(mat, data)
                .name(sp.getDisplayName())
                .lore(stockLine, "&8ID: " + sp.getId(), " ", "&eClick to set stock").build();
    }

    private String stockStr(ShopProduct sp) {
        if (sp.getStock() < 0)  return "Disabled";
        if (sp.getStock() == 0) return "Out of stock";
        return String.valueOf(sp.getStock());
    }

    private List<ShopProduct> getAllProducts() {
        List<ShopProduct> list = new ArrayList<>();
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            list.addAll(cat.getProducts().values());
            for (ShopSubCategory sub : cat.getSubCategories().values())
                list.addAll(sub.getProducts().values());
        }
        return list;
    }

    private int[] innerSlots() {
        int[] slots = new int[PAGE_SIZE];
        int idx = 0;
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++)
                slots[idx++] = row * 9 + col;
        return slots;
    }
}
