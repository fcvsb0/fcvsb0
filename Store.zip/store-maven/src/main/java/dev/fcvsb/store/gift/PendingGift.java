package dev.fcvsb.store.gift;

import java.util.UUID;

/**
 * A gift that was purchased but not yet claimed by the recipient.
 */
public class PendingGift {

    private final String id;           // unique ID
    private final UUID   senderUUID;
    private final String senderName;
    private final UUID   recipientUUID;
    private final String recipientName;
    private final String itemId;
    private final String itemName;
    private final String message;      // optional personal message
    private final long   createdAt;
    private       boolean claimed;
    private       boolean approved;
    private       int     pricePaid;  // coins paid for this gift (used for refund) // staff must approve before recipient can claim

    public PendingGift(String id, UUID senderUUID, String senderName,
                       UUID recipientUUID, String recipientName,
                       String itemId, String itemName,
                       String message, long createdAt) {
        this.id            = id;
        this.senderUUID    = senderUUID;
        this.senderName    = senderName;
        this.recipientUUID = recipientUUID;
        this.recipientName = recipientName;
        this.itemId        = itemId;
        this.itemName      = itemName;
        this.message       = message;
        this.createdAt     = createdAt;
        this.claimed       = false;
        this.approved      = false;
        this.pricePaid     = 0;
    }

    public String  getId()            { return id; }
    public UUID    getSenderUUID()    { return senderUUID; }
    public String  getSenderName()    { return senderName; }
    public UUID    getRecipientUUID() { return recipientUUID; }
    public String  getRecipientName() { return recipientName; }
    public String  getItemId()        { return itemId; }
    public String  getItemName()      { return itemName; }
    public String  getMessage()       { return message; }
    public long    getCreatedAt()     { return createdAt; }
    public boolean isClaimed()        { return claimed; }
    public void    setClaimed()       { this.claimed = true; }
    public boolean isApproved()       { return approved; }
    public void    setApproved()      { this.approved = true; }
    public int     getRefundAmount()  { return pricePaid; }
    public void    setPricePaid(int p){ this.pricePaid = p; }
}
