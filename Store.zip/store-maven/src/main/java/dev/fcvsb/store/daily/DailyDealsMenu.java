package dev.fcvsb.store.daily;

import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.CartHelper;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import dev.fcvsb.store.StorePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class DailyDealsMenu extends Menu {

    // 27-slot layout: row 1 = border, row 2 = items (slots 10-16), row 3 = border+ui
    private static final int[] ITEM_SLOTS = { 10, 11, 12, 13, 14, 15, 16 };

    private final StoreCart cart;
    private final Menu      back;
    private final Map<Integer, ShopProduct> slotMap = new HashMap<>();

    public DailyDealsMenu(StoreCart cart, Menu back) {
        this.cart = cart;
        this.back = back;
    }

    @Override
    protected void onOpened(Player p) {
        // Ensure global clock is running (lazy start in case plugin loaded without daily-deals enabled)
        startGlobalClock();
    }

    @Override public String title(Player p) { return "\u00a76\u00a7l\u2605 Daily Deals"; }
    @Override public int    size (Player p) { return 27; }

    // ── Global clock ticker (one scheduler for ALL players in this menu) ──
    private static org.bukkit.scheduler.BukkitTask clockTask = null;

    public static void startGlobalClock() {
        if (clockTask != null) return;
        clockTask = new BukkitRunnable() {
            @Override public void run() {
                ItemStack dealsClock  = buildStaticClockItem();
                ItemStack storeButton = buildStaticStoreButton();

                for (Player p : org.bukkit.Bukkit.getOnlinePlayers()) {
                    if (p.getOpenInventory() == null) continue;
                    org.bukkit.inventory.Inventory top = p.getOpenInventory().getTopInventory();
                    if (top == null) continue;
                    dev.fcvsb.store.menu.Menu m = dev.fcvsb.store.menu.Menu.getOpen(p);
                    if (m == null) continue;

                    // Inside DailyDealsMenu — update clock slot (22)
                    if (m instanceof DailyDealsMenu && top.getSize() == 27) {
                        top.setItem(22, dealsClock);
                        p.updateInventory();
                    }
                    // Inside StoreMenu — update deals button slot
                    else if (m instanceof dev.fcvsb.store.menu.StoreMenu && top.getSize() == 54) {
                        int slot = dev.fcvsb.store.StoreConfig.getDailyDealSlot();
                        if (slot >= 0 && slot < 54) {
                            top.setItem(slot, storeButton);
                            p.updateInventory();
                        }
                    }
                }
            }
        }.runTaskTimer(StorePlugin.getInstance(), 20L, 20L);
    }

    /** Builds the deals button shown in StoreMenu — updated every second */
    public static ItemStack buildStaticStoreButton() {
        java.util.List<DailyDeal> deals = new java.util.ArrayList<>(DailyDealManager.getActive());
        java.util.List<String> lore = new java.util.ArrayList<>();
        lore.add("&7Resets in: &e" + DailyDealManager.getCountdown());
        lore.add(" ");
        if (deals.isEmpty()) {
            lore.add("&8No deals available right now.");
        } else {
            for (DailyDeal d : deals) {
                // Find product name
                String name = d.getProductId();
                outer:
                for (dev.fcvsb.store.shop.ShopCategory cat : dev.fcvsb.store.shop.ShopLoader.getCategories().values()) {
                    for (dev.fcvsb.store.shop.ShopProduct sp : cat.getProducts().values())
                        if (sp.getId().equals(d.getProductId())) { name = dev.fcvsb.store.shop.ShopProduct.cleanDisplayName(sp.getDisplayName()); break outer; }
                    for (dev.fcvsb.store.shop.ShopSubCategory sub : cat.getSubCategories().values())
                        for (dev.fcvsb.store.shop.ShopProduct sp : sub.getProducts().values())
                            if (sp.getId().equals(d.getProductId())) { name = dev.fcvsb.store.shop.ShopProduct.cleanDisplayName(sp.getDisplayName()); break outer; }
                }
                lore.add("&a" + name + " &7— &c-" + d.getDiscountPct() + "% &7(" + d.getDealPrice() + " coins)");
            }
        }
        lore.add(" ");
        lore.add("&eClick to view deals!");
        return dev.fcvsb.store.util.ItemBuilder.of(org.bukkit.Material.NETHER_STAR)
                .name("&6&l★ Daily Deals")
                .lore(lore).build();
    }

    public static void stopGlobalClock() {
        if (clockTask != null) { clockTask.cancel(); clockTask = null; }
    }

    // Static version — builds once, shared for all players in that tick
    private static ItemStack buildStaticClockItem() {
        return dev.fcvsb.store.util.ItemBuilder.of(Material.WATCH)
                .name("&6&lResets In: &e" + DailyDealManager.getCountdown())
                .lore("&7Discount: &c-" + StoreConfig.getDailyDealPercent() + "%",
                      "&7New deals every 24 hours.",
                      DailyDealManager.isPaused() ? "&c⏸ Paused" : " ").build();
    }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        slotMap.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get27());
        Borders.fill(b, 27);

        List<DailyDeal> deals = new ArrayList<>(DailyDealManager.getActive());

        if (deals.isEmpty()) {
            b.put(13, ItemBuilder.of(Material.BARRIER)
                    .name("&cNo Active Deals")
                    .lore("&7Check back soon!").build());
        } else {
            int offset = Math.max(0, (7 - deals.size()) / 2);
            for (int i = 0; i < Math.min(deals.size(), ITEM_SLOTS.length); i++) {
                DailyDeal deal = deals.get(i);
                ShopProduct sp = findProduct(deal.getProductId());
                if (sp == null) continue;
                int slot = ITEM_SLOTS[Math.min(offset + i, ITEM_SLOTS.length - 1)];
                b.put(slot, buildDealItem(sp, deal));
                slotMap.put(slot, sp);
            }
        }

        // UI row (bottom border)
        b.put(18, Borders.backButton());
        b.put(22, buildClockItem());
        b.put(26, CartHelper.buildCartItem(p, cart));

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean rightClick) {
        if (slot == 18) { back.open(p); return; }
        if (slot == 26) { CartHelper.handleCartClick(p, cart, this, rightClick); return; }

        ShopProduct sp = slotMap.get(slot);
        if (sp == null) return;

        DailyDeal deal = DailyDealManager.getDeal(sp.getId());
        if (deal == null) return;

        // Respect cart limit (quantity field in product YAML)
        int limit  = sp.getCartLimit();
        int inCart = cart.getItems().getOrDefault(sp, 0);
        if (limit > 0 && inCart >= limit) {
            p.sendMessage(ChatColor.RED + "✗ You can only add " + ChatColor.WHITE + limit
                    + ChatColor.RED + "x " + ChatColor.WHITE
                    + ShopProduct.cleanDisplayName(sp.getDisplayName())
                    + ChatColor.RED + " per purchase.");
            return;
        }

        cart.addItemWithPrice(sp, 1, deal.getDealPrice());

        p.sendMessage(ChatColor.GREEN + "\u25b8 " + ChatColor.WHITE
                + ChatColor.translateAlternateColorCodes('&', sp.getDisplayName())
                + ChatColor.GREEN + " added to cart at "
                + ChatColor.YELLOW + deal.getDealPrice() + " coins"
                + ChatColor.GREEN + " (" + ChatColor.RED + "-" + deal.getDiscountPct() + "%" + ChatColor.GREEN + ")!");
        refresh(p);
    }

    private ItemStack buildDealItem(ShopProduct sp, DailyDeal deal) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Original: &m&7" + deal.getOriginalPrice() + " coins");
        lore.add("&aDeal price: &f&l" + deal.getDealPrice() + " coins");
        lore.add("&7You save: &c-" + deal.getDiscountPct() + "% &7(" + deal.getSavings() + " coins)");
        lore.add(" ");
        lore.add("&eClick to add to cart!");
        return ItemBuilder.of(sp.getMaterial(), sp.getMaterialData())
                .name("&6\u2605 " + sp.getDisplayName())
                .lore(lore)
                .build();
    }

    private ItemStack buildClockItem() { return buildStaticClockItem(); }

    private ShopProduct findProduct(String id) {
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (ShopProduct sp : cat.getProducts().values())
                if (sp.getId().equals(id)) return sp;
            for (ShopSubCategory sub : cat.getSubCategories().values())
                for (ShopProduct sp : sub.getProducts().values())
                    if (sp.getId().equals(id)) return sp;
        }
        return null;
    }
}
