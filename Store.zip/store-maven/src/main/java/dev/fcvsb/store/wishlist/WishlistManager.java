package dev.fcvsb.store.wishlist;

import java.util.*;

/**
 * Tracks each player's wishlist (set of item IDs).
 * Persisted via DataStorage.
 */
public class WishlistManager {

    // UUID -> set of item IDs on wishlist
    private static final Map<UUID, Set<String>> WISHLISTS = new HashMap<>();

    public static Set<String> get(UUID uuid) {
        return WISHLISTS.computeIfAbsent(uuid, k -> new LinkedHashSet<>());
    }

    public static boolean toggle(UUID uuid, String itemId) {
        Set<String> list = get(uuid);
        if (list.contains(itemId)) { list.remove(itemId); return false; }
        else                       { list.add(itemId);    return true;  }
    }

    public static void remove(UUID uuid, String itemId) {
        Set<String> list = WISHLISTS.get(uuid);
        if (list != null) list.remove(itemId);
    }

    public static boolean has(UUID uuid, String itemId) {
        return WISHLISTS.getOrDefault(uuid, Collections.emptySet()).contains(itemId);
    }

    public static void clear(UUID uuid) {
        WISHLISTS.remove(uuid);
    }

    public static Map<UUID, Set<String>> getAll() { return WISHLISTS; }
}
