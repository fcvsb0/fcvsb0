package dev.fcvsb.store.subscription;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class SubscriptionManager {

    private static final Map<String, ActiveSubscription> ALL = new LinkedHashMap<>();
    private static       long idCounter = 0;

    // ── Create ────────────────────────────────────────────────────────────

    public static ActiveSubscription create(UUID playerUUID, String playerName,
                                             String productId, String productName,
                                             long durationMs,
                                             List<String> onActivate) {
        String id  = "sub_" + (++idCounter) + "_" + System.currentTimeMillis();
        long   now = System.currentTimeMillis();
        ActiveSubscription sub = new ActiveSubscription(id, playerUUID, playerName,
                productId, productName, now, now + durationMs);
        ALL.put(id, sub);

        // Run activate commands immediately
        runCommands(onActivate, playerName);
        return sub;
    }

    public static void loadRaw(String id, UUID playerUUID, String playerName,
                                String productId, String productName,
                                long startedAt, long expiresAt,
                                boolean warned24h, boolean expired) {
        ActiveSubscription sub = new ActiveSubscription(id, playerUUID, playerName,
                productId, productName, startedAt, expiresAt);
        if (warned24h) sub.setWarned24h();
        if (expired)   sub.setExpired();
        ALL.put(id, sub);
        // Keep idCounter safe
        try {
            long n = Long.parseLong(id.split("_")[1]);
            if (n > idCounter) idCounter = n;
        } catch (Exception ignored) {}
    }

    // ── Tick (called every minute) ────────────────────────────────────────

    public static void tick(Map<String, List<String>> expireCommandsByProduct) {
        long now = System.currentTimeMillis();
        for (ActiveSubscription sub : new java.util.ArrayList<>(ALL.values())) {
            if (sub.isExpired()) continue;

            long rem = sub.getExpiresAt() - now;

            // 24h warning
            if (!sub.isWarned24h() && rem <= 86_400_000L && rem > 0) {
                sub.setWarned24h();
                Player p = Bukkit.getPlayer(sub.getPlayerUUID());
                if (p != null) {
                    p.sendMessage(ChatColor.GOLD + "⚠ " + ChatColor.YELLOW + "Your "
                            + ChatColor.WHITE + sub.getProductName()
                            + ChatColor.YELLOW + " membership expires in "
                            + ChatColor.RED + sub.formatTimeLeft() + ChatColor.YELLOW + "!");
                }
            }

            // Expiry
            if (rem <= 0) {
                sub.setExpired();
                List<String> cmds = expireCommandsByProduct.getOrDefault(sub.getProductId(), Collections.emptyList());
                runCommands(cmds, sub.getPlayerName());
                Player p = Bukkit.getPlayer(sub.getPlayerUUID());
                if (p != null) {
                    p.sendMessage(ChatColor.RED + "✗ " + ChatColor.WHITE + sub.getProductName()
                            + ChatColor.RED + " membership has expired.");
                }
            }
        }
    }

    // ── Query ─────────────────────────────────────────────────────────────

    public static Collection<ActiveSubscription> getAll()  { return ALL.values(); }

    public static List<ActiveSubscription> getForPlayer(UUID uuid) {
        return ALL.values().stream()
                .filter(s -> s.getPlayerUUID().equals(uuid) && s.isActive())
                .collect(Collectors.toList());
    }

    public static boolean hasActiveSub(UUID uuid, String productId) {
        return ALL.values().stream()
                .anyMatch(s -> s.getPlayerUUID().equals(uuid)
                        && s.getProductId().equals(productId)
                        && s.isActive());
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static void runCommands(List<String> cmds, String playerName) {
        for (String cmd : cmds) {
            String parsed = cmd.replace("<player>", playerName);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), parsed);
        }
    }
}
