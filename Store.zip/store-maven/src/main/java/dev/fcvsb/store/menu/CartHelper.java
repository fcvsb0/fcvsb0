package dev.fcvsb.store.menu;

import dev.fcvsb.store.Lang;
import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.StoreItem;
import dev.fcvsb.store.StoreBroadcastQueue;
import dev.fcvsb.store.wishlist.WishlistManager;
import dev.fcvsb.store.gift.PendingGift;
import dev.fcvsb.store.gift.PendingGiftManager;
import dev.fcvsb.store.subscription.SubscriptionManager;
import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.coupon.Coupon;
import dev.fcvsb.store.coupon.CouponManager;
import dev.fcvsb.store.log.PurchaseLog;
import dev.fcvsb.store.log.PurchaseLogger;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;
import dev.fcvsb.store.StorePlugin;
import dev.fcvsb.store.storage.DataStorage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class CartHelper {

    private static final Random RNG = new Random();

    public static ItemStack buildCartItem(Player player, StoreCart cart) {
        if (cart.getItems().isEmpty())
            return ItemBuilder.of(Material.MINECART)
                    .name("&c&lEmpty Cart")
                    .lore("&7No items.", " ", "&eClick to open").build();

        List<String> lore = new ArrayList<>();
        int finalTotal = cart.getFinalTotal(player);
        lore.add("&eTotal: &f" + finalTotal + " coins");
        if (cart.hasGiftTarget())
            lore.add("&d\u25b8 Gift for: &f" + cart.getGiftTargetName());
        lore.add(" ");
        for (Map.Entry<StoreItem, Integer> e : cart.getItems().entrySet())
            lore.add("&7" + e.getValue() + "x &r" + ShopProduct.cleanDisplayName(e.getKey().getDisplayName()));
        lore.add(" ");
        lore.add("&aClick &fto view cart");
        lore.add("&cRight click &fto clear");

        return ItemBuilder.of(Material.STORAGE_MINECART)
                .name((cart.hasGiftTarget() ? "&d\u25b8 &6" : "&6") + "&lCart &7(" + cart.getSize() + " items)")
                .lore(lore).build();
    }

    public static void handleCartClick(Player player, StoreCart cart, Menu currentMenu, boolean rightClick) {
        if (rightClick) {
            cart.clear();
            player.sendMessage(Lang.get("cart_cleared"));
            playSound(player, StoreConfig.getSoundNeutral());
            currentMenu.open(player);
            return;
        }
        if (cart.getSize() == 0) {
            player.sendMessage(Lang.get("cart_empty"));
            playSound(player, StoreConfig.getSoundFail());
            return;
        }
        new CartMenu(cart, currentMenu).open(player);
    }

    public static void processPurchase(Player player, StoreCart cart) {
        PlayerData data       = PlayerData.get(player.getUniqueId());
        Coupon     coupon     = CouponManager.getApplied(player.getUniqueId());
        boolean    isGift     = cart.hasGiftTarget();
        String     giftName   = isGift ? cart.getGiftTargetName() : null;
        Player     recipient  = isGift ? Bukkit.getPlayerExact(giftName) : null;

        // If gift target set but player went offline, abort
        if (isGift && recipient == null) {
            player.sendMessage(ChatColor.RED + "Gift recipient " + ChatColor.WHITE + giftName
                    + ChatColor.RED + " is no longer online. Purchase cancelled.");
            playSound(player, StoreConfig.getSoundFail());
            return;
        }

        int cartTotal   = cart.getTotal(player);
        int couponSavings= cart.getCouponSavings(player);
        int afterCoupon = cart.getTotalWithCoupon(player);
        int giftFee     = cart.getGiftFeeTotal(player);
        int finalTotal  = cart.getFinalTotal(player);

        // Validate purchasability (always check against buyer)
        for (Map.Entry<StoreItem, Integer> e : cart.getItems().entrySet()) {
            if (!e.getKey().canPurchase(player, e.getValue())) {
                player.sendMessage(ChatColor.RED + e.getKey().getPurchaseBlockedReason(player, e.getValue()));
                playSound(player, StoreConfig.getSoundFail());
                return;
            }
            // If gifting, check item is giftable
            if (isGift && !e.getKey().isGiftable()) {
                player.sendMessage(ChatColor.RED + ShopProduct.cleanDisplayName(e.getKey().getDisplayName())
                        + " cannot be gifted.");
                playSound(player, StoreConfig.getSoundFail());
                return;
            }
            // Subscriptions cannot be gifted — they activate on the buyer
            if (isGift && e.getKey() instanceof ShopProduct && ((ShopProduct) e.getKey()).isSubscription()) {
                player.sendMessage(ChatColor.RED + "Memberships cannot be gifted.");
                playSound(player, StoreConfig.getSoundFail());
                return;
            }
        }

        // Atomic stock reservation — synchronized on ShopProduct instances to prevent
        // two players buying the last unit simultaneously with an alt
        List<ShopProduct> reservedStock = new ArrayList<>();
        for (Map.Entry<StoreItem, Integer> e : cart.getItems().entrySet()) {
            if (!(e.getKey() instanceof ShopProduct)) continue;
            ShopProduct sp = (ShopProduct) e.getKey();
            int qty = e.getValue();
            synchronized (sp) {
                int stock = sp.getStock();
                if (stock == 0) {
                    player.sendMessage(ChatColor.RED + ShopProduct.cleanDisplayName(sp.getDisplayName())
                            + " is out of stock.");
                    // Release any already-reserved stock
                    for (ShopProduct r : reservedStock) synchronized (r) { r.setStock(r.getStock() + 1); }
                    playSound(player, StoreConfig.getSoundFail());
                    return;
                }
                if (stock > 0 && qty > stock) {
                    player.sendMessage(ChatColor.RED + "Not enough stock for "
                            + ShopProduct.cleanDisplayName(sp.getDisplayName())
                            + ChatColor.RED + ". Available: " + ChatColor.WHITE + stock);
                    for (ShopProduct r : reservedStock) synchronized (r) { r.setStock(r.getStock() + 1); }
                    playSound(player, StoreConfig.getSoundFail());
                    return;
                }
                // Reserve stock now — release if payment fails
                if (stock > 0) {
                    int newStock = stock - qty;
                    sp.setStock(newStock);
                    reservedStock.add(sp);
                    // Broadcast SOLD OUT if stock just hit 0
                    if (newStock == 0) {
                        String soldMsg = ChatColor.RED + "" + ChatColor.BOLD + "SOLD OUT! "
                                + ChatColor.RESET + ChatColor.WHITE + ShopProduct.cleanDisplayName(sp.getDisplayName())
                                + ChatColor.GRAY + " is now out of stock.";
                        Bukkit.broadcastMessage(soldMsg);
                    }
                }
            }
        }

        if (!data.takeCoins(finalTotal)) {
            player.sendMessage(Lang.get("purchase_not_enough", "%total%", finalTotal, "%coins%", data.getCoins()));
            // Release reserved stock since payment failed
            for (ShopProduct r : reservedStock) synchronized (r) { r.setStock(r.getStock() + 1); }
            playSound(player, StoreConfig.getSoundFail());
            return;
        }

        // Mark coupon used
        String couponCode = null;
        if (coupon != null) {
            coupon.use(player.getUniqueId());
            CouponManager.clearApplied(player.getUniqueId());
            couponCode = coupon.getCode();
            if (couponSavings > 0)
                player.sendMessage(ChatColor.GREEN + "Coupon " + ChatColor.WHITE + coupon.getCode()
                        + ChatColor.GREEN + " saved you " + ChatColor.WHITE + couponSavings + ChatColor.GREEN + " coins!");
        }

        if (isGift && giftFee > 0)
            player.sendMessage(ChatColor.GRAY + "Gift fee applied: " + ChatColor.WHITE + giftFee + " coins.");

        // Grant items to buyer or gift recipient
        Player grantTarget = isGift ? recipient : player;

        for (Map.Entry<StoreItem, Integer> e : cart.getItems().entrySet()) {
            StoreItem item = e.getKey();
            int       qty  = e.getValue();

            // Grant items — if gift, create pending gift (claimable via /gifts)
            if (isGift && item instanceof ShopProduct) {
                ShopProduct sp = (ShopProduct) item;
                String giftMsg = cart.getGiftMessage();
                for (int i = 0; i < qty; i++) {
                    int unitPrice = cart.getOverridePrice(sp) > 0
                            ? cart.getOverridePrice(sp)
                            : sp.getPrice(player);
                    PendingGift pending = PendingGiftManager.create(
                            player.getUniqueId(), player.getName(),
                            cart.getGiftTargetUUID(), giftName,
                            sp.getId(), ShopProduct.cleanDisplayName(sp.getDisplayName()),
                            giftMsg, unitPrice);
                    // Auto-approve unless gift exceeds review threshold
                    int threshold = dev.fcvsb.store.StoreConfig.getGiftReviewThreshold();
                    boolean needsReview = threshold > 0 && unitPrice >= threshold;
                    if (!needsReview) pending.setApproved();
                    // Remove item from recipient's wishlist since it's been purchased
                    WishlistManager.remove(cart.getGiftTargetUUID(), sp.getId());
                    // Persist gifts immediately
                    dev.fcvsb.store.storage.DataStorage.saveGifts();
                    // Notify recipient if online
                    if (recipient != null) {
                        if (needsReview) {
                            recipient.sendMessage(ChatColor.YELLOW + "\u231b " + ChatColor.WHITE
                                    + player.getName() + ChatColor.YELLOW + " sent you a gift: "
                                    + ChatColor.YELLOW + ShopProduct.cleanDisplayName(sp.getDisplayName())
                                    + ChatColor.YELLOW + ". Pending staff approval.");
                        } else {
                            recipient.sendMessage(ChatColor.LIGHT_PURPLE + "\u2665 " + ChatColor.WHITE
                                    + player.getName() + ChatColor.GREEN + " sent you a gift: "
                                    + ChatColor.YELLOW + ShopProduct.cleanDisplayName(sp.getDisplayName())
                                    + ChatColor.GREEN + "! Use " + ChatColor.WHITE + "/gifts"
                                    + ChatColor.GREEN + " to claim it.");
                        }
                        if (giftMsg != null && !giftMsg.isEmpty())
                            recipient.sendMessage(ChatColor.GRAY + "\u201c" + giftMsg + "\u201d");
                    }
                    // Notify online staff if gift needs review
                    if (needsReview) {
                        String staffMsg = ChatColor.GOLD + "[Store] " + ChatColor.WHITE
                                + player.getName() + ChatColor.YELLOW + " sent a high-value gift ("
                                + ChatColor.GREEN + unitPrice + " coins"
                                + ChatColor.YELLOW + ") to " + ChatColor.WHITE + giftName
                                + ChatColor.YELLOW + ". Use " + ChatColor.WHITE + "/gifts " + giftName
                                + ChatColor.YELLOW + " to review.";
                        for (org.bukkit.entity.Player staff : org.bukkit.Bukkit.getOnlinePlayers())
                            if (staff.hasPermission("store.admin")) staff.sendMessage(staffMsg);
                    }
                }
            } else if (item instanceof ShopProduct) {
                ShopProduct sp = (ShopProduct) item;
                if (sp.isSubscription()) {
                    // Global kill-switch
                    if (!dev.fcvsb.store.StoreConfig.isSubscriptionsEnabled()) {
                        grantTarget.sendMessage(org.bukkit.ChatColor.RED + "✗ Memberships are currently disabled.");
                        continue;
                    }
                    // Already active?
                    if (SubscriptionManager.hasActiveSub(grantTarget.getUniqueId(), sp.getId())) {
                        grantTarget.sendMessage(org.bukkit.ChatColor.RED + "✗ You already have an active "
                                + org.bukkit.ChatColor.WHITE + ShopProduct.cleanDisplayName(sp.getDisplayName())
                                + org.bukkit.ChatColor.RED + " membership!");
                        continue;
                    }
                    // Activate membership — commands run inside create()
                    SubscriptionManager.create(
                            grantTarget.getUniqueId(), grantTarget.getName(),
                            sp.getId(), ShopProduct.cleanDisplayName(sp.getDisplayName()),
                            sp.getSubDurationMs(),
                            sp.getCommands());
                    // Schedule expire-commands map for tick
                    dev.fcvsb.store.storage.DataStorage.saveSubscriptions();
                    grantTarget.sendMessage(
                            org.bukkit.ChatColor.GOLD + "✔ " + org.bukkit.ChatColor.WHITE
                            + ShopProduct.cleanDisplayName(sp.getDisplayName())
                            + org.bukkit.ChatColor.GREEN + " membership activated! Duration: "
                            + org.bukkit.ChatColor.YELLOW
                            + formatDuration(sp.getSubDurationMs()));
                } else {
                    for (int i = 0; i < qty; i++) {
                        for (String cmd : sp.getCommands()) {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                                    cmd.replace("<player>", grantTarget.getName()));
                        }
                    }
                }
            } else {
                item.grant(grantTarget);
            }

            // If this product is a rank, update the player's rank in RankManager
            if (item instanceof dev.fcvsb.store.shop.ShopProduct) {
                dev.fcvsb.store.shop.ShopProduct sp = (dev.fcvsb.store.shop.ShopProduct) item;
                if (sp.isRankProduct()) {
                    dev.fcvsb.store.rank.RankManager.setRank(grantTarget.getUniqueId(), sp.getId());
                    dev.fcvsb.store.storage.DataStorage.savePlayer(grantTarget.getUniqueId(), data);
                }
            }

            // Track purchase count for one-time/max-stack enforcement
            data.incrementPurchaseCount(item.getId(), qty);

            // Price breakdown for log
            int basePrice         = item.getPrice(player) * qty;
            int saleSaving        = item.getDiscount(player) * qty;
            int afterSaleItem     = basePrice - saleSaving;
            int itemCouponDisc    = 0;
            if (couponSavings > 0 && cartTotal > 0)
                itemCouponDisc = (int) Math.round((double) couponSavings * afterSaleItem / cartTotal);

            int itemGiftFee = 0;
            if (isGift && item.isGiftable() && StoreConfig.isGiftFeeEnabled()) {
                int feePct = item.getGiftFeePercent() >= 0 ? item.getGiftFeePercent() : StoreConfig.getGlobalGiftFee();
                itemGiftFee = (int) Math.ceil((afterSaleItem - itemCouponDisc) * feePct / 100.0);
            }

            int itemFinalPaid = afterSaleItem - itemCouponDisc + itemGiftFee;

            PurchaseLogger.record(player.getUniqueId(),
                    new PurchaseLog(
                            player.getName(),
                            ShopProduct.cleanDisplayName(item.getDisplayName()),
                            item.getCategory(),
                            basePrice, saleSaving,
                            couponCode, itemCouponDisc,
                            itemFinalPaid,
                            isGift ? giftName : null,
                            itemGiftFee
                    ));

            // Broadcast
            if (StoreConfig.isBroadcast()) {
                String msg;
                if (isGift) {
                    msg = ChatColor.translateAlternateColorCodes('&',
                            StoreConfig.getGiftBroadcastMessage()
                                    .replace("<buyer>",     player.getName())
                                    .replace("<recipient>", grantTarget.getName())
                                    .replace("<item>",      ShopProduct.cleanDisplayName(item.getDisplayName()))
                                    .replace("<amount>",    String.valueOf(qty)));
                } else {
                    msg = item.getBroadcastMessage(player, qty);
                }
                if (msg != null) StoreBroadcastQueue.queue(msg);
            }
        }

        if (isGift)
            player.sendMessage(ChatColor.GREEN + "▸ Gift sent! " + ChatColor.WHITE
                    + giftName + ChatColor.GREEN + " can claim it with " + ChatColor.WHITE + "/gifts");

        cart.clear(); // also clears gift target
        DataStorage.savePlayer(player.getUniqueId(), data);
        DataStorage.saveCoupons();
        DataStorage.saveWishlists();
        DataStorage.saveLogs();
        playSound(player, StoreConfig.getSoundSuccess());
        if (StoreConfig.isFireworks()) launchFirework(player.getLocation());
        if (StoreConfig.isPurchaseExplosionEnabled() && finalTotal >= StoreConfig.getPurchaseExplosionThreshold())
            spawnPurchaseExplosion(player);

        // Run purchase commands if enabled
        if (StoreConfig.isPurchaseCommandsEnabled()) {
            String mode = StoreConfig.getPurchaseCommandMode();
            boolean trigger = mode.equalsIgnoreCase("always")
                    || (mode.equalsIgnoreCase("threshold")
                        && finalTotal >= StoreConfig.getPurchaseCommandThreshold());
            if (trigger) {
                boolean asConsole = !StoreConfig.getPurchaseCommandExecutor().equalsIgnoreCase("player");
                for (String cmd : StoreConfig.getPurchaseCommands()) {
                    String parsed = cmd
                            .replace("<player>", player.getName())
                            .replace("<total>",  String.valueOf(finalTotal));
                    if (asConsole) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), parsed);
                    } else {
                        player.performCommand(parsed);
                    }
                }
            }
        }
        player.sendMessage(Lang.get("purchase_success", "%coins%", data.getCoins()));
    }

    public static void playSound(Player player, String soundName) {
        if (soundName == null || soundName.isEmpty()) return;
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase().replace(".", "_"));
            player.playSound(player.getLocation(), sound, 1f, 1f);
        } catch (IllegalArgumentException ignored) {}
    }

    /**
     * Visual-only explosion: colored smoke + large fireball particles around the player.
     * No damage, no block destruction — purely cosmetic.
     */
    private static void spawnPurchaseExplosion(Player player) {
        Location loc = player.getLocation();

        // Play explosion sound (low pitch so it sounds "womp" not deadly)
        try { player.playSound(loc, Sound.EXPLODE, 0.8f, 0.6f); } catch (Exception ignored) {}

        // Schedule a burst of colored smoke rings over 30 ticks
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (!player.isOnline() || tick >= 6) { cancel(); return; }
                double radius = 1.5 + tick * 0.3;
                int points = 12;
                for (int i = 0; i < points; i++) {
                    double angle = 2 * Math.PI * i / points;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Location ring = loc.clone().add(x, 0.5 + tick * 0.2, z);
                    // SMOKE_LARGE effect (id 2000, data 0)
                    ring.getWorld().playEffect(ring, Effect.SMOKE, 4); // 4 = up direction
                }
                // Spawn a few random sparks using FIREWORKS_SPARK at center
                loc.getWorld().playEffect(loc.clone().add(0, 1, 0), Effect.MOBSPAWNER_FLAMES, 0);
                tick++;
            }
        }.runTaskTimer(StorePlugin.getInstance(), 0L, 5L);

        // Also launch 3 small fireworks around the player for extra flair
        for (int i = 0; i < 3; i++) {
            double angle = 2 * Math.PI * i / 3;
            Location fwLoc = loc.clone().add(Math.cos(angle), 0, Math.sin(angle));
            final Location fl = fwLoc;
            Bukkit.getScheduler().runTaskLater(StorePlugin.getInstance(), () -> {
                Firework fw = fl.getWorld().spawn(fl, Firework.class);
                FireworkMeta meta = fw.getFireworkMeta();
                Color[] cols = {Color.YELLOW, Color.ORANGE, Color.AQUA, Color.LIME, Color.FUCHSIA};
                meta.addEffect(FireworkEffect.builder()
                        .with(FireworkEffect.Type.STAR)
                        .withColor(cols[RNG.nextInt(cols.length)], cols[RNG.nextInt(cols.length)])
                        .withFade(Color.WHITE).withFlicker().build());
                meta.setPower(0);
                fw.setFireworkMeta(meta);
            }, i * 4L);
        }
    }

    private static String formatDuration(long ms) {
        long s = ms/1000, m = s/60, h = m/60, d = h/24;
        if (d > 0) return d + " day" + (d==1?"":"s");
        if (h > 0) return h + " hour" + (h==1?"":"s");
        if (m > 0) return m + " minute" + (m==1?"":"s");
        return s + "s";
    }

    private static void launchFirework(Location loc) {
        Firework fw = loc.getWorld().spawn(loc, Firework.class);
        FireworkMeta meta = fw.getFireworkMeta();
        Color[] colors = {Color.fromRGB(255, 170, 0), Color.YELLOW, Color.ORANGE, Color.RED, Color.AQUA, Color.LIME};
        meta.addEffect(FireworkEffect.builder()
                .with(FireworkEffect.Type.BALL_LARGE)
                .withColor(colors[RNG.nextInt(colors.length)], colors[RNG.nextInt(colors.length)])
                .withFade(Color.WHITE).withTrail().build());
        meta.setPower(1);
        fw.setFireworkMeta(meta);
    }
}
