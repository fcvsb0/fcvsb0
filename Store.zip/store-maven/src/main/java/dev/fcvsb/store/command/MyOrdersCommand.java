package dev.fcvsb.store.command;

import dev.fcvsb.store.menu.MyOrdersMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MyOrdersCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage("\u00a7cPlayers only."); return true; }
        new MyOrdersMenu().open((Player) sender);
        return true;
    }
}
