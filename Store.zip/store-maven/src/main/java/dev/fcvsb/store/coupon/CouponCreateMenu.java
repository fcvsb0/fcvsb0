package dev.fcvsb.store.coupon;

import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

/** /coupon create — step by step menu */
public class CouponCreateMenu extends Menu {

    private String code           = "";    // empty = auto-generate
    private int    discountPct    = 0;
    private String expiry         = "never";
    private int    maxUses        = 0;     // 0 = unlimited (total)
    private int    playerMaxUses  = 0;     // 0 = unlimited (per player)

    @Override public String title(Player p) { return "\u00a78[\u00a7bCoupon\u00a78] \u00a7fCreate Coupon"; }
    @Override public int    size (Player p) { return 45; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 45);

        // Code
        b.put(10, ItemBuilder.of(Material.NAME_TAG)
                .name("&b&lCoupon Code")
                .lore("&7Current: &f" + (code.isEmpty() ? "&7(auto-generate)" : code),
                      " ", "&eClick to set custom code").build());

        // Discount
        b.put(12, ItemBuilder.of(Material.GOLD_INGOT)
                .name("&6&lDiscount %")
                .lore("&7Current: &f" + (discountPct > 0 ? discountPct + "%" : "&cNot set"),
                      " ", "&eClick to set (1-99)").build());

        // Expiry
        b.put(14, ItemBuilder.of(Material.WATCH)
                .name("&e&lExpiry")
                .lore("&7Current: &f" + expiry,
                      " ", "&7Format: 1d, 2h, 30m, never",
                      "&eClick to set").build());

        // Max uses (total)
        b.put(16, ItemBuilder.of(Material.PAPER)
                .name("&a&lMax Uses &7(total)")
                .lore("&7Current: &f" + (maxUses == 0 ? "Unlimited" : String.valueOf(maxUses)),
                      " ", "&7Max times this coupon can be used globally.",
                      "&7(0 = unlimited)",
                      "&eClick to set").build());

        // Player max uses (per player)
        b.put(20, ItemBuilder.of(Material.SKULL_ITEM)
                .name("&d&lPlayer Max Uses")
                .lore("&7Current: &f" + (playerMaxUses == 0 ? "Unlimited" : String.valueOf(playerMaxUses)),
                      " ", "&7Max times one player can use this coupon.",
                      "&7(0 = unlimited)",
                      "&eClick to set").build());

        // Confirm
        boolean ready = discountPct > 0;
        b.put(31, ready
                ? ItemBuilder.of(Material.WOOL, (short) 5)
                        .name("&a&l\u2714 Create Coupon")
                        .lore("&7Code: &f" + (code.isEmpty() ? "(auto)" : code),
                              "&7Discount: &f" + discountPct + "%",
                              "&7Expiry: &f" + expiry,
                              "&7Max uses: &f" + (maxUses == 0 ? "Unlimited" : maxUses),
                              "&7Per-player max: &f" + (playerMaxUses == 0 ? "Unlimited" : playerMaxUses),
                              " ", "&aClick to confirm").build()
                : ItemBuilder.of(Material.WOOL, (short) 14)
                        .name("&c&l\u2718 Cannot Create")
                        .lore("&7Set a discount percentage first.").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        switch (slot) {
            case 10:
                EditorSession.start(p, "Enter coupon code (leave blank for auto)", this, input -> {
                    code = input.equalsIgnoreCase("blank") || input.isEmpty() ? "" : input.toUpperCase();
                    open(p);
                }); break;

            case 12:
                EditorSession.start(p, "Enter discount percentage (1-99)", this, input -> {
                    try {
                        int v = Integer.parseInt(input);
                        if (v < 1 || v > 99) { p.sendMessage("\u00a7cMust be 1-99."); open(p); return; }
                        discountPct = v; open(p);
                    } catch (NumberFormatException e) { p.sendMessage("\u00a7cInvalid number."); open(p); }
                }); break;

            case 14:
                EditorSession.start(p, "Enter expiry (1d, 2h, 30m, never)", this, input -> {
                    long exp = parseExpiry(input);
                    if (exp == -1 && !input.equalsIgnoreCase("never")) { p.sendMessage("\u00a7cInvalid format."); open(p); return; }
                    expiry = input.toLowerCase(); open(p);
                }); break;

            case 16:
                EditorSession.start(p, "Enter total max uses (0 = unlimited)", this, input -> {
                    try {
                        maxUses = Math.max(0, Integer.parseInt(input)); open(p);
                    } catch (NumberFormatException e) { p.sendMessage("\u00a7cInvalid number."); open(p); }
                }); break;

            case 20:
                EditorSession.start(p, "Enter per-player max uses (0 = unlimited)", this, input -> {
                    try {
                        playerMaxUses = Math.max(0, Integer.parseInt(input)); open(p);
                    } catch (NumberFormatException e) { p.sendMessage("\u00a7cInvalid number."); open(p); }
                }); break;

            case 31:
                if (discountPct <= 0) return;
                String finalCode = code.isEmpty() ? CouponManager.generateCode(8) : code;
                if (CouponManager.get(finalCode) != null) { p.sendMessage("\u00a7cCode already exists."); return; }
                long expireAt = parseExpiry(expiry);
                Coupon coupon = CouponManager.create(finalCode, discountPct, expireAt, maxUses, playerMaxUses);
                DataStorage.saveCoupons();
                p.sendMessage("\u00a7a\u2714 Coupon \u00a7f" + coupon.getCode() + "\u00a7a created! ("
                        + discountPct + "% off, expiry: " + expiry
                        + (playerMaxUses > 0 ? ", max " + playerMaxUses + "/player" : "") + ")");
                p.closeInventory();
                break;
        }
    }

    private static long parseExpiry(String s) {
        if (s == null || s.equalsIgnoreCase("never") || s.equalsIgnoreCase("0")) return 0L;
        try {
            char unit = s.charAt(s.length() - 1);
            long val  = Long.parseLong(s.substring(0, s.length() - 1).trim());
            long ms;
            switch (unit) {
                case 'd': ms = val * 86400_000L; break;
                case 'h': ms = val * 3600_000L;  break;
                case 'm': ms = val * 60_000L;    break;
                case 's': ms = val * 1000L;      break;
                default:  return -1L;
            }
            return System.currentTimeMillis() + ms;
        } catch (Exception e) { return -1L; }
    }
}
