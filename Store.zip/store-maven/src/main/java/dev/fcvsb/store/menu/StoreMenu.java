package dev.fcvsb.store.menu;

import dev.fcvsb.store.Lang;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.daily.DailyDeal;
import dev.fcvsb.store.daily.DailyDealManager;
import dev.fcvsb.store.daily.DailyDealsMenu;
import dev.fcvsb.store.rank.RankManager;
import dev.fcvsb.store.rank.RanksMenu;
import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Main store menu — 6 rows (54 slots).
 *
 *  Slot 41 → Cart     Slot 39 → Gift
 *  Slot 20 → Gkits    Slot 22 → Crates    Slot 24 → Tags
 */
public class StoreMenu extends Menu {

    private static final int SLOT_CART = 41;
    private static final int SLOT_GIFT  = 39;
    private int getDealsSlot() { return StoreConfig.isDailyDealsEnabled() ? StoreConfig.getDailyDealSlot() : -1; }
    private int getRanksSlot()  { return StoreConfig.isRanksEnabled()      ? StoreConfig.getRanksSlot()     : -1; }

    private final StoreCart cart;
    private final Map<Integer, ShopCategory> shopSlots = new HashMap<>();

    public StoreMenu(StoreCart cart) { this.cart = cart; }

    @Override
    protected void onOpened(Player p) {
        if (StoreConfig.isDailyDealsEnabled()) DailyDealsMenu.startGlobalClock();
    }

    @Override
    public String title(Player p) {
        String base = StoreConfig.getMenuName();
        return cart.hasGiftTarget()
                ? base + " \u00a78| \u00a7aGift for \u00a7f" + cart.getGiftTargetName()
                : base;
    }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        shopSlots.clear();
        Map<Integer, ItemStack> b = new HashMap<>();

        // Colored border first, then fill rest black
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        b.put(SLOT_CART, CartHelper.buildCartItem(p, cart));
        b.put(SLOT_GIFT, buildGiftButton(p));

        // Daily deals slot
        if (StoreConfig.isDailyDealsEnabled() && getDealsSlot() >= 0 && getDealsSlot() < 54)
            b.put(getDealsSlot(), buildDealsButton());

        // Ranks slot
        if (StoreConfig.isRanksEnabled() && getRanksSlot() >= 0 && getRanksSlot() < 54)
            b.put(getRanksSlot(), buildRanksButton(p));

        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            int slot = cat.getSlot();
            if (slot < 0 || slot >= 54 || slot == SLOT_CART || slot == SLOT_GIFT || slot == getDealsSlot() || slot == getRanksSlot()) continue;
            b.put(slot, buildShopIcon(cat));
            shopSlots.put(slot, cat);
        }
        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean rightClick) {
        if (slot == SLOT_CART) {
            CartHelper.handleCartClick(p, cart, this, rightClick);
            return;
        }
        if (slot == SLOT_GIFT) {
            if (rightClick && cart.hasGiftTarget()) {
                String was = cart.getGiftTargetName();
                cart.clearGiftTarget();
                p.sendMessage(Lang.get("gift_cancelled", "%recipient%", was));
                refresh(p);
            } else {
                promptGiftTarget(p);
            }
            return;
        }
        if (StoreConfig.isDailyDealsEnabled() && slot == getDealsSlot()) {
            new dev.fcvsb.store.daily.DailyDealsMenu(cart, this).open(p);
            return;
        }
        if (StoreConfig.isRanksEnabled() && slot == getRanksSlot()) {
            new RanksMenu(cart, this).open(p);
            return;
        }
        ShopCategory cat = shopSlots.get(slot);
        if (cat != null) new ShopCategoryMenu(cat, cart, this).open(p);
    }

    // ── Gift button ───────────────────────────────────────────────────────

    private void promptGiftTarget(Player p) {
        EditorSession.start(p, "Enter the name of the player you want to gift to", this, input -> {
            String targetName = input.trim();
            Player target = Bukkit.getPlayerExact(targetName);
            if (target == null) {
                p.sendMessage(Lang.get("gift_offline", "%player%", targetName));
                open(p); return;
            }
            if (target.equals(p)) {
                p.sendMessage(Lang.get("gift_self"));
                open(p); return;
            }
            cart.setGiftTarget(target.getUniqueId(), target.getName());
            p.sendMessage(Lang.get("gift_activated", "%recipient%", target.getName()));
            if (StoreConfig.isGiftFeeEnabled())
                p.sendMessage(Lang.get("gift_fee_notice", "%fee%", StoreConfig.getGlobalGiftFee()));
            p.sendMessage(Lang.get("gift_only_giftable"));
            open(p);
        });
    }

    private ItemStack buildGiftButton(Player p) {
        if (cart.hasGiftTarget()) {
            int giftFee = cart.getGiftFeeTotal(p);
            List<String> lore = new ArrayList<>();
            lore.add("&aGifting to: &f" + cart.getGiftTargetName());
            if (StoreConfig.isGiftFeeEnabled())
                lore.add("&7Gift fee: &6+" + StoreConfig.getGlobalGiftFee() + "% &7on giftable items");
            if (cart.getSize() > 0 && giftFee > 0)
                lore.add("&7Current fee: &6+" + giftFee + " coins");
            lore.add(" ");
            lore.add("&eLeft-click &7to change recipient");
            lore.add("&cRight-click &7to cancel gift mode");
            return ItemBuilder.of(Material.NETHER_STAR).name("&a&l\u25b8 Gift Mode: ON").lore(lore).build();
        }
        return ItemBuilder.of(Material.NETHER_STAR)
                .name("&e&l\u25b8 Send a Gift")
                .lore("&7Want to buy something for a friend?",
                      " ",
                      "&eClick &7and enter the player's name.",
                      "&7They must be &aonline &7to receive gifts.",
                      " ",
                      "&8Only items marked as giftable can be sent.").build();
    }

    private ItemStack buildRanksButton(Player p) {
        dev.fcvsb.store.shop.ShopProduct current = RankManager.getCurrentRank(p.getUniqueId());
        dev.fcvsb.store.shop.ShopProduct next    = RankManager.getNextRank(p.getUniqueId());
        List<String> lore = new java.util.ArrayList<>();
        lore.add("&7Your rank: " + (current != null
                ? org.bukkit.ChatColor.translateAlternateColorCodes('&', current.getDisplayName())
                : "&7None"));
        if (next != null) {
            lore.add("&7Next rank: " + org.bukkit.ChatColor.translateAlternateColorCodes('&', next.getDisplayName()));
            lore.add("&7Price: &e" + next.getPrice(p) + " coins");
        } else {
            lore.add("&a\u2605 Maximum rank reached!");
        }
        lore.add(" ");
        lore.add("&eClick to view ranks!");
        return ItemBuilder.of(Material.NETHER_STAR)
                .name("&6&l\u2605 Rank Upgrades")
                .lore(lore).build();
    }

    private ItemStack buildDealsButton() {
        java.util.List<DailyDeal> deals = new java.util.ArrayList<>(DailyDealManager.getActive());
        java.util.List<String> lore = new java.util.ArrayList<>();
        lore.add("&7Resets in: &e" + DailyDealManager.getCountdown());
        lore.add(" ");
        if (deals.isEmpty()) {
            lore.add("&8No deals available right now.");
        } else {
            for (DailyDeal d : deals) {
                dev.fcvsb.store.shop.ShopProduct sp = findProduct(d.getProductId());
                String name = sp != null ? dev.fcvsb.store.shop.ShopProduct.cleanDisplayName(sp.getDisplayName()) : d.getProductId();
                lore.add("&a" + name + " &7— &c-" + d.getDiscountPct() + "% &7(" + d.getDealPrice() + " coins)");
            }
        }
        lore.add(" ");
        lore.add("&eClick to view deals!");
        return dev.fcvsb.store.util.ItemBuilder.of(Material.NETHER_STAR)
                .name("&6&l★ Daily Deals")
                .lore(lore).build();
    }

    private dev.fcvsb.store.shop.ShopProduct findProduct(String id) {
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (dev.fcvsb.store.shop.ShopProduct sp : cat.getProducts().values())
                if (sp.getId().equals(id)) return sp;
            for (dev.fcvsb.store.shop.ShopSubCategory sub : cat.getSubCategories().values())
                for (dev.fcvsb.store.shop.ShopProduct sp : sub.getProducts().values())
                    if (sp.getId().equals(id)) return sp;
        }
        return null;
    }

    private ItemStack buildShopIcon(ShopCategory cat) {
        List<String> lore = new ArrayList<>(cat.getLore());
        if (lore.isEmpty()) lore.add("&eClick to view");
        return ItemBuilder.of(cat.getMaterial(), cat.getMaterialData())
                .name(cat.getName()).lore(lore).build();
    }
}
