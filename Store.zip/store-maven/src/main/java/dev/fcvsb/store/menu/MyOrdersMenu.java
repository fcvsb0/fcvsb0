package dev.fcvsb.store.menu;

import dev.fcvsb.store.log.PurchaseLog;
import dev.fcvsb.store.log.PurchaseLogger;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class MyOrdersMenu extends Menu {

    private static final int PAGE_SIZE = 28;
    private int page;

    public MyOrdersMenu()           { this.page = 0; }
    public MyOrdersMenu(int page)   { this.page = page; }

    @Override public String title(Player p) { return "\u00a78\u00bb \u00a76My Orders"; }
    @Override public int size(Player p)     { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        List<PurchaseLog> logs = PurchaseLogger.getForPlayer(p.getUniqueId());
        int total = (int) Math.ceil(Math.max(1, logs.size()) / (double) PAGE_SIZE);
        int start = page * PAGE_SIZE;

        if (logs.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.PAPER)
                    .name("&7No orders yet")
                    .lore("&7You haven't purchased anything yet.").build());
        } else {
            // Inner area: rows 1-4, cols 1-7 (slots 10-16, 19-25, 28-34, 37-43)
            int[] slots = buildInnerSlots();
            int idx = 0;
            for (int i = start; i < Math.min(start + PAGE_SIZE, logs.size()) && idx < slots.length; i++, idx++) {
                b.put(slots[idx], buildOrderItem(logs.get(i)));
            }
        }

        // Summary slot
        int totalSpent = PurchaseLogger.totalSpentBy(p.getUniqueId());
        b.put(49, ItemBuilder.of(Material.GOLD_INGOT)
                .name("&6&lOrder Summary")
                .lore("&7Total orders: &f" + logs.size(),
                      "&7Total spent:  &f" + totalSpent + " coins",
                      "&7Page: &f" + (page + 1) + " / " + total).build());

        // Navigation
        if (page > 0)
            b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total - 1)
            b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        List<PurchaseLog> logs = PurchaseLogger.getForPlayer(p.getUniqueId());
        int total = (int) Math.ceil(Math.max(1, logs.size()) / (double) PAGE_SIZE);
        if (slot == 45 && page > 0)        new MyOrdersMenu(page - 1).open(p);
        if (slot == 53 && page < total - 1) new MyOrdersMenu(page + 1).open(p);
    }

    private ItemStack buildOrderItem(PurchaseLog log) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Date:      &f" + log.getFormattedDate());
        lore.add("&7Category:  &f" + log.getCategory());
        lore.add("&7Paid:      &f" + log.getFinalPaid() + " coins");
        if (log.hadSale())
            lore.add("&a  \u25b8 Sale saved: &f" + log.getSaleDiscount() + " coins");
        if (log.hadCoupon())
            lore.add("&a  \u25b8 Coupon [" + log.getCouponCode() + "]: &f-" + log.getCouponDiscount() + " coins");
        if (log.isGift())
            lore.add("&d  \u25b8 Gifted to: &f" + log.getGiftRecipient());
        return ItemBuilder.of(Material.PAPER).name("&f" + log.getItemName()).lore(lore).build();
    }

    private int[] buildInnerSlots() {
        int[] slots = new int[PAGE_SIZE];
        int idx = 0;
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++)
                slots[idx++] = row * 9 + col;
        return slots;
    }
}
