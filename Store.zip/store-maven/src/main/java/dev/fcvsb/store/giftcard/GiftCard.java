package dev.fcvsb.store.giftcard;

import java.util.UUID;

public class GiftCard {

    private final String id;
    private final UUID   createdBy;
    private final UUID   owner;
    private final String reason;
    private final int    coins;
    private final long   expireAt;
    private       UUID   redeemedBy;

    public GiftCard(String id, UUID createdBy, UUID owner, String reason, int coins, long expireAt) {
        this.id        = id;
        this.createdBy = createdBy;
        this.owner     = owner;
        this.reason    = reason;
        this.coins     = coins;
        this.expireAt  = expireAt;
    }

    public String getId()         { return id; }
    public UUID   getCreatedBy()  { return createdBy; }
    public UUID   getOwner()      { return owner; }
    public String getReason()     { return reason; }
    public int    getCoins()      { return coins; }
    public long   getExpireAt()   { return expireAt; }
    public UUID   getRedeemedBy() { return redeemedBy; }

    public boolean isRedeemed() { return redeemedBy != null; }
    public boolean isExpired()  { return expireAt > 0 && System.currentTimeMillis() > expireAt; }
    public boolean isValid()    { return !isRedeemed() && !isExpired(); }

    public void redeem(UUID player) { this.redeemedBy = player; }

    public String formatExpiry() {
        if (expireAt == 0) return "Never";
        long remaining = expireAt - System.currentTimeMillis();
        if (remaining <= 0) return "Expired";
        long s = remaining / 1000, m = s / 60, h = m / 60, d = h / 24;
        if (d > 0) return d + "d " + (h % 24) + "h";
        if (h > 0) return h + "h " + (m % 60) + "m";
        if (m > 0) return m + "m " + (s % 60) + "s";
        return s + "s";
    }
}
