package dev.fcvsb.store;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerData {

    private static final Map<UUID, PlayerData> cache = new HashMap<>();

    private int coins;
    private final Map<String, Integer> purchaseCounts = new HashMap<>();

    private PlayerData() {
        this.coins = 5000;
    }

    public static PlayerData get(UUID uuid) {
        return cache.computeIfAbsent(uuid, k -> new PlayerData());
    }

    // ── Coins ─────────────────────────────────────────────────────────────
    public int  getCoins()               { return coins; }
    public void setCoins(int coins)      { this.coins = Math.max(0, coins); }
    public void addCoins(int amount)     { this.coins += amount; }
    public boolean takeCoins(int amount) {
        if (coins < amount) return false;
        coins -= amount;
        return true;
    }

    // ── Purchase counts ───────────────────────────────────────────────────
    public int  getPurchaseCount(String itemId)      { return purchaseCounts.getOrDefault(itemId, 0); }
    public void incrementPurchaseCount(String itemId){ purchaseCounts.merge(itemId, 1, Integer::sum); }
    public void incrementPurchaseCount(String itemId, int qty) { purchaseCounts.merge(itemId, qty, Integer::sum); }
    public java.util.Map<String, Integer> getPurchaseCounts() { return purchaseCounts; }

    public static java.util.Map<UUID, PlayerData> getAll() { return cache; }
}
