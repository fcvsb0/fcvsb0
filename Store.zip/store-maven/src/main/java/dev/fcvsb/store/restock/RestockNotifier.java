package dev.fcvsb.store.restock;
import dev.fcvsb.store.storage.DataStorage;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Players can subscribe to restock alerts for out-of-stock items.
 * When stock is replenished, all subscribers are notified.
 */
public class RestockNotifier {

    // itemId -> set of subscribed UUIDs
    private static final Map<String, Set<UUID>> SUBS = new HashMap<>();

    public static boolean toggle(UUID uuid, String itemId) {
        Set<UUID> subs = SUBS.computeIfAbsent(itemId, k -> new HashSet<>());
        if (subs.contains(uuid)) { subs.remove(uuid); DataStorage.saveRestockSubs(); return false; }
        else                     { subs.add(uuid);    DataStorage.saveRestockSubs(); return true;  }
    }

    public static boolean isSubscribed(UUID uuid, String itemId) {
        return SUBS.getOrDefault(itemId, Collections.emptySet()).contains(uuid);
    }

    /**
     * Call this when an item's stock goes from 0 to > 0.
     * Notifies all subscribers and clears the list.
     */
    public static void notifyRestock(String itemId, String itemName, int newStock) {
        Set<UUID> subs = SUBS.remove(itemId);
        DataStorage.saveRestockSubs();
        if (subs == null || subs.isEmpty()) return;
        String msg = ChatColor.GOLD + "\u25b8 " + ChatColor.WHITE + itemName
                + ChatColor.GREEN + " is back in stock! "
                + ChatColor.GRAY + "(" + newStock + " available) "
                + ChatColor.YELLOW + "Use /store to buy it.";
        for (UUID uuid : subs) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
    }

    public static Map<String, Set<UUID>> getAll() { return SUBS; }

    public static void loadAll(Map<String, Set<UUID>> data) {
        SUBS.clear();
        SUBS.putAll(data);
    }
}
