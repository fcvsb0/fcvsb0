package dev.fcvsb.store;

import org.bukkit.ChatColor;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Central language manager.
 *
 * Reads language.yml with a simple line-by-line parser instead of SnakeYAML,
 * so emoji / high-codepoint characters in values never crash Spigot 1.8.8.
 */
public class Lang {

    private static File                file;
    private static Map<String, String> messages = new HashMap<>();
    private static final Logger        LOG      = Logger.getLogger("Store");

    // ── Init ──────────────────────────────────────────────────────────────

    public static void init(StorePlugin plugin) {
        file = new File(plugin.getDataFolder(), "language.yml");
        if (!file.exists()) writeDefaults();
        load();
    }

    public static void reload() { load(); }

    // ── API ───────────────────────────────────────────────────────────────

    public static String get(String key, Object... replacements) {
        String raw = messages.getOrDefault(key, "&c[Missing lang key: " + key + "]");
        String msg = color(raw);
        for (int i = 0; i + 1 < replacements.length; i += 2)
            msg = msg.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
        return msg;
    }

    public static String prefix() { return get("prefix"); }

    // ── Simple line-by-line loader (no SnakeYAML) ─────────────────────────

    private static void load() {
        messages.clear();
        try {
            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            for (String line : lines) {
                // Skip comments and blank lines
                String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;

                int colon = line.indexOf(':');
                if (colon < 0) continue;

                String key   = line.substring(0, colon).trim();
                String value = line.substring(colon + 1).trim();

                // Strip surrounding quotes if present
                if (value.startsWith("\"") && value.endsWith("\"") && value.length() >= 2)
                    value = value.substring(1, value.length() - 1);
                else if (value.startsWith("'") && value.endsWith("'") && value.length() >= 2)
                    value = value.substring(1, value.length() - 1);

                // Unescape \" inside quoted strings
                value = value.replace("\\\"", "\"");

                messages.put(key, value);
            }
        } catch (IOException e) {
            LOG.severe("[Store] Failed to load language.yml: " + e.getMessage());
        }
    }

    // ── Defaults ──────────────────────────────────────────────────────────

    private static void writeDefaults() {
        String yaml =
            "# Store Plugin - Language Configuration\n" +
            "# Supports & color codes and placeholder tokens per message.\n" +
            "\n" +
            "prefix: \"&7[&6&lStore&7] \"\n" +
            "\n" +
            "# -- General --\n" +
            "no_permission:        \"&cYou don't have permission to do that.\"\n" +
            "player_not_found:     \"&cPlayer &f%player% &cis not online.\"\n" +
            "store_disabled:       \"&cThe store is currently disabled.\"\n" +
            "invalid_number:       \"&cInvalid number: &f%input%\"\n" +
            "reload_success:       \"&aStore reloaded successfully.\"\n" +
            "\n" +
            "# -- Cart --\n" +
            "cart_empty:           \"&cYour cart is empty!\"\n" +
            "cart_cleared:         \"&eCart cleared.\"\n" +
            "cart_item_added:      \"&a%item% &aadded to cart.\"\n" +
            "cart_item_removed:    \"&c%item% &cremoved from cart.\"\n" +
            "cart_item_added_gift: \"&a%item% &aadded to cart &8(Gift for &a%recipient%&8).\"\n" +
            "\n" +
            "# -- Purchase --\n" +
            "purchase_success:     \"&aPurchase complete! Remaining coins: &f%coins%\"\n" +
            "purchase_not_enough:  \"&cNot enough coins! You need &f%total% &cbut have &f%coins%\"\n" +
            "purchase_blocked:     \"&c%reason%\"\n" +
            "purchase_one_time:    \"&cThis item can only be purchased once.\"\n" +
            "purchase_limit:       \"&cPurchase limit: &f%max%&c. You already have: &f%bought%\"\n" +
            "purchase_cart_limit:  \"&cYou can only add &f%limit% &cof &f%item% &cto your cart.\"\n" +
            "purchase_out_stock:   \"&c%item% &cis out of stock!\"\n" +
            "purchase_no_stock:    \"&cNot enough stock for &f%item%&c. Available: &f%stock%\"\n" +
            "\n" +
            "# -- Broadcast --\n" +
            "broadcast_purchase:   \"&7[&6&lStore&7] &f%player% &epurchased &f%item%&e!\"\n" +
            "broadcast_gift:       \"&7[&6&lStore&7] &f%buyer% &egifted &f%item% &eto &f%recipient%&e!\"\n" +
            "\n" +
            "# -- Gift system --\n" +
            "gift_activated:       \"&a>> Gift mode activated! Browsing for: &f%recipient%\"\n" +
            "gift_fee_notice:      \"&7  A +%fee%% gift fee will be added on giftable items.\"\n" +
            "gift_only_giftable:   \"&7  Only items marked as giftable can be sent.\"\n" +
            "gift_cancelled:       \"&eGift mode cancelled. Was gifting to: &f%recipient%\"\n" +
            "gift_not_giftable:    \"&c%item% &ccannot be gifted.\"\n" +
            "gift_self:            \"&cYou cannot gift items to yourself.\"\n" +
            "gift_offline:         \"&cPlayer &f%player% &cis not online.\"\n" +
            "gift_received:        \"&6>> &f%buyer% &ahas gifted you items from the store!\"\n" +
            "gift_fee_applied:     \"&7Gift fee applied: &f%fee% &7coins.\"\n" +
            "\n" +
            "# -- Coupon system --\n" +
            "coupon_applied:       \"&aCoupon &f%code% &aapplied! (%pct%% off)\"\n" +
            "coupon_removed:       \"&eCoupon &f%code% &eremoved.\"\n" +
            "coupon_invalid:       \"&cInvalid coupon code: &f%code%\"\n" +
            "coupon_expired:       \"&cThat coupon has expired or reached its usage limit.\"\n" +
            "coupon_already_used:  \"&cYou have already used this coupon.\"\n" +
            "coupon_saved:         \"&aCoupon &f%code% &asaved you &f%amount% &acoins!\"\n" +
            "\n" +
            "# -- Sale system --\n" +
            "sale_started:         \"&aA &f%pct%% &asale has started! Use &6&l/coinshop &ato take advantage!\"\n" +
            "sale_ended:           \"&7The sale has ended.\"\n" +
            "sale_already_active:  \"&cA sale is already active.\"\n" +
            "sale_not_active:      \"&cNo active sale.\"\n" +
            "\n" +
            "# -- Coins --\n" +
            "coins_balance:        \"&7Your balance: &f%coins% &7coins.\"\n" +
            "coins_given:          \"&aGave &f%coins% &acoins to &f%player%\"\n" +
            "coins_taken:          \"&aRemoved &f%coins% &acoins from &f%player%\"\n" +
            "coins_set:            \"&aSet &f%player%'s &acoins to &f%coins%\"\n" +
            "\n";

        try {
            file.getParentFile().mkdirs();
            Files.write(file.toPath(), yaml.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            LOG.severe("[Store] Failed to write language.yml: " + e.getMessage());
        }
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }
}
