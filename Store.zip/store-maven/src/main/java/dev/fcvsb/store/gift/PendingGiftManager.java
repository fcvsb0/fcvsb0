package dev.fcvsb.store.gift;

import java.util.*;

public class PendingGiftManager {

    private static final Map<String, PendingGift> GIFTS = new LinkedHashMap<>();

    public static PendingGift create(UUID senderUUID, String senderName,
                                     UUID recipientUUID, String recipientName,
                                     String itemId, String itemName, String message,
                                     int pricePaid) {
        String id = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        PendingGift gift = new PendingGift(id, senderUUID, senderName,
                recipientUUID, recipientName, itemId, itemName,
                message, System.currentTimeMillis());
        gift.setPricePaid(pricePaid);
        GIFTS.put(id, gift);
        return gift;
    }

    public static PendingGift get(String id) { return GIFTS.get(id.toUpperCase()); }

    public static List<PendingGift> getPending(UUID recipientUUID) {
        List<PendingGift> list = new ArrayList<>();
        for (PendingGift g : GIFTS.values())
            if (!g.isClaimed() && g.getRecipientUUID().equals(recipientUUID))
                list.add(g);
        return list;
    }

    public static Map<String, PendingGift> getAll() { return GIFTS; }

    public static void loadRaw(PendingGift gift) {
        GIFTS.put(gift.getId(), gift);
    }
}
