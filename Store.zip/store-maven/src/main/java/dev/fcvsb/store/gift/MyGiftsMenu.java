package dev.fcvsb.store.gift;

import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.text.SimpleDateFormat;
import java.util.*;

public class MyGiftsMenu extends Menu {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM/dd/yyyy HH:mm");

    private final UUID   targetUUID; // null = self
    private final String targetName;

    public MyGiftsMenu() {
        this.targetUUID = null;
        this.targetName = null;
    }

    public MyGiftsMenu(UUID targetUUID, String targetName) {
        this.targetUUID = targetUUID;
        this.targetName = targetName;
    }

    private UUID resolveTarget(Player p) {
        return targetUUID != null ? targetUUID : p.getUniqueId();
    }

    @Override public String title(Player p) {
        return targetName != null
                ? "\u00a78\u00bb \u00a7d" + targetName + "'s Gifts \u00a77(OP)"
                : "\u00a78\u00bb \u00a7dMy Gifts";
    }
    @Override public int    size(Player p)  { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        List<PendingGift> gifts = PendingGiftManager.getPending(resolveTarget(p));

        if (gifts.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.EYE_OF_ENDER)
                    .name("&7No pending gifts")
                    .lore("&7You have no gifts waiting to be claimed.").build());
        } else {
            int[] slots = innerSlots();
            for (int i = 0; i < Math.min(gifts.size(), slots.length); i++) {
                b.put(slots[i], buildGiftItem(gifts.get(i)));
            }
        }

        b.put(49, ItemBuilder.of(Material.PAPER)
                .name("&d&lPending Gifts")
                .lore("&7Total: &f" + gifts.size(),
                      " ",
                      "&aClick a gift to claim it!").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        List<PendingGift> gifts = PendingGiftManager.getPending(resolveTarget(p));
        int[] slots = innerSlots();
        for (int i = 0; i < slots.length; i++) {
            if (slot != slots[i] || i >= gifts.size()) continue;
            PendingGift gift = gifts.get(i);
            // OP viewing another player's gifts — open review menu
            if (targetUUID != null && p.hasPermission("store.admin")) {
                new GiftReviewMenu(gift, this).open(p);
                return;
            }
            // Normal player — can only claim approved gifts
            if (!gift.isApproved()) {
                p.sendMessage(org.bukkit.ChatColor.YELLOW + "⏳ This gift is pending staff approval.");
                return;
            }
            claimGift(p, gift);
            return;
        }
    }

    private void claimGift(Player p, PendingGift gift) {
        // Find product and run commands
        ShopProduct sp = findProduct(gift.getItemId());
        if (sp == null) {
            p.sendMessage(ChatColor.RED + "Could not find item " + gift.getItemName() + ". Contact an admin.");
            return;
        }

        gift.setClaimed();
        sp.grant(p);
        // Persist claimed state
        dev.fcvsb.store.storage.DataStorage.saveGifts();

        p.sendMessage(ChatColor.LIGHT_PURPLE + "\u2665 " + ChatColor.WHITE + "You claimed "
                + ChatColor.YELLOW + gift.getItemName()
                + ChatColor.WHITE + " gifted by "
                + ChatColor.LIGHT_PURPLE + gift.getSenderName() + ChatColor.WHITE + "!");

        if (gift.getMessage() != null && !gift.getMessage().isEmpty()) {
            p.sendMessage(ChatColor.GRAY + "\u201c" + ChatColor.WHITE + gift.getMessage() + ChatColor.GRAY + "\u201d");
        }

        // Notify sender if online
        Player sender = Bukkit.getPlayer(gift.getSenderUUID());
        if (sender != null) {
            sender.sendMessage(ChatColor.GREEN + "\u25b8 " + ChatColor.WHITE
                    + p.getName() + ChatColor.GREEN + " claimed your gift: "
                    + ChatColor.YELLOW + gift.getItemName());
        }

        refresh(p);
    }

    private ItemStack buildGiftItem(PendingGift gift) {
        List<String> lore = new ArrayList<>();
        lore.add("&7From:   &d" + gift.getSenderName());
        lore.add("&7Item:   &f" + gift.getItemName());
        lore.add("&7Sent:   &f" + SDF.format(new Date(gift.getCreatedAt())));
        if (gift.getMessage() != null && !gift.getMessage().isEmpty()) {
            lore.add(" ");
            lore.add("&7Message: &f" + gift.getMessage());
        }
        lore.add(" ");
        if (gift.isApproved()) {
            lore.add("&aClick to claim!");
        } else {
            lore.add("&ePayment Confirmation Pending");
            lore.add("&7Waiting for staff approval.");
        }
        return ItemBuilder.of(gift.isApproved() ? Material.EYE_OF_ENDER : Material.WATCH)
                .name((gift.isApproved() ? "&d\u2665 " : "&e") + "Gift from &f" + gift.getSenderName())
                .lore(lore).build();
    }

    private ShopProduct findProduct(String id) {
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (ShopProduct sp : cat.getProducts().values())
                if (sp.getId().equals(id)) return sp;
            for (ShopSubCategory sub : cat.getSubCategories().values())
                for (ShopProduct sp : sub.getProducts().values())
                    if (sp.getId().equals(id)) return sp;
        }
        return null;
    }

    private int[] innerSlots() {
        int[] slots = new int[28];
        int idx = 0;
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++)
                slots[idx++] = row * 9 + col;
        return slots;
    }
}
