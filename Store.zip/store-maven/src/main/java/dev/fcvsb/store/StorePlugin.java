package dev.fcvsb.store;

import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.command.CoinsCommand;
import dev.fcvsb.store.command.GiftsCommand;
import dev.fcvsb.store.command.MySubsCommand;
import dev.fcvsb.store.command.DealsCommand;
import dev.fcvsb.store.daily.DailyDealManager;
import dev.fcvsb.store.rank.RankManager;
import dev.fcvsb.store.subscription.SubscriptionManager;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.giftcard.GiftCardCommand;
import dev.fcvsb.store.giftcard.GiftCardPlayerCommand;
import dev.fcvsb.store.command.MyOrdersCommand;
import dev.fcvsb.store.gift.PendingGiftManager;
import dev.fcvsb.store.command.WishlistCommand;
import dev.fcvsb.store.command.SaleCommand;
import dev.fcvsb.store.command.StoreCommand;
import dev.fcvsb.store.coupon.CouponCommand;
import dev.fcvsb.store.editor.EditorChatListener;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.shop.ShopLoader;
import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Arrays;

public class StorePlugin extends JavaPlugin {

    private static StorePlugin instance;

    @Override
    public void onEnable() {
        instance = this;

// ── Exodo License Verification ──
        if (!new java.io.File(getDataFolder(), "license.yml").exists()) {
            saveResource("license.yml", false);
        }
        org.bukkit.configuration.file.YamlConfiguration licenseCfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(), "license.yml"));
        ExodoLicense license = new ExodoLicense(
                this,
                licenseCfg.getString("license", "YOUR_LICENSE_KEY"),
                "http://40.233.108.11:3001/api/v1",
                "f90723c4121cb301437b61d6eb2928342d93de84"
        );
        if (!license.verify()) {
            getLogger().severe("Invalid license. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        DataStorage.init(this);  // MUST be first — PlayerData.get() uses it
        StoreConfig.init(this);
        Lang.init(this);
        ShopLoader.init(this);
        dev.fcvsb.store.rank.RankManager.rebuild();
        DataStorage.loadAll();

        getServer().getPluginManager().registerEvents(new Menu.MenuEvents(),    this);
        getServer().getPluginManager().registerEvents(new EditorChatListener(), this);
        getServer().getPluginManager().registerEvents(new PlayerDataListener(), this);

        // ── Register all commands dynamically (no plugin.yml commands needed) ──
        StoreCommand storeCmd = new StoreCommand();
        register("store",      storeCmd,                 "coinshop", "coin-shop", "tienda");
        register("sale",       new SaleCommand());
        register("storecoins", new CoinsCommand(), "coins");
        register("coupon",     new CouponCommand());
        register("myorders",   new MyOrdersCommand(), "mypurchases", "orders");
        register("gifts",      new GiftsCommand(), "mygifts", "claimgift");
        register("giftcard",   new GiftCardCommand(), "gc");
        register("giftcards",  new GiftCardPlayerCommand(), "mygiftcards");
        register("wishlist",   new WishlistCommand(), "wl");
        register("mysubs",    new MySubsCommand(), "mymemberships", "memberships");
        register("deals",     new DealsCommand());

        // Inject required-rank: "" into any product YAML missing it
        injectRequiredRankField();

        // Daily deals — check/roll on startup, then every 5 minutes
        if (StoreConfig.isDailyDealsEnabled()) {
            DailyDealManager.tickCheck();
            getServer().getScheduler().runTaskTimer(this, DailyDealManager::tickCheck, 6000L, 6000L);
            dev.fcvsb.store.daily.DailyDealsMenu.startGlobalClock();
        }

        // Subscription tick — check expiries every minute
        if (StoreConfig.isSubscriptionsEnabled())
        getServer().getScheduler().runTaskTimer(this, () -> {
            java.util.Map<String, java.util.List<String>> expCmds = new java.util.HashMap<>();
            for (ShopCategory cat : ShopLoader.getCategories().values()) {
                for (ShopProduct sp : cat.getProducts().values())
                    if (sp.isSubscription()) expCmds.put(sp.getId(), sp.getSubExpireCommands());
                for (ShopSubCategory sub : cat.getSubCategories().values())
                    for (ShopProduct sp : sub.getProducts().values())
                        if (sp.isSubscription()) expCmds.put(sp.getId(), sp.getSubExpireCommands());
            }
            boolean changed = false;
            long before = SubscriptionManager.getAll().stream().filter(s -> !s.isExpired()).count();
            SubscriptionManager.tick(expCmds);
            long after = SubscriptionManager.getAll().stream().filter(s -> !s.isExpired()).count();
            if (before != after) dev.fcvsb.store.storage.DataStorage.saveSubscriptions();
        }, 1200L, 1200L); // every minute

        getServer().getScheduler().runTaskTimerAsynchronously(this, new StoreBroadcastQueue(), 1L, 1L);

        org.bukkit.Bukkit.getConsoleSender().sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&8--------------------"));
        org.bukkit.Bukkit.getConsoleSender().sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&6Author: &cfcvsb"));
        org.bukkit.Bukkit.getConsoleSender().sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&6Discord: &cfcvsb_"));
        org.bukkit.Bukkit.getConsoleSender().sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&8--------------------"));
    }

    @Override
    public void onDisable() {
        dev.fcvsb.store.daily.DailyDealsMenu.stopGlobalClock();
        DataStorage.saveAll();
        getLogger().info("Store disabled — data saved.");
    }

    public static StorePlugin getInstance() { return instance; }

    // ── Dynamic command registration via SimpleCommandMap reflection ──────


    /**
     * Walks all .yml files under plugins/Store/shop/ and injects "required-rank: \"\""
     * into any file that doesn't already have that key.
     */
    private void injectRequiredRankField() {
        File shopDir = new File(getDataFolder(), "shop");
        if (!shopDir.exists()) return;
        injectInDir(shopDir);
    }

    private void injectInDir(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) { injectInDir(f); continue; }
            if (!f.getName().endsWith(".yml")) continue;
            try {
                String content = new String(java.nio.file.Files.readAllBytes(f.toPath()),
                        java.nio.charset.StandardCharsets.UTF_8);
                // Skip if already has required-rank key
                if (content.contains("required-rank:")) continue;
                // Append at end of file
                if (!content.endsWith("\n")) content += "\n";
                content += "required-rank: \"\"\n";
                java.nio.file.Files.write(f.toPath(), content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            } catch (Exception e) {
                getLogger().warning("[Store] Could not inject required-rank into " + f.getName() + ": " + e.getMessage());
            }
        }
    }

    private void register(String name, CommandExecutor executor, String... aliases) {
        try {
            // Create PluginCommand instance via its package-private constructor
            Constructor<PluginCommand> ctor =
                    PluginCommand.class.getDeclaredConstructor(String.class, Plugin.class);
            ctor.setAccessible(true);
            PluginCommand cmd = ctor.newInstance(name, this);
            cmd.setExecutor(executor);
            if (aliases.length > 0) cmd.setAliases(Arrays.asList(aliases));

            // Get the server's SimpleCommandMap via reflection
            Field mapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
            mapField.setAccessible(true);
            SimpleCommandMap commandMap = (SimpleCommandMap) mapField.get(Bukkit.getServer());
            commandMap.register(getName().toLowerCase(), cmd);

        } catch (Exception e) {
            getLogger().severe("Failed to register command /" + name + ": " + e.getMessage());
        }
    }
}
