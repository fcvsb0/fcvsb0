package dev.fcvsb.store.coupon;

import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public class CouponDeleteMenu extends Menu {

    private final Coupon coupon;
    private final Menu   back;

    public CouponDeleteMenu(Coupon coupon, Menu back) {
        this.coupon = coupon;
        this.back   = back;
    }

    @Override public String title(Player p) { return "\u00a78[\u00a7cDelete\u00a78] \u00a7fCoupon \u00a7b" + coupon.getCode(); }
    @Override public int    size (Player p) { return 27; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 27);

        b.put(11, ItemBuilder.of(Material.WOOL, (short) 5)
                .name("&a&l\u2714 Delete Coupon")
                .lore("&7Code: &f" + coupon.getCode(),
                      "&7Discount: &f" + coupon.getDiscountPct() + "%",
                      "&7Uses: &f" + coupon.getUseCount(),
                      " ", "&cThis cannot be undone.").build());

        b.put(15, ItemBuilder.of(Material.WOOL, (short) 14)
                .name("&c&l\u2718 Cancel").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        if (slot == 11) {
            CouponManager.remove(coupon.getCode());
            dev.fcvsb.store.storage.DataStorage.saveCoupons();
            p.sendMessage("\u00a7c\u2718 Coupon \u00a7f" + coupon.getCode() + "\u00a7c deleted.");
            back.open(p);
        } else if (slot == 15) {
            back.open(p);
        }
    }
}
