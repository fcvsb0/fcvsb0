package dev.fcvsb.store.util;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ItemBuilder {

    private final ItemStack item;
    private final ItemMeta  meta;

    private ItemBuilder(Material mat, int amount, short data) {
        this.item = new ItemStack(mat, amount, data);
        this.meta = item.getItemMeta();
    }

    public static ItemBuilder of(Material mat)             { return new ItemBuilder(mat, 1, (short) 0); }
    public static ItemBuilder of(Material mat, short data) { return new ItemBuilder(mat, 1, data); }

    public ItemBuilder name(String name) {
        meta.setDisplayName(color(name));
        return this;
    }

    /** Lore with & color code translation */
    public ItemBuilder lore(String... lines) {
        meta.setLore(Arrays.stream(lines).map(ItemBuilder::color).collect(Collectors.toList()));
        return this;
    }

    /** Lore with & color code translation */
    public ItemBuilder lore(List<String> lines) {
        meta.setLore(lines.stream().map(ItemBuilder::color).collect(Collectors.toList()));
        return this;
    }

    /** Lore already translated — no double-translation */
    public ItemBuilder loreRaw(List<String> lines) {
        meta.setLore(lines);
        return this;
    }

    /** Override stack size (clamped 1-64 by Minecraft) */
    public ItemBuilder amount(int amt) {
        item.setAmount(Math.max(1, Math.min(64, amt)));
        return this;
    }

    public ItemStack build() { item.setItemMeta(meta); return item; }

    public static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
}
