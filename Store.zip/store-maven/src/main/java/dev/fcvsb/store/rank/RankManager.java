package dev.fcvsb.store.rank;

import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopSubCategory;

import java.util.*;

/**
 * Builds the rank chain from ShopProducts that have rank.enabled: true.
 * Call RankManager.rebuild() after ShopLoader.load().
 */
public class RankManager {

    // Ordered chain: index 0 = first/default rank
    private static final List<ShopProduct>        CHAIN       = new ArrayList<>();
    // productId -> ShopProduct
    private static final Map<String, ShopProduct> BY_ID       = new LinkedHashMap<>();
    // uuid -> current rank product id
    private static final Map<UUID, String>         PLAYER_RANK = new HashMap<>();

    private RankManager() {}

    // ── Build chain from loaded products ─────────────────────────────────

    public static void rebuild() {
        CHAIN.clear();
        BY_ID.clear();

        // Collect all rank products
        Map<String, ShopProduct> all = new LinkedHashMap<>();
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (ShopProduct sp : cat.getProducts().values())
                if (sp.isRankProduct()) all.put(sp.getId(), sp);
            for (ShopSubCategory sub : cat.getSubCategories().values())
                for (ShopProduct sp : sub.getProducts().values())
                    if (sp.isRankProduct()) all.put(sp.getId(), sp);
        }

        if (all.isEmpty()) return;

        // Find root: not referenced as next by anyone
        Set<String> referenced = new HashSet<>();
        for (ShopProduct sp : all.values())
            if (!sp.getRankNext().isEmpty()) referenced.add(sp.getRankNext());
        String rootId = null;
        for (String id : all.keySet())
            if (!referenced.contains(id)) { rootId = id; break; }
        if (rootId == null) rootId = all.keySet().iterator().next();

        // Walk chain
        String cur = rootId;
        Set<String> visited = new HashSet<>();
        while (cur != null && !cur.isEmpty() && all.containsKey(cur) && !visited.contains(cur)) {
            ShopProduct sp = all.get(cur);
            CHAIN.add(sp);
            BY_ID.put(cur, sp);
            visited.add(cur);
            cur = sp.getRankNext();
        }
        // Orphans
        for (Map.Entry<String, ShopProduct> e : all.entrySet())
            if (!visited.contains(e.getKey())) { CHAIN.add(e.getValue()); BY_ID.put(e.getKey(), e.getValue()); }
    }

    // ── Queries ───────────────────────────────────────────────────────────

    public static List<ShopProduct>  getChain()           { return Collections.unmodifiableList(CHAIN); }
    public static ShopProduct        getById(String id)   { return id == null ? null : BY_ID.get(id); }
    public static boolean            isEnabled()          { return !CHAIN.isEmpty(); }

    /** Current rank product for player. Returns first in chain if none set. */
    public static ShopProduct getCurrentRank(UUID uuid) {
        String id = PLAYER_RANK.get(uuid);
        if (id != null && BY_ID.containsKey(id)) return BY_ID.get(id);
        return CHAIN.isEmpty() ? null : CHAIN.get(0);
    }

    public static String getCurrentRankId(UUID uuid) {
        ShopProduct sp = getCurrentRank(uuid);
        return sp == null ? "" : sp.getId();
    }

    /** Next rank the player can purchase. Null = already at top. */
    public static ShopProduct getNextRank(UUID uuid) {
        ShopProduct current = getCurrentRank(uuid);
        if (current == null || current.getRankNext().isEmpty()) return null;
        return BY_ID.get(current.getRankNext());
    }

    /** True if player owns this rank or higher. */
    public static boolean hasRank(UUID uuid, String rankId) {
        if (rankId == null || rankId.isEmpty()) return true;
        int playerIdx = indexOf(getCurrentRankId(uuid));
        int checkIdx  = indexOf(rankId);
        return checkIdx >= 0 && playerIdx >= checkIdx;
    }

    // ── Mutations ─────────────────────────────────────────────────────────

    public static void setRank(UUID uuid, String rankId)        { PLAYER_RANK.put(uuid, rankId); }
    public static void loadPlayerRank(UUID uuid, String rankId) { if (rankId != null && !rankId.isEmpty()) PLAYER_RANK.put(uuid, rankId); }
    public static String getSavedRankId(UUID uuid)              { return PLAYER_RANK.getOrDefault(uuid, ""); }

    private static int indexOf(String rankId) {
        for (int i = 0; i < CHAIN.size(); i++)
            if (CHAIN.get(i).getId().equals(rankId)) return i;
        return -1;
    }
}
