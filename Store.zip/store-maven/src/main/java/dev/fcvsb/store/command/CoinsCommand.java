package dev.fcvsb.store.command;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.storage.DataStorage;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CoinsCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        // /coins — own balance
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Usage: /coins <player>");
                return true;
            }
            Player p = (Player) sender;
            int coins = PlayerData.get(p.getUniqueId()).getCoins();
            p.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Your Coins: "
                    + ChatColor.WHITE + coins + ChatColor.YELLOW + " coins");
            return true;
        }

        // /coins <player> — check other player (OP only)
        if (args.length == 1) {
            if (!sender.isOp()) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target != null) {
                int coins = PlayerData.get(target.getUniqueId()).getCoins();
                sender.sendMessage(ChatColor.YELLOW + target.getName() + "'s coins: "
                        + ChatColor.WHITE + coins);
            } else {
                sender.sendMessage(ChatColor.RED + "Player '" + args[0] + "' is not online.");
            }
            return true;
        }

        // /coins <add|set|take> <player> <amount> — OP only
        if (args.length == 3 && sender.isOp()) {
            String action = args[0].toLowerCase();
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player '" + args[1] + "' is not online.");
                return true;
            }
            int amount;
            try {
                amount = Integer.parseInt(args[2]);
                if (amount < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "Invalid amount: " + args[2]);
                return true;
            }
            PlayerData data = PlayerData.get(target.getUniqueId());
            switch (action) {
                case "add":
                case "give":
                    data.addCoins(amount);
                    sender.sendMessage(ChatColor.GREEN + "Added " + amount + " coins to " + target.getName()
                            + " (now " + data.getCoins() + ")");
                    target.sendMessage(ChatColor.GREEN + "You received " + ChatColor.WHITE + amount
                            + ChatColor.GREEN + " coins! Balance: " + ChatColor.WHITE + data.getCoins());
                    break;
                case "take":
                case "remove":
                    data.setCoins(Math.max(0, data.getCoins() - amount));
                    sender.sendMessage(ChatColor.YELLOW + "Removed " + amount + " coins from " + target.getName()
                            + " (now " + data.getCoins() + ")");
                    break;
                case "set":
                    data.setCoins(amount);
                    sender.sendMessage(ChatColor.YELLOW + "Set " + target.getName() + "'s coins to " + amount);
                    target.sendMessage(ChatColor.YELLOW + "Your coins have been set to "
                            + ChatColor.WHITE + amount);
                    break;
                default:
                    sender.sendMessage(ChatColor.RED + "Usage: /coins <add|take|set> <player> <amount>");
            }
            DataStorage.savePlayer(target.getUniqueId(), data);
            return true;
        }

        // Usage
        if (sender.isOp()) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /coins [player] | /coins <add|take|set> <player> <amount>");
        } else {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /coins");
        }
        return true;
    }
}
