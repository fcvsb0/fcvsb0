package dev.fcvsb.store.command;

import dev.fcvsb.store.wishlist.WishlistMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WishlistCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
        Player p = (Player) sender;

        if (args.length == 0) {
            // Own wishlist
            new WishlistMenu(p).open(p);
        } else {
            // View someone else's wishlist to gift them
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                p.sendMessage(ChatColor.RED + "Player '" + args[0] + "' is not online.");
                return true;
            }
            if (target.equals(p)) { new WishlistMenu(p).open(p); return true; }
            new WishlistMenu(target.getUniqueId(), target.getName()).open(p);
        }
        return true;
    }
}
