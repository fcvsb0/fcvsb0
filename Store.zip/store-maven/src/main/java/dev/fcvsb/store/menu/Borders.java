package dev.fcvsb.store.menu;

import dev.fcvsb.store.StoreConfig;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;

public class Borders {

    public static ItemStack glass(short data) {
        ItemStack i = new ItemStack(Material.STAINED_GLASS_PANE, 1, data);
        ItemMeta  m = i.getItemMeta();
        m.setDisplayName(" ");
        i.setItemMeta(m);
        return i;
    }

    public static ItemStack black() { return glass((short) 15); }

    /** Colored border for 5-row (45-slot) menus. */
    public static Map<Integer, ItemStack> get() {
        short P = StoreConfig.getGlassPrimary();
        short S = StoreConfig.getGlassSecondary();
        ItemStack gP = glass(P), gS = glass(S);
        Map<Integer, ItemStack> b = new HashMap<>();
        // Top row
        b.put(0, gP); b.put(1, gS); b.put(2, gS); b.put(3, gS); b.put(4, gS);
        b.put(5, gS);  b.put(6, gS);  b.put(7, gS);  b.put(8, gP);
        // Side columns
        b.put(9, gS);  b.put(17, gS);
        b.put(18, gS); b.put(26, gS);
        b.put(27, gS); b.put(35, gS);
        // Bottom row
        b.put(36, gP); b.put(37, gS); b.put(38, gS); b.put(39, gS); b.put(40, gS);
        b.put(41, gS); b.put(42, gS); b.put(43, gS); b.put(44, gP);
        return b;
    }

    /** Colored border for 6-row (54-slot) menus. */
    public static Map<Integer, ItemStack> get54() {
        short P = StoreConfig.getGlassPrimary();
        short S = StoreConfig.getGlassSecondary();
        ItemStack gP = glass(P), gS = glass(S);
        Map<Integer, ItemStack> b = new HashMap<>();
        // Top row
        b.put(0, gP); b.put(1, gS); b.put(2, gS); b.put(3, gS); b.put(4, gS);
        b.put(5, gS);  b.put(6, gS);  b.put(7, gS);  b.put(8, gP);
        // Side columns rows 1-4
        b.put(9, gS);  b.put(17, gS);
        b.put(18, gS); b.put(26, gS);
        b.put(27, gS); b.put(35, gS);
        b.put(36, gS); b.put(44, gS);
        // Bottom row
        b.put(45, gP); b.put(46, gS); b.put(47, gS); b.put(48, gS); b.put(49, gS);
        b.put(50, gS); b.put(51, gS); b.put(52, gS); b.put(53, gP);
        return b;
    }

    /** Colored border for 3-row (27-slot) menus. */
    public static Map<Integer, ItemStack> get27() {
        short P = StoreConfig.getGlassPrimary();
        short S = StoreConfig.getGlassSecondary();
        ItemStack gP = glass(P), gS = glass(S);
        Map<Integer, ItemStack> b = new HashMap<>();
        // Top row
        b.put(0, gP); b.put(1, gS); b.put(2, gS); b.put(3, gS); b.put(4, gS);
        b.put(5, gS); b.put(6, gS); b.put(7, gS); b.put(8, gP);
        // Side columns
        b.put(9, gS); b.put(17, gS);
        // Bottom row
        b.put(18, gP); b.put(19, gS); b.put(20, gS); b.put(21, gS); b.put(22, gS);
        b.put(23, gS); b.put(24, gS); b.put(25, gS); b.put(26, gP);
        return b;
    }

    public static void fill(Map<Integer, ItemStack> buttons, int size) {
        if (!StoreConfig.isGlassFill()) return; // glass-fill: false → leave slots empty
        ItemStack filler = black();
        for (int i = 0; i < size; i++) buttons.putIfAbsent(i, filler);
    }

    public static ItemStack backButton() {
        ItemStack i = new ItemStack(Material.ARROW);
        ItemMeta  m = i.getItemMeta();
        m.setDisplayName("\u00a7e\u2190 Back");
        i.setItemMeta(m);
        return i;
    }
}
