package dev.fcvsb.store.giftcard;

import dev.fcvsb.store.StoreConfig;

import java.util.*;

public class GiftCardManager {

    private static final Map<String, GiftCard>       ALL      = new LinkedHashMap<>();
    private static final Map<UUID, List<GiftCard>>   BY_OWNER = new LinkedHashMap<>();

    private static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final Random RNG   = new Random();

    // ── Create ────────────────────────────────────────────────────────────

    public static GiftCard create(UUID staff, UUID targetOwner, String reason, int coins, long expireAt) {
        String id   = generateId();
        GiftCard gc = new GiftCard(id, staff, targetOwner, reason, coins, expireAt);
        ALL.put(id, gc);
        BY_OWNER.computeIfAbsent(targetOwner, k -> new ArrayList<>()).add(gc);
        return gc;
    }

    private static String generateId() {
        int len = StoreConfig.getGiftcardChars();
        String id;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < len; i++) sb.append(CHARS.charAt(RNG.nextInt(CHARS.length())));
            id = sb.toString();
        } while (ALL.containsKey(id));
        return id;
    }

    public static GiftCard createRaw(String id, UUID staff, UUID owner, String reason, int coins, long expireAt) {
        GiftCard gc = new GiftCard(id, staff, owner, reason, coins, expireAt);
        ALL.put(id.toUpperCase(), gc);
        if (owner != null) BY_OWNER.computeIfAbsent(owner, k -> new ArrayList<>()).add(gc);
        return gc;
    }

    // ── Query ─────────────────────────────────────────────────────────────

    public static GiftCard getById(String id)            { return ALL.get(id.toUpperCase()); }
    public static List<GiftCard> getForPlayer(UUID uuid) { return BY_OWNER.getOrDefault(uuid, Collections.emptyList()); }
    public static Collection<GiftCard> getAll()          { return ALL.values(); }

    // ── Remove ────────────────────────────────────────────────────────────

    public static boolean remove(String id) {
        GiftCard gc = ALL.remove(id.toUpperCase());
        if (gc == null) return false;
        BY_OWNER.values().forEach(list -> list.removeIf(g -> g.getId().equals(id)));
        return true;
    }

    // ── Redeem ────────────────────────────────────────────────────────────

    public static boolean redeem(UUID player, String id) {
        GiftCard gc = getById(id);
        if (gc == null || !gc.isValid()) return false;
        gc.redeem(player);
        return true;
    }

    // ── Duration parser ───────────────────────────────────────────────────

    /** Parse "1d", "2h", "30m", "never" → expiry epoch ms. 0 = never. -1 = error. */
    public static long parseExpiry(String input) {
        if (input.equalsIgnoreCase("never") || input.equalsIgnoreCase("0")) return 0;
        long ms = 0;
        StringBuilder num = new StringBuilder();
        for (char c : input.toLowerCase().toCharArray()) {
            if (Character.isDigit(c)) { num.append(c); }
            else {
                if (num.length() == 0) return -1;
                long n = Long.parseLong(num.toString()); num.setLength(0);
                switch (c) {
                    case 'd': ms += n * 86_400_000L; break;
                    case 'h': ms += n * 3_600_000L;  break;
                    case 'm': ms += n * 60_000L;     break;
                    case 's': ms += n * 1_000L;      break;
                    default: return -1;
                }
            }
        }
        return ms > 0 ? System.currentTimeMillis() + ms : -1;
    }
}
