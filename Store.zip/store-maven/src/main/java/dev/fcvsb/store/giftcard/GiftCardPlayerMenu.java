package dev.fcvsb.store.giftcard;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class GiftCardPlayerMenu extends Menu {

    private static final int[] SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34
    };

    private int page = 0;
    private final Map<Integer, GiftCard> slotMap = new HashMap<>();

    @Override public String title(Player p) { return "\u00a7a\u00a7l\uD83C\uDF81 Your Gift Cards"; }
    @Override public int    size (Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        slotMap.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 54);

        List<GiftCard> cards = GiftCardManager.getForPlayer(p.getUniqueId());
        int total = (int) Math.ceil(Math.max(1, cards.size()) / (double) SLOTS.length);
        int start = page * SLOTS.length;

        if (cards.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.BARRIER)
                    .name("&cNo Gift Cards")
                    .lore("&7You don't have any gift cards.",
                          " ", "&8Gift cards are given by admins.").build());
        } else {
            for (int i = 0; i < SLOTS.length && (start + i) < cards.size(); i++) {
                GiftCard gc = cards.get(start + i);
                b.put(SLOTS[i], buildCard(gc));
                slotMap.put(SLOTS[i], gc);
            }
        }

        long redeemable = 0, redeemed = 0, expired = 0;
        for (GiftCard gc : cards) {
            if (gc.isRedeemed()) redeemed++;
            else if (gc.isExpired()) expired++;
            else redeemable++;
        }

        b.put(49, ItemBuilder.of(Material.BOOK)
                .name("&6&lGift Card Wallet")
                .lore("&7Total:            &f" + cards.size(),
                      "&aRedeemable:       &f" + redeemable,
                      "&7Already redeemed: &f" + redeemed,
                      "&cExpired:          &f" + expired,
                      " ", "&8Click a &agreen &8card to redeem it.").build());

        if (page > 0)        b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total-1)  b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        List<GiftCard> cards = GiftCardManager.getForPlayer(p.getUniqueId());
        int total = (int) Math.ceil(Math.max(1, cards.size()) / (double) SLOTS.length);

        if (slot == 45 && page > 0)       { page--; open(p); return; }
        if (slot == 53 && page < total-1) { page++; open(p); return; }

        GiftCard gc = slotMap.get(slot);
        if (gc == null) return;

        if (gc.isRedeemed()) {
            p.sendMessage(ChatColor.RED + "This gift card has already been redeemed.");
            playFail(p); open(p); return;
        }
        if (gc.isExpired()) {
            p.sendMessage(ChatColor.RED + "This gift card has expired.");
            playFail(p); open(p); return;
        }

        // Redeem
        gc.redeem(p.getUniqueId());
        PlayerData data = PlayerData.get(p.getUniqueId());
        data.addCoins(gc.getCoins());
        DataStorage.savePlayer(p.getUniqueId(), data);
        DataStorage.saveGiftCards();

        p.sendMessage(ChatColor.GREEN + "\u2714 Gift card redeemed! You received "
                + ChatColor.WHITE + ChatColor.BOLD + gc.getCoins()
                + ChatColor.GREEN + " coins.");
        if (gc.getReason() != null && !gc.getReason().isEmpty())
            p.sendMessage(ChatColor.GRAY + "Reason: " + ChatColor.WHITE + gc.getReason());

        playSuccess(p);
        open(p);
    }

    private ItemStack buildCard(GiftCard gc) {
        List<String> lore = new ArrayList<>();
        if (gc.isRedeemed()) {
            lore.add("&7Status: &8Already redeemed");
            lore.add("&7Coins:  &8" + gc.getCoins());
            if (gc.getReason() != null && !gc.getReason().isEmpty())
                lore.add("&7Reason: &8" + gc.getReason());
            return ItemBuilder.of(Material.MAP).name("&8&m" + gc.getId() + " &8[Redeemed]").lore(lore).build();
        }
        if (gc.isExpired()) {
            lore.add("&7Status: &cExpired");
            lore.add("&7Coins:  &8" + gc.getCoins());
            if (gc.getReason() != null && !gc.getReason().isEmpty())
                lore.add("&7Reason: &8" + gc.getReason());
            return ItemBuilder.of(Material.MAP).name("&c&m" + gc.getId() + " &c[Expired]").lore(lore).build();
        }
        lore.add("&7Status:  &a\u2714 Valid");
        lore.add("&7Coins:   &6\u2605 &f" + gc.getCoins() + " coins");
        if (gc.getReason() != null && !gc.getReason().isEmpty())
            lore.add("&7Reason:  &f" + gc.getReason());
        lore.add("&7Expires: &e" + gc.formatExpiry());
        lore.add(" ");
        lore.add("&a\u25b6 Click to redeem!");
        return ItemBuilder.of(Material.MAP).name("&a&l" + gc.getId()).lore(lore).build();
    }

    private void playSuccess(Player p) {
        try { p.playSound(p.getLocation(), Sound.valueOf(StoreConfig.getSoundSuccess().toUpperCase().replace(".", "_")), 1f, 1f); }
        catch (Exception ignored) {}
    }

    private void playFail(Player p) {
        try { p.playSound(p.getLocation(), Sound.valueOf(StoreConfig.getSoundFail().toUpperCase().replace(".", "_")), 1f, 1f); }
        catch (Exception ignored) {}
    }
}
