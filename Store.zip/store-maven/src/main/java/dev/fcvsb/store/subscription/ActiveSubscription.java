package dev.fcvsb.store.subscription;

import java.util.UUID;

public class ActiveSubscription {

    private final String id;          // unique instance id
    private final UUID   playerUUID;
    private final String playerName;
    private final String productId;   // which membership product
    private final String productName;
    private final long   startedAt;
    private final long   expiresAt;
    private       boolean warned24h;  // whether 24h warning was sent
    private       boolean expired;    // whether expiry commands were run

    public ActiveSubscription(String id, UUID playerUUID, String playerName,
                               String productId, String productName,
                               long startedAt, long expiresAt) {
        this.id          = id;
        this.playerUUID  = playerUUID;
        this.playerName  = playerName;
        this.productId   = productId;
        this.productName = productName;
        this.startedAt   = startedAt;
        this.expiresAt   = expiresAt;
        this.warned24h   = false;
        this.expired     = false;
    }

    public String  getId()          { return id; }
    public UUID    getPlayerUUID()  { return playerUUID; }
    public String  getPlayerName()  { return playerName; }
    public String  getProductId()   { return productId; }
    public String  getProductName() { return productName; }
    public long    getStartedAt()   { return startedAt; }
    public long    getExpiresAt()   { return expiresAt; }
    public boolean isWarned24h()    { return warned24h; }
    public boolean isExpired()      { return expired; }

    public void setWarned24h()      { this.warned24h = true; }
    public void setExpired()        { this.expired = true; }

    public boolean isActive()       { return !expired && System.currentTimeMillis() < expiresAt; }

    public String formatTimeLeft() {
        long rem = Math.max(0, expiresAt - System.currentTimeMillis());
        long s = rem / 1000, m = s / 60, h = m / 60, d = h / 24;
        if (d > 0) return d + "d " + (h % 24) + "h";
        if (h > 0) return h + "h " + (m % 60) + "m";
        if (m > 0) return m + "m";
        return s + "s";
    }
}
