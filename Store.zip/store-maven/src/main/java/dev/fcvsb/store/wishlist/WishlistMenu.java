package dev.fcvsb.store.wishlist;

import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Shows a player's own wishlist.
 * Can be opened for someone else (gift mode) to gift them items.
 */
public class WishlistMenu extends Menu {

    private final UUID   ownerUUID;
    private final String ownerName;
    private final boolean giftMode; // true = viewing someone else's wishlist to gift

    /** Own wishlist */
    public WishlistMenu(Player owner) {
        this.ownerUUID = owner.getUniqueId();
        this.ownerName = owner.getName();
        this.giftMode  = false;
    }

    /** View someone else's wishlist to gift them */
    public WishlistMenu(UUID targetUUID, String targetName) {
        this.ownerUUID = targetUUID;
        this.ownerName = targetName;
        this.giftMode  = true;
    }

    @Override
    public String title(Player p) {
        return giftMode
                ? "\u00a78\u00bb \u00a7d" + ownerName + "'s Wishlist"
                : "\u00a78\u00bb \u00a76My Wishlist";
    }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        Set<String> wishlist = WishlistManager.get(ownerUUID);
        List<ShopProduct> products = resolveProducts(wishlist);

        if (products.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.PAPER)
                    .name(giftMode ? "&7" + ownerName + " has no wishlist items." : "&7Your wishlist is empty.")
                    .lore("&7" + (giftMode ? "" : "Right-click items in the shop to add them!")).build());
        } else {
            int[] slots = buildInnerSlots();
            for (int i = 0; i < Math.min(products.size(), slots.length); i++) {
                ShopProduct sp = products.get(i);
                b.put(slots[i], buildWishItem(sp, p));
            }
        }

        if (giftMode) {
            b.put(49, ItemBuilder.of(Material.GOLD_INGOT)
                    .name("&6&lGifting: &f" + ownerName)
                    .lore("&7Click an item to add it to your cart",
                          "&7as a gift for &f" + ownerName + "&7.").build());
        } else {
            b.put(49, ItemBuilder.of(Material.BOOK)
                    .name("&6&lMy Wishlist")
                    .lore("&7Right-click items in the shop",
                          "&7to add or remove them here.",
                          " ",
                          "&7Items: &f" + wishlist.size()).build());
        }

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        Set<String> wishlist = WishlistManager.get(ownerUUID);
        List<ShopProduct> products = resolveProducts(wishlist);

        int[] slots = buildInnerSlots();
        for (int i = 0; i < slots.length; i++) {
            if (slot != slots[i]) continue;
            if (i >= products.size()) return;
            ShopProduct sp = products.get(i);

            if (giftMode) {
                // Add to cart as gift for the wishlist owner
                StoreCart cart = StoreCart.of(p.getUniqueId());
                cart.setGiftTarget(ownerUUID, ownerName);
                cart.addItem(sp, 1);
                p.sendMessage("\u00a7a\u25b8 \u00a7fAdded \u00a7e" + sp.getDisplayName()
                        + "\u00a7f to cart as a gift for \u00a7d" + ownerName + "\u00a7f.");
                p.closeInventory();
            } else if (right) {
                // Remove from own wishlist
                WishlistManager.toggle(ownerUUID, sp.getId()); // remove from the OWNER's wishlist, not the buyer's
                new WishlistMenu(p).open(p);
            }
            return;
        }
    }

    private List<ShopProduct> resolveProducts(Set<String> wishlist) {
        List<ShopProduct> result = new ArrayList<>();
        for (String id : wishlist) {
            ShopProduct sp = findProduct(id);
            if (sp != null) result.add(sp);
        }
        return result;
    }

    private ShopProduct findProduct(String id) {
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (ShopProduct sp : cat.getProducts().values())
                if (sp.getId().equals(id)) return sp;
            for (ShopSubCategory sub : cat.getSubCategories().values())
                for (ShopProduct sp : sub.getProducts().values())
                    if (sp.getId().equals(id)) return sp;
        }
        return null;
    }

    private ItemStack buildWishItem(ShopProduct sp, Player viewer) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Price: &f" + sp.getPrice(viewer) + " coins");
        if (sp.getStock() == 0)       lore.add("&cOut of stock");
        else if (sp.getStock() > 0)   lore.add("&7Stock: &f" + sp.getStock());
        lore.add(" ");
        if (giftMode) lore.add("&aClick to add to cart as gift");
        else          lore.add("&cRight-click to remove");

        ItemStack base = sp.getDisplayItem(viewer, null);
        Material mat   = base != null ? base.getType() : Material.PAPER;
        short    data  = base != null ? base.getDurability() : 0;
        return ItemBuilder.of(mat, data).name(sp.getDisplayName()).lore(lore).build();
    }

    private int[] buildInnerSlots() {
        int[] slots = new int[28];
        int idx = 0;
        for (int row = 1; row <= 4; row++)
            for (int col = 1; col <= 7; col++)
                slots[idx++] = row * 9 + col;
        return slots;
    }
}
