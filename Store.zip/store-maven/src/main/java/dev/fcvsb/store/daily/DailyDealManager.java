package dev.fcvsb.store.daily;

import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.shop.ShopSubCategory;

import java.util.*;

public class DailyDealManager {

    // active deals: productId -> DailyDeal
    private static final Map<String, DailyDeal> ACTIVE = new LinkedHashMap<>();
    private static long    resetAt = 0; // epoch ms when current deals expire
    private static boolean paused  = false;

    // ── Roll new deals ────────────────────────────────────────────────────

    public static void rollDeals() {
        ACTIVE.clear();
        int count = StoreConfig.getDailyDealCount();
        int pct   = StoreConfig.getDailyDealPercent();

        List<ShopProduct> eligible = getEligible();
        if (eligible.isEmpty()) return;

        Collections.shuffle(eligible);
        for (int i = 0; i < Math.min(count, eligible.size()); i++) {
            ShopProduct sp = eligible.get(i);
            int salePrice = Math.max(1, sp.getPrice(null) - (int) Math.round(sp.getPrice(null) * pct / 100.0));
            ACTIVE.put(sp.getId(), new DailyDeal(sp.getId(), sp.getPrice(null), salePrice, pct));
        }

        // Reset in 24 hours from now
        resetAt = System.currentTimeMillis() + 86_400_000L;
    }

    // Load from persisted state (called on startup)
    public static void loadState(Map<String, DailyDeal> deals, long savedResetAt, boolean savedPaused, long savedPausedAt) {
        ACTIVE.clear();
        ACTIVE.putAll(deals);
        resetAt  = savedResetAt;
        paused   = savedPaused;
        pausedAt = savedPausedAt;
    }

    public static long getPausedAt() { return pausedAt; }

    // ── Tick check ────────────────────────────────────────────────────────

    /** Call periodically — returns true if deals were re-rolled. */
    public static boolean tickCheck() {
        if (paused) return false;
        if (resetAt == 0 || System.currentTimeMillis() >= resetAt) {
            rollDeals();
            dev.fcvsb.store.storage.DataStorage.saveDailyDeals();
            return true;
        }
        return false;
    }

    private static long pausedAt = 0; // epoch ms when paused

    public static void pause()  { paused = true;  pausedAt = System.currentTimeMillis(); }
    public static void resume() { paused = false; resetAt = System.currentTimeMillis() + (resetAt - pausedAt); pausedAt = 0; }
    public static boolean isPaused() { return paused; }

    /** Force-roll new deals immediately (used by /deals next) */
    public static void forceNext() {
        rollDeals();
        dev.fcvsb.store.storage.DataStorage.saveDailyDeals();
    }

    // ── Query ─────────────────────────────────────────────────────────────

    public static Collection<DailyDeal> getActive()         { return ACTIVE.values(); }
    public static DailyDeal getDeal(String productId)        { return ACTIVE.get(productId); }
    public static boolean hasDeal(String productId)          { return ACTIVE.containsKey(productId); }
    public static long    getResetAt()                       { return resetAt; }

    /** Remaining time formatted as HH:mm:ss */
    public static String getCountdown() {
        if (paused) return "§c⏸ Paused";
        long rem = Math.max(0, resetAt - System.currentTimeMillis());
        long s = rem / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        return String.format("%02d:%02d:%02d", h, m, sec);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static List<ShopProduct> getEligible() {
        List<ShopProduct> list = new ArrayList<>();
        for (ShopCategory cat : ShopLoader.getCategories().values()) {
            for (ShopProduct sp : cat.getProducts().values())
                if (sp.isDailyDealEligible()) list.add(sp);
            for (ShopSubCategory sub : cat.getSubCategories().values())
                for (ShopProduct sp : sub.getProducts().values())
                    if (sp.isDailyDealEligible()) list.add(sp);
        }
        return list;
    }
}
