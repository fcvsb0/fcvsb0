package dev.fcvsb.store.log;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Full breakdown of a single purchase: sale discounts, coupon, gift fee, final paid.
 */
public class PurchaseLog {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    private final String playerName;
    private final String itemName;
    private final String category;
    private final int    originalPrice;
    private final int    saleDiscount;
    private final String couponCode;
    private final int    couponDiscount;
    private final int    finalPaid;
    private final String giftRecipient;   // null if not a gift
    private final int    giftFee;         // 0 if not a gift
    private final long   timestamp;

    public PurchaseLog(String playerName, String itemName, String category,
                       int originalPrice, int saleDiscount,
                       String couponCode, int couponDiscount,
                       int finalPaid,
                       String giftRecipient, int giftFee) {
        this.playerName    = playerName;
        this.itemName      = itemName;
        this.category      = category;
        this.originalPrice = originalPrice;
        this.saleDiscount  = saleDiscount;
        this.couponCode    = couponCode;
        this.couponDiscount= couponDiscount;
        this.finalPaid     = finalPaid;
        this.giftRecipient = giftRecipient;
        this.giftFee       = giftFee;
        this.timestamp     = System.currentTimeMillis();
    }

    /** Constructor that restores a log with a known timestamp (used by DataStorage). */
    public PurchaseLog(String playerName, String itemName, String category,
                       int originalPrice, int saleDiscount,
                       String couponCode, int couponDiscount,
                       int finalPaid,
                       String giftRecipient, int giftFee, long timestamp) {
        this.playerName    = playerName;
        this.itemName      = itemName;
        this.category      = category;
        this.originalPrice = originalPrice;
        this.saleDiscount  = saleDiscount;
        this.couponCode    = couponCode;
        this.couponDiscount= couponDiscount;
        this.finalPaid     = finalPaid;
        this.giftRecipient = giftRecipient;
        this.giftFee       = giftFee;
        this.timestamp     = timestamp;
    }

    public String getPlayerName()     { return playerName; }
    public String getItemName()       { return itemName; }
    public String getCategory()       { return category; }
    public int    getOriginalPrice()  { return originalPrice; }
    public int    getSaleDiscount()   { return saleDiscount; }
    public String getCouponCode()     { return couponCode; }
    public int    getCouponDiscount() { return couponDiscount; }
    public int    getFinalPaid()      { return finalPaid; }
    public String getGiftRecipient()  { return giftRecipient; }
    public int    getGiftFee()        { return giftFee; }
    public long   getTimestamp()      { return timestamp; }

    /** @deprecated Use getFinalPaid() */
    @Deprecated public int getCoins() { return finalPaid; }

    public boolean hadSale()      { return saleDiscount  > 0; }
    public boolean hadCoupon()    { return couponCode != null && couponDiscount > 0; }
    public boolean isGift()       { return giftRecipient != null; }
    public boolean hadGiftFee()   { return giftFee > 0; }
    public int     getTotalSavings() { return saleDiscount + couponDiscount; }

    public String getFormattedDate() { return SDF.format(new Date(timestamp)); }
}
