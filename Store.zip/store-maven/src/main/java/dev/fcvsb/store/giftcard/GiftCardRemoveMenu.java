package dev.fcvsb.store.giftcard;

import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public class GiftCardRemoveMenu extends Menu {

    private final GiftCard gc;
    private final Menu     back;

    public GiftCardRemoveMenu(GiftCard gc, Menu back) {
        this.gc   = gc;
        this.back = back;
    }

    @Override public String title(Player p) { return "\u00a78[\u00a7cRemove\u00a78] \u00a7fGiftCard \u00a77" + gc.getId(); }
    @Override public int    size (Player p) { return 27; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 27);

        b.put(11, ItemBuilder.of(Material.WOOL, (short) 5)
                .name("&a&l\u2714 Confirm Remove")
                .lore("&7ID:     &f" + gc.getId(),
                      "&7Coins:  &f" + gc.getCoins(),
                      "&7Reason: &f" + gc.getReason(),
                      " ", "&cThis cannot be undone.").build());

        b.put(15, ItemBuilder.of(Material.WOOL, (short) 14)
                .name("&c&l\u2718 Cancel").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        if (slot == 11) {
            GiftCardManager.remove(gc.getId());
            dev.fcvsb.store.storage.DataStorage.saveGiftCards();
            p.sendMessage("\u00a7c\u2718 GiftCard \u00a7f" + gc.getId() + "\u00a7c removed.");
            back.open(p);
        } else if (slot == 15) {
            back.open(p);
        }
    }
}
