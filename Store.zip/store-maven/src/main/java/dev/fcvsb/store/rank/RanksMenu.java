package dev.fcvsb.store.rank;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.storage.DataStorage;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class RanksMenu extends Menu {

    private static final int[] RANK_SLOTS = {
        10, 11, 12, 13, 14, 15, 16,
        19, 20, 21, 22, 23, 24, 25
    };

    private final StoreCart cart;
    private final Menu      back;

    public RanksMenu(StoreCart cart, Menu back) {
        this.cart = cart;
        this.back = back;
    }

    @Override public String title(Player p) { return "\u00a76\u00a7l\u2605 Rank Upgrades"; }
    @Override public int    size (Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        List<ShopProduct> chain   = RankManager.getChain();
        ShopProduct       current = RankManager.getCurrentRank(p.getUniqueId());
        ShopProduct       next    = RankManager.getNextRank(p.getUniqueId());

        for (int i = 0; i < Math.min(chain.size(), RANK_SLOTS.length); i++) {
            b.put(RANK_SLOTS[i], buildRankItem(chain.get(i), current, next, p));
        }

        // Info slot
        b.put(49, ItemBuilder.of(Material.NETHER_STAR)
                .name("&e&lYour Rank")
                .lore("&7Current: " + (current != null
                        ? ChatColor.translateAlternateColorCodes('&', current.getDisplayName())
                        : "&7None"),
                      next != null
                        ? "&7Next: " + ChatColor.translateAlternateColorCodes('&', next.getDisplayName())
                              + " &7— &e" + next.getPrice(p) + " coins"
                        : "&a\u2605 Maximum rank reached!")
                .build());

        b.put(45, Borders.backButton());
        return b;
    }

    private ItemStack buildRankItem(ShopProduct rank, ShopProduct current,
                                    ShopProduct next, Player p) {
        boolean isCurrent     = current != null && rank.getId().equals(current.getId());
        boolean isOwned       = RankManager.hasRank(p.getUniqueId(), rank.getId()) && !isCurrent;
        boolean isPurchasable = next != null && rank.getId().equals(next.getId());

        List<String> lore = new ArrayList<>();
        lore.add(" ");
        if (isCurrent) {
            lore.add("&a\u25b8 Your current rank");
        } else if (isOwned) {
            lore.add("&2\u2714 Already owned");
        } else if (isPurchasable) {
            lore.add("&7Price: &e" + rank.getPrice(p) + " coins");
            lore.add("&7Your balance: &e" + PlayerData.get(p.getUniqueId()).getCoins() + " coins");
            lore.add(" ");
            lore.add("&aClick to purchase!");
        } else {
            lore.add("&c\u274c Locked");
            lore.add("&7Purchase previous ranks first.");
        }

        Material mat = isPurchasable ? Material.GOLD_INGOT
                     : (isCurrent || isOwned) ? Material.EMERALD
                     : Material.IRON_INGOT;

        String prefix = isCurrent ? "&a\u2605 " : isOwned ? "&2\u2714 " : isPurchasable ? "&e\u25b6 " : "&8\u274c ";

        return ItemBuilder.of(rank.getMaterial(), rank.getMaterialData())
                .name(prefix + rank.getDisplayName())
                .lore(lore)
                .build();
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        if (slot == 45) { back.open(p); return; }

        List<ShopProduct> chain = RankManager.getChain();
        for (int i = 0; i < Math.min(chain.size(), RANK_SLOTS.length); i++) {
            if (slot != RANK_SLOTS[i]) continue;
            ShopProduct rank = chain.get(i);
            ShopProduct next = RankManager.getNextRank(p.getUniqueId());

            if (next == null || !rank.getId().equals(next.getId())) return;

            PlayerData data = PlayerData.get(p.getUniqueId());
            int price = rank.getPrice(p);
            if (!data.takeCoins(price)) {
                p.sendMessage(ChatColor.RED + "\u2718 You need "
                        + ChatColor.WHITE + price + " coins"
                        + ChatColor.RED + " to unlock "
                        + ChatColor.WHITE + ShopProduct.cleanDisplayName(rank.getDisplayName())
                        + ChatColor.RED + ". You have "
                        + ChatColor.WHITE + data.getCoins() + ChatColor.RED + ".");
                return;
            }

            // Grant rank
            RankManager.setRank(p.getUniqueId(), rank.getId());
            DataStorage.savePlayer(p.getUniqueId(), data);

            // Run commands
            for (String cmd : rank.getCommands()) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        cmd.replace("<player>", p.getName()));
            }

            // Title
            String displayClean = ChatColor.translateAlternateColorCodes('&', rank.getDisplayName());
            sendTitle(p, ChatColor.GOLD + "\u2605 Rank Unlocked!", displayClean);

            // Broadcast
            String broadcast = StoreConfig.getRankBroadcast()
                    .replace("<player>", p.getName())
                    .replace("<rank>", displayClean);
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcast));

            refresh(p);
            return;
        }
    }

    private void sendTitle(Player p, String title, String subtitle) {
        try {
            Object chatTitle    = nmsChatComponent(title);
            Object chatSubtitle = nmsChatComponent(subtitle);
            Object times  = nmsPacket("PacketPlayOutTitle",
                    nmsEnum("EnumTitleAction", "TIMES"), null, 10, 60, 20);
            Object pTitle = nmsPacket("PacketPlayOutTitle",
                    nmsEnum("EnumTitleAction", "TITLE"), chatTitle, 0, 0, 0);
            Object pSub   = nmsPacket("PacketPlayOutTitle",
                    nmsEnum("EnumTitleAction", "SUBTITLE"), chatSubtitle, 0, 0, 0);
            Object handle = p.getClass().getMethod("getHandle").invoke(p);
            Object pc = handle.getClass().getField("playerConnection").get(handle);
            java.lang.reflect.Method send = pc.getClass().getMethod("sendPacket",
                    Class.forName(nmsPath("Packet")));
            send.invoke(pc, times);
            send.invoke(pc, pSub);
            send.invoke(pc, pTitle);
        } catch (Exception ignored) {
            p.sendMessage(ChatColor.GOLD + "\u2605 " + title + " " + subtitle);
        }
    }

    private static String nmsPath(String cls) {
        String v = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
        return "net.minecraft.server." + v + "." + cls;
    }
    private static Object nmsChatComponent(String text) throws Exception {
        Class<?> s = Class.forName(nmsPath("IChatBaseComponent$ChatSerializer"));
        return s.getMethod("a", String.class).invoke(null,
                "{\"text\":\"" + text.replace("\"", "\\\"") + "\"}");
    }
    private static Object nmsEnum(String cls, String val) throws Exception {
        Class<?> c = Class.forName(nmsPath("PacketPlayOutTitle$" + cls));
        return Enum.valueOf((Class<Enum>) c, val);
    }
    private static Object nmsPacket(String cls, Object action, Object component,
                                     int fadeIn, int stay, int fadeOut) throws Exception {
        Class<?> pkt     = Class.forName(nmsPath(cls));
        Class<?> enumCls = Class.forName(nmsPath("PacketPlayOutTitle$EnumTitleAction"));
        Class<?> chatCls = Class.forName(nmsPath("IChatBaseComponent"));
        return pkt.getConstructor(enumCls, chatCls, int.class, int.class, int.class)
                  .newInstance(action, component, fadeIn, stay, fadeOut);
    }
}
