package dev.fcvsb.store.command;

import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.daily.DailyDealManager;
import dev.fcvsb.store.storage.DataStorage;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class DealsCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("store.admin")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }
        if (!StoreConfig.isDailyDealsEnabled()) {
            sender.sendMessage(ChatColor.RED + "Daily deals are disabled in config.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "/deals pause " + ChatColor.GRAY + "— pause/resume automatic re-roll");
            sender.sendMessage(ChatColor.GOLD + "/deals next  " + ChatColor.GRAY + "— force new deals immediately");
            sender.sendMessage(ChatColor.GRAY  + "Status: " + (DailyDealManager.isPaused()
                    ? ChatColor.RED + "PAUSED"
                    : ChatColor.GREEN + "ACTIVE — resets in " + DailyDealManager.getCountdown()));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "pause":
                if (DailyDealManager.isPaused()) {
                    DailyDealManager.resume();
                    DataStorage.saveDailyDeals();
                    sender.sendMessage(ChatColor.GREEN + "✔ Daily deals resumed. Next roll in: "
                            + DailyDealManager.getCountdown());
                } else {
                    DailyDealManager.pause();
                    DataStorage.saveDailyDeals();
                    sender.sendMessage(ChatColor.YELLOW + "⏸ Daily deals paused. Current deals will stay until resumed.");
                }
                break;

            case "next":
                DailyDealManager.forceNext();
                sender.sendMessage(ChatColor.GREEN + "✔ New daily deals rolled! Active deals: "
                        + DailyDealManager.getActive().size());
                break;

            default:
                sender.sendMessage(ChatColor.RED + "Unknown sub-command. Use: /deals pause | /deals next");
        }
        return true;
    }
}
