package dev.fcvsb.store.giftcard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * /giftcard create <player>  — opens GiftCardCreateMenu
 * /giftcard remove <player>  — opens GiftCardManageMenu
 * /giftcard manage <player>  — opens GiftCardManageMenu
 */
public class GiftCardCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
        if (!sender.hasPermission("store.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }

        Player p = (Player) sender;

        if (args.length < 2) { usage(p); return true; }

        String sub    = args[0].toLowerCase();
        String target = args[1];

        UUID   targetUUID;
        String targetName;
        Player online = Bukkit.getPlayerExact(target);
        if (online != null) {
            targetUUID = online.getUniqueId();
            targetName = online.getName();
        } else {
            @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(target);
            targetUUID = off.getUniqueId();
            targetName = off.getName() != null ? off.getName() : target;
        }

        switch (sub) {
            case "create":
                new GiftCardCreateMenu(targetUUID, targetName).open(p);
                break;
            case "remove":
            case "manage":
                new GiftCardManageMenu(targetUUID, targetName).open(p);
                break;
            default:
                usage(p);
        }
        return true;
    }

    private void usage(Player p) {
        p.sendMessage(ChatColor.YELLOW + "Usage:");
        p.sendMessage(ChatColor.GRAY + "  /giftcard create <player>");
        p.sendMessage(ChatColor.GRAY + "  /giftcard remove <player>");
        p.sendMessage(ChatColor.GRAY + "  /giftcard manage <player>");
    }
}
