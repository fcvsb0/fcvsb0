package dev.fcvsb.store.giftcard;

import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class GiftCardManageMenu extends Menu {

    private static final int[] SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34
    };

    private final UUID   targetUUID;
    private final String targetName;
    private       int    page = 0;
    private final Map<Integer, GiftCard> slotMap = new HashMap<>();

    public GiftCardManageMenu(UUID targetUUID, String targetName) {
        this.targetUUID = targetUUID;
        this.targetName = targetName;
    }

    @Override public String title(Player p) { return "\u00a78[\u00a7aGiftCards\u00a78] \u00a7f" + targetName; }
    @Override public int    size (Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        slotMap.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 54);

        List<GiftCard> cards = GiftCardManager.getForPlayer(targetUUID);
        int total = (int) Math.ceil(Math.max(1, cards.size()) / (double) SLOTS.length);
        int start = page * SLOTS.length;

        if (cards.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.BARRIER).name("&cNo GiftCards")
                    .lore("&7" + targetName + " has no giftcards.").build());
        } else {
            for (int i = 0; i < SLOTS.length && (start + i) < cards.size(); i++) {
                GiftCard gc = cards.get(start + i);
                b.put(SLOTS[i], buildCard(gc));
                slotMap.put(SLOTS[i], gc);
            }
        }

        b.put(49, ItemBuilder.of(Material.PAPER)
                .name("&7Page &f" + (page+1) + " &7of &f" + total)
                .lore("&7Total: &f" + cards.size() + " giftcards").build());
        if (page > 0)       b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total-1) b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());
        b.put(4, Borders.backButton());
        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        if (slot == 4)  { p.closeInventory(); return; }
        if (slot == 45 && page > 0) { page--; open(p); return; }
        if (slot == 53) { page++; open(p); return; }
        GiftCard gc = slotMap.get(slot);
        if (gc != null) new GiftCardRemoveMenu(gc, this).open(p);
    }

    private ItemStack buildCard(GiftCard gc) {
        Material mat  = gc.isRedeemed() ? Material.BOOK : gc.isExpired() ? Material.BARRIER : Material.PAPER;
        String status = gc.isRedeemed() ? "&7[Redeemed]" : gc.isExpired() ? "&c[Expired]" : "&a[Valid]";
        return ItemBuilder.of(mat)
                .name("&f" + gc.getId() + " " + status)
                .lore("&7Coins:  &f" + gc.getCoins(),
                      "&7Reason: &f" + gc.getReason(),
                      "&7Expiry: &f" + gc.formatExpiry(),
                      " ", "&cLeft-click to remove").build();
    }
}
