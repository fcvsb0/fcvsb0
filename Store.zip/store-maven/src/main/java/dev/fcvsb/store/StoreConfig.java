package dev.fcvsb.store;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public class StoreConfig {

    private static File              file;
    private static FileConfiguration cfg;

    public static void init(StorePlugin plugin) {
        file = new File(plugin.getDataFolder(), "config.yml");
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        if (!file.exists()) writeDefaults();
        else cfg = YamlConfiguration.loadConfiguration(file);
    }

    public static void reload() { cfg = YamlConfiguration.loadConfiguration(file); }

    // ── General ───────────────────────────────────────────────────────────
    public static String  getServerName()  { return cfg.getString("server", "store"); }
    public static String  getDateFormat()  { return cfg.getString("date-format", "MM/dd/yyyy HH:mm:ss"); }
    public static String  getSaveSystem()  { return cfg.getString("save-system", "FLATFILE"); }

    // ── Shop system ───────────────────────────────────────────────────────
    public static boolean isPurchaseInstantly() { return cfg.getBoolean("shop-system.purchase-instantly", false); }
    public static boolean isBuyerOther()        { return cfg.getBoolean("shop-system.buyer-other", true); }

    // ── Shop command ──────────────────────────────────────────────────────
    public static String       getShopCommandName()    { return cfg.getString("shop-command.name", "tienda"); }
    public static List<String> getShopCommandAliases() { return cfg.getStringList("shop-command.aliases"); }

    // ── Currency ──────────────────────────────────────────────────────────
    public static String getCurrencyCommand(String currency) {
        return cfg.getString("currency-custom-command." + currency, currency);
    }

    public static boolean isWithdrawEnabled() { return cfg.getBoolean("currency-withdraw-system.enabled", false); }
    public static String getWithdrawItemName(String currency) {
        return cfg.getString("currency-withdraw-system.currency-items." + currency + ".name", "&6&lx<currency-amount> Coins");
    }
    public static List<String> getWithdrawItemDesc(String currency) {
        return cfg.getStringList("currency-withdraw-system.currency-items." + currency + ".description");
    }
    public static String getWithdrawItemMaterial(String currency) {
        return cfg.getString("currency-withdraw-system.currency-items." + currency + ".material", "GOLD_NUGGET");
    }
    public static boolean isWithdrawItemEnchanted(String currency) {
        return cfg.getBoolean("currency-withdraw-system.currency-items." + currency + ".enchanted", false);
    }

    // ── Coupon system ─────────────────────────────────────────────────────
    public static boolean isCouponEnabled()          { return cfg.getBoolean("coupon-system.enabled", true); }
    public static boolean isCouponBlockedDuringSale() { return cfg.getBoolean("coupon-system.blocked-during-sale", false); }

    // ── GiftCard ──────────────────────────────────────────────────────────
    public static boolean isGiftcardEnabled()   { return cfg.getBoolean("giftcard-system.enabled", true); }
    public static int     getGiftcardChars()    { return cfg.getInt("giftcard-system.characters", 12); }

    // ── Subscriptions ─────────────────────────────────────────────────────
    public static boolean isSubscriptionsEnabled() { return cfg.getBoolean("subscriptions.enabled", true); }

    // ── Daily Deals ───────────────────────────────────────────────────────
    public static boolean isDailyDealsEnabled()  { return cfg.getBoolean("daily-deals.enabled", true); }
    public static int     getDailyDealCount()    { return cfg.getInt("daily-deals.count", 1); }
    public static int     getDailyDealPercent()  { return cfg.getInt("daily-deals.discount-percent", 15); }
    public static int     getDailyDealSlot()     { return cfg.getInt("daily-deals.slot", 49); }

    // ── Gift system ───────────────────────────────────────────────────────

    // ── Ranks ─────────────────────────────────────────────────────────────
    public static boolean isRanksEnabled()    { return cfg.getBoolean("ranks.enabled", false); }
    public static int     getRanksSlot()      { return cfg.getInt("ranks.slot", 48); }
    public static String  getRankBroadcast()  { return cfg.getString("ranks.broadcast", "&6[Store] &f<player> &ejust ranked up to &6<rank>&e!"); }

    /** Minimum gift total (coins) that requires staff review. 0 = disabled. */
    public static int getGiftReviewThreshold() { return cfg.getInt("gift-system.review-threshold", 5000); }

    /** Whether the gift fee (IVA) is enabled globally. */
    public static boolean isGiftFeeEnabled() { return cfg.getBoolean("gift-system.iva", true); }

    /** Global extra fee % applied when gifting. Default 5. Range 1-100. */
    public static int getGlobalGiftFee() { return Math.max(1, Math.min(100, cfg.getInt("gift-system.gift-fee", 5))); }

    /** Custom broadcast message for gifts. Supports <buyer>, <recipient>, <item>, <amount>. */
    public static String getGiftBroadcastMessage() {
        return cfg.getString("gift-system.broadcast-message",
                "&7[&6&lStore&7] &f<buyer> &egifted &f<item> &eto &f<recipient>&e! Use &6&l/coinshop&e to visit the store!");
    }

    // ── Sound system ──────────────────────────────────────────────────────
    public static String getSoundFail()    { return cfg.getString("sound-system.fail",    "BLOCK_GRASS_BREAK"); }
    public static String getSoundSuccess() { return cfg.getString("sound-system.success", "BLOCK_NOTE_BLOCK_HARP"); }
    public static String getSoundNeutral() { return cfg.getString("sound-system.neutral", "ENTITY_EXPERIENCE_ORB_PICKUP"); }

    // ── Menu design ───────────────────────────────────────────────────────
    public static String getMenuName() {
        return ChatColor.translateAlternateColorCodes('&',
                cfg.getString("menu-design.name", "&d\u2764 &5&lElder&d&lFlame &d\u2764")); // &c❤ es el corazon el /u27654
    }

    public static short getGlassPrimary()   { return parseData(cfg.getString("menu-design.glass_primary",   "160:2")); }
    public static short getGlassSecondary() { return parseData(cfg.getString("menu-design.glass_secondary", "160:10")); }

    private static short parseData(String value) {
        if (value == null) return 0;
        String[] parts = value.split(":");
        try { return (short) Integer.parseInt(parts.length > 1 ? parts[1] : parts[0]); }
        catch (NumberFormatException e) { return 0; }
    }

    // ── Store toggles ─────────────────────────────────────────────────────
    // ── Purchase explosion ────────────────────────────────────────────────
    public static boolean isPurchaseExplosionEnabled() { return cfg.getBoolean("purchase-explosion.enabled", true); }
    public static int     getPurchaseExplosionThreshold() { return cfg.getInt("purchase-explosion.threshold", 1500); }

    // ── Purchase Commands ─────────────────────────────────────────────────
    public static boolean isPurchaseCommandsEnabled()  { return cfg.getBoolean("purchase-commands.enabled", false); }
    public static int     getPurchaseCommandThreshold() { return cfg.getInt("purchase-commands.threshold", 0); }
    /** "always" = every purchase | "threshold" = only when total >= threshold */
    public static String  getPurchaseCommandMode()      { return cfg.getString("purchase-commands.mode", "always"); }
    /** "console" | "player" */
    public static String  getPurchaseCommandExecutor()  { return cfg.getString("purchase-commands.executor", "console"); }
    public static java.util.List<String> getPurchaseCommands() {
        return cfg.getStringList("purchase-commands.commands");
    }

    public static boolean isWishlistEnabled() { return cfg.getBoolean("wishlist", true); }
    public static boolean isGlassFill()        { return cfg.getBoolean("glass-fill", true); }

    public static boolean isEnabled()   { return cfg.getBoolean("store.enabled",   true); }
    public static boolean isFireworks() { return cfg.getBoolean("store.fireworks",  true); }
    public static boolean isBroadcast() { return cfg.getBoolean("store.broadcast",  true); }

    public static void setEnabled(boolean v)   { cfg.set("store.enabled",   v); save(); }
    public static void setFireworks(boolean v) { cfg.set("store.fireworks",  v); save(); }
    public static void setBroadcast(boolean v) { cfg.set("store.broadcast",  v); save(); }
    public static void toggle(String key) { String path = "store." + key; cfg.set(path, !cfg.getBoolean(path, true)); save(); }

    // ── Defaults ──────────────────────────────────────────────────────────
    private static void writeDefaults() {
        String yaml =
            "# Store Plugin Configuration\n" +
            "server: \"store\"\n" +
            "date-format: \"MM/dd/yyyy HH:mm:ss\"\n" +
            "save-system: \"FLATFILE\"\n" +
            "\n" +
            "shop-system:\n" +
            "  purchase-instantly: false\n" +
            "  buyer-other: true\n" +
            "\n" +
            "shop-command:\n" +
            "  name: \"tienda\"\n" +
            "  aliases:\n" +
            "    - \"store\"\n" +
            "    - \"coinshop\"\n" +
            "    - \"coin-shop\"\n" +
            "\n" +
            "currency-custom-command:\n" +
            "  coins: \"coins\"\n" +
            "\n" +
            "currency-withdraw-system:\n" +
            "  enabled: false\n" +
            "  currency-items:\n" +
            "    coins:\n" +
            "      name: \"&6&lx<currency-amount> Coins\"\n" +
            "      description:\n" +
            "        - \"&eClick to redeem &f<currency-amount> &ecoins.\"\n" +
            "      material: \"GOLD_NUGGET\"\n" +
            "      enchanted: true\n" +
            "\n" +
                        "\n" +
            "coupon-system:\n" +
            "  blocked-during-sale: false\n" +
            "  enabled: true\n" +
            "\n" +
            "giftcard-system:\n" +
            "  enabled: true\n" +
            "  characters: 12      # Length of generated giftcard codes\n" +
            "\n" +
            "# Gift System\n" +
            "# Players can right-click giftable items in the shop to buy them for online players.\n" +
            "gift-system:\n" +
            "  iva: yes           # Toggle the extra gift fee on/off\n" +
            "  gift-fee: 5        # Extra % fee applied to all gifted items (1-100)\n"
            + "  review-threshold: 5000  # Gifts costing more than this require staff approval (0 = disabled)\n"
            + "\n"
            + "# Rank upgrade system (set enabled: true to show the ranks button in /store)\n"
            + "ranks:\n"
            + "  enabled: false\n"
            + "  slot: 48\n"
            + "  broadcast: '&6[Store] &f<player> &ejust ranked up to &6<rank>&e!'\n" +
            "  broadcast-message: \"&7[&6&lStore&7] &f<buyer> &egifted &f<item> &eto &f<recipient>&e! Use &6&l/coinshop&e!\"\n" +
            "\n" +
            "sound-system:\n" +
            "  fail: \"BLOCK_GRASS_BREAK\"\n" +
            "  success: \"BLOCK_NOTE_BLOCK_HARP\"\n" +
            "  neutral: \"ENTITY_EXPERIENCE_ORB_PICKUP\"\n" +
            "\n" +
            "menu-design:\n" +
            "  name: \"&d\u2764 &5&lElder&d&lFlame &d\u2764\"\n" +
            "  glass_primary: \"160:2\"\n" +
            "  glass_secondary: \"160:10\"\n" +
            "\n" +
            "wishlist: true\n" +
            "glass-fill: true\n" +

            "\n" +
            "store:\n" +
            "  enabled: true\n" +
            "  fireworks: true\n" +
            "  broadcast: true\n" +
            "\n" +
            "# Daily Deals — random product(s) at a discount, resets every 24h\n" +
            "daily-deals:\n" +
            "  enabled: true\n" +
            "  count: 1              # how many products on deal at once\n" +
            "  discount-percent: 15  # % discount applied on top of any sale\n" +
            "  slot: 49              # slot in the main store menu\n" +
            "\n" +
            "# Subscription system — global toggle\n" +
            "subscriptions:\n" +
            "  enabled: true    # false = disables all memberships globally\n" +
            "\n" +
            "# Per-product subscription config (in your product YAML):\n" +
            "#   subscription:\n" +
            "#     enabled: true\n" +
            "#     duration: 30d          # 30d, 7d, 24h, etc.\n" +
            "#     expire-commands:\n" +
            "#       - \"lp user <player> parent remove vip\"\n" +
            "\n" +
            "# Explosion effect when a purchase total exceeds threshold (no damage)\n" +
            "purchase-explosion:\n" +
            "  enabled: true\n" +
            "  threshold: 1500   # coins\n" +
            "\n" +
            "# Commands triggered on purchase.\n" +
            "# mode: always = every purchase | threshold = only when total >= threshold\n" +
            "# executor: console | player\n" +
            "# Placeholders: <player>, <total>\n" +
            "purchase-commands:\n" +
            "  enabled: false\n" +
            "  mode: always         # always | threshold\n" +
            "  threshold: 1500      # only used when mode: threshold\n" +
            "  executor: console    # console | player\n" +
            "  commands:\n" +
            "    - \"say <player> just spent <total> coins in the store!\"\n";

        try { Files.write(file.toPath(), yaml.getBytes(StandardCharsets.UTF_8)); }
        catch (IOException e) { e.printStackTrace(); }
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    private static void save() {
        try { cfg.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    public static FileConfiguration raw() { return cfg; }
}
