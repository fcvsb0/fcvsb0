package dev.fcvsb.store.menu;

import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.sale.SaleManager;
import dev.fcvsb.store.shop.ShopCategory;
import dev.fcvsb.store.shop.ShopLoader;
import dev.fcvsb.store.shop.ShopSubCategory;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * /store editor — 3 sections:
 *   Row 1: store toggles (enabled, fireworks, broadcast) + sale controls
 *   Row 3: all loaded ShopCategories
 *   Row 4-5: subcategories of a selected category (if clicked)
 */
public class EditorMenu extends Menu {

    // ── Fixed slots ───────────────────────────────────────────────────────
    private static final int SLOT_TOGGLE_STORE     = 1;
    private static final int SLOT_TOGGLE_FIREWORKS = 3;
    private static final int SLOT_TOGGLE_BROADCAST = 5;
    private static final int SLOT_SALE_INFO        = 7;
    private static final int SLOT_SALE_STOP        = 8;

    // Category display rows: slots 18-26 (row 3 of 6-row inventory)
    private static final int CAT_ROW_START = 18;

    private final Map<Integer, ShopCategory>    catSlots = new HashMap<>();
    private final Map<Integer, ShopSubCategory> subSlots = new HashMap<>();

    @Override public String title(Player p) { return "\u00a78[\u00a76Editor\u00a78] \u00a76Store Admin"; }
    @Override public int    size (Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        catSlots.clear();
        subSlots.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        b.putAll(Borders.get54());
        Borders.fill(b, 54);

        // ── Row 0: divider label ──────────────────────────────────────────
        b.put(0, ItemBuilder.of(Material.STAINED_GLASS_PANE, (short) 4)
                .name("&6&lStore Settings").build());

        // ── Toggles ───────────────────────────────────────────────────────
        b.put(SLOT_TOGGLE_STORE, buildToggle(
                "&6&lStore", "Enable or disable the store.\nIf OFF, only OPs can open it.",
                StoreConfig.isEnabled(), Material.LEVER));

        b.put(SLOT_TOGGLE_FIREWORKS, buildToggle(
                "&6&lFireworks", "Launch fireworks on purchase.",
                StoreConfig.isFireworks(), Material.FIREWORK));

        b.put(SLOT_TOGGLE_BROADCAST, buildToggle(
                "&6&lBroadcast", "Announce purchases to the server.",
                StoreConfig.isBroadcast(), Material.PAPER));

        // ── Sale info ─────────────────────────────────────────────────────
        b.put(SLOT_SALE_INFO, buildSaleInfo());

        if (SaleManager.isActive()) {
            b.put(SLOT_SALE_STOP, ItemBuilder.of(Material.BARRIER)
                    .name("&c&lCancel Sale")
                    .lore("&7Active: &f" + SaleManager.getPercentage() + "% OFF",
                          "&7Remaining: &e" + SaleManager.formatRemaining(),
                          " ", "&cClick to cancel").build());
        }

        // ── Row 2 separator ───────────────────────────────────────────────
        b.put(9, ItemBuilder.of(Material.STAINED_GLASS_PANE, (short) 0).name("&8\u2500\u2500 Categories").build());

        // ── Categories row ────────────────────────────────────────────────
        Collection<ShopCategory> cats = ShopLoader.getCategories().values();
        int slot = CAT_ROW_START;
        for (ShopCategory cat : cats) {
            if (slot > 26) break;
            b.put(slot, buildCategoryIcon(cat));
            catSlots.put(slot, cat);
            slot++;
        }

        if (cats.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.BARRIER)
                    .name("&cNo categories loaded")
                    .lore("&7Add YAML files to plugins/Store/shop/").build());
        }

        // ── Sub-category rows (slots 27-44) ───────────────────────────────
        b.put(27, ItemBuilder.of(Material.STAINED_GLASS_PANE, (short) 0).name("&8\u2500\u2500 Subcategories").build());

        int subSlot = 28;
        for (ShopCategory cat : cats) {
            for (ShopSubCategory sub : cat.getSubCategories().values()) {
                if (subSlot > 44) break;
                b.put(subSlot, buildSubIcon(cat, sub));
                subSlots.put(subSlot, sub);
                subSlot++;
            }
        }

        if (subSlot == 28) {
            b.put(35, ItemBuilder.of(Material.PAPER)
                    .name("&7No subcategories").build());
        }

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        switch (slot) {
            case SLOT_TOGGLE_STORE:
                StoreConfig.toggle("enabled");
                p.sendMessage(ChatColor.GOLD + "Store: " + state(StoreConfig.isEnabled()));
                open(p); break;
            case SLOT_TOGGLE_FIREWORKS:
                StoreConfig.toggle("fireworks");
                p.sendMessage(ChatColor.GOLD + "Fireworks: " + state(StoreConfig.isFireworks()));
                open(p); break;
            case SLOT_TOGGLE_BROADCAST:
                StoreConfig.toggle("broadcast");
                p.sendMessage(ChatColor.GOLD + "Broadcast: " + state(StoreConfig.isBroadcast()));
                open(p); break;
            case SLOT_SALE_STOP:
                if (SaleManager.isActive()) { SaleManager.cancel(); p.sendMessage(ChatColor.GREEN + "Sale cancelled."); open(p); }
                break;
        }

        // Category click → info message
        ShopCategory cat = catSlots.get(slot);
        if (cat != null) {
            p.sendMessage(ChatColor.GOLD + "Category: " + ChatColor.WHITE + cat.getId()
                    + ChatColor.GRAY + " | Products: " + cat.getProducts().size()
                    + " | Subcategories: " + cat.getSubCategories().size());
        }

        ShopSubCategory sub = subSlots.get(slot);
        if (sub != null) {
            p.sendMessage(ChatColor.GOLD + "Subcategory: " + ChatColor.WHITE + sub.getId()
                    + ChatColor.GRAY + " | Parent: " + sub.getParentId()
                    + " | Products: " + sub.getProducts().size());
        }
    }

    // ── Builders ──────────────────────────────────────────────────────────

    private ItemStack buildToggle(String name, String desc, boolean on, Material mat) {
        String[] lines = desc.split("\n");
        String[] lore  = new String[lines.length + 2];
        for (int i = 0; i < lines.length; i++) lore[i] = "&7" + lines[i];
        lore[lines.length]     = " ";
        lore[lines.length + 1] = "Status: " + (on ? "&a&lENABLED" : "&c&lDISABLED");
        return ItemBuilder.of(on ? Material.EMERALD : Material.REDSTONE).name(name).lore(lore).build();
    }

    private ItemStack buildSaleInfo() {
        if (!SaleManager.isActive())
            return ItemBuilder.of(Material.PAPER).name("&6Sale")
                    .lore("&7No active sale.", " ", "&7Use &f/sale <time> <percent>").build();
        return ItemBuilder.of(Material.PAPER)
                .name("&6&lSale: &f" + SaleManager.getPercentage() + "% OFF")
                .lore("&7Time remaining: &e" + SaleManager.formatRemaining()).build();
    }

    private ItemStack buildCategoryIcon(ShopCategory cat) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Products: &f" + cat.getProducts().size());
        lore.add("&7Subcategories: &f" + cat.getSubCategories().size());
        lore.add("&7Slot: &f" + cat.getSlot());
        lore.add(" ");
        lore.add("&eClick for info");
        return ItemBuilder.of(cat.getMaterial(), cat.getMaterialData())
                .name(cat.getName())
                .lore(lore).build();
    }

    private ItemStack buildSubIcon(ShopCategory parent, ShopSubCategory sub) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Parent: &f" + parent.getId());
        lore.add("&7Products: &f" + sub.getProducts().size());
        lore.add("&7Slot: &f" + sub.getSlot());
        lore.add(" ");
        lore.add("&eClick for info");
        return ItemBuilder.of(sub.getMaterial(), sub.getMaterialData())
                .name(sub.getName())
                .lore(lore).build();
    }

    private String state(boolean b) {
        return b ? ChatColor.GREEN + "ENABLED" : ChatColor.RED + "DISABLED";
    }
}
