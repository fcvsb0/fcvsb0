package dev.fcvsb.store.menu;

import dev.fcvsb.store.log.PurchaseLog;
import dev.fcvsb.store.log.PurchaseLogger;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LogsMenu extends Menu {

    private static final int PAGE_SIZE  = 28;
    private static final int START_SLOT = 10; // skip left border (slot 9)
    private static final int ROW_WIDTH  = 7;  // slots 10-16 per row (skip 17 = right border)
    private static final int ROWS       = 4;

    private final String targetName;
    private final UUID   targetUUID;
    private       int    page = 0;

    public LogsMenu() { this.targetName = null; this.targetUUID = null; }
    public LogsMenu(String playerName, UUID uuid) { this.targetName = playerName; this.targetUUID = uuid; }

    @Override
    public String title(Player p) {
        return targetName == null
                ? "\u00a78\u00bb \u00a76Global Logs"
                : "\u00a78\u00bb \u00a76Logs: \u00a7f" + targetName;
    }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 54);
        b.put(4, Borders.backButton());

        List<PurchaseLog> logs = targetUUID == null
                ? PurchaseLogger.getGlobal()
                : PurchaseLogger.getForPlayer(targetUUID);

        int total = (int) Math.ceil(Math.max(1, logs.size()) / (double) PAGE_SIZE);
        int start = page * PAGE_SIZE;

        if (logs.isEmpty()) {
            b.put(22, ItemBuilder.of(Material.PAPER).name("&7No logs").lore("&7No purchases recorded yet.").build());
        } else {
            int row = 0, col = 0;
            for (int i = start; i < Math.min(start + PAGE_SIZE, logs.size()); i++) {
                int slot = START_SLOT + row * 9 + col;
                b.put(slot, buildLogItem(logs.get(i)));
                col++;
                if (col >= ROW_WIDTH) { col = 0; row++; }
                if (row >= ROWS) break;
            }
        }

        List<String> summaryLore = new ArrayList<>();
        summaryLore.add("&7Total logs: &f" + logs.size());
        if (targetUUID != null) {
            summaryLore.add("&7Total spent: &f" + PurchaseLogger.totalSpentBy(targetUUID) + " coins");
            summaryLore.add("&7Total saved: &a" + PurchaseLogger.totalSavedBy(targetUUID) + " coins");
        }
        summaryLore.add("&7Page: &f" + (page + 1) + " / " + total);

        b.put(49, ItemBuilder.of(Material.PAPER).name("&6&lPurchase Summary").lore(summaryLore).build());

        if (page > 0)        b.put(45, ItemBuilder.of(Material.ARROW).name("&e\u00ab Previous").build());
        if (page < total-1)  b.put(53, ItemBuilder.of(Material.ARROW).name("&eNext \u00bb").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        List<PurchaseLog> logs = targetUUID == null ? PurchaseLogger.getGlobal() : PurchaseLogger.getForPlayer(targetUUID);
        int total = (int) Math.ceil(Math.max(1, logs.size()) / (double) PAGE_SIZE);
        if (slot == 4)  { p.closeInventory(); return; }
        if (slot == 45 && page > 0)       { page--; open(p); }
        if (slot == 53 && page < total-1) { page++; open(p); }
    }

    private ItemStack buildLogItem(PurchaseLog log) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Player:   &f" + log.getPlayerName());
        lore.add("&7Category: &f" + log.getCategory());
        lore.add("&7Date:     &e" + log.getFormattedDate());
        if (log.isGift())
            lore.add("&d\u25b8 Gifted to: &f" + log.getGiftRecipient());
        lore.add(" ");

        lore.add("&7Original: &f" + log.getOriginalPrice() + " coins");
        if (log.hadSale())
            lore.add("&6\u25b8 Sale: &c-" + log.getSaleDiscount() + " coins");
        if (log.hadCoupon())
            lore.add("&b\u25b8 Coupon &f[" + log.getCouponCode() + "&f]&b: &c-" + log.getCouponDiscount() + " coins");
        if (log.hadGiftFee())
            lore.add("&d\u25b8 Gift fee: &6+" + log.getGiftFee() + " coins");

        boolean hasChanges = log.hadSale() || log.hadCoupon() || log.hadGiftFee();
        if (hasChanges) {
            lore.add("&8\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            lore.add("&aActually paid: &f&l" + log.getFinalPaid() + " coins");
            if (log.getTotalSavings() > 0)
                lore.add("&7Savings: &a-" + log.getTotalSavings() + " coins");
        } else {
            lore.add("&7Paid: &f" + log.getFinalPaid() + " coins");
        }

        // Icon based on purchase type
        Material icon;
        if (log.isGift())                              icon = Material.EYE_OF_ENDER;
        else if (log.hadCoupon() && log.hadSale())     icon = Material.EMERALD;
        else if (log.hadCoupon())                      icon = Material.DIAMOND;
        else if (log.hadSale())                        icon = Material.GOLD_INGOT;
        else                                           icon = Material.PAPER;

        return ItemBuilder.of(icon).name("&f" + log.getItemName()).lore(lore).build();
    }
}
