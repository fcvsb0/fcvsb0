package dev.fcvsb.store.menu;

import dev.fcvsb.store.Lang;
import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.StoreItem;
import dev.fcvsb.store.sale.SaleManager;
import dev.fcvsb.store.coupon.Coupon;
import dev.fcvsb.store.coupon.CouponManager;
import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.shop.ShopProduct;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CartMenu extends Menu {

    private static final int[] ITEM_SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34
    };

    private static final int SLOT_BACK        = 45;
    private static final int SLOT_CLEAR       = 47;
    private static final int SLOT_SUMMARY     = 49;
    private static final int SLOT_BUY         = 51;
    private static final int SLOT_COUPON      = 53;
    private static final int SLOT_CANCEL_GIFT = 46; // only shown when gift target is set

    private final StoreCart               cart;
    private final Menu                    back;
    private final Map<Integer, StoreItem> slotMap = new LinkedHashMap<>();

    public CartMenu(StoreCart cart, Menu back) { this.cart = cart; this.back = back; }

    @Override
    public String title(Player p) {
        String base = "\u00a76\u00a7lShopping Cart";
        return cart.hasGiftTarget()
                ? base + " \u00a78| \u00a7aGift for \u00a7f" + cart.getGiftTargetName()
                : base;
    }

    @Override public int size(Player p) { return 54; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        slotMap.clear();
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 54);

        List<Map.Entry<StoreItem, Integer>> entries = new ArrayList<>(cart.getItems().entrySet());
        for (int i = 0; i < entries.size() && i < ITEM_SLOTS.length; i++) {
            StoreItem item = entries.get(i).getKey();
            int       qty  = entries.get(i).getValue();
            b.put(ITEM_SLOTS[i], buildSlot(p, item, qty));
            slotMap.put(ITEM_SLOTS[i], item);
        }

        b.put(SLOT_BACK,    Borders.backButton());
        b.put(SLOT_CLEAR,   ItemBuilder.of(Material.BARRIER)
                .name("&c&lClear Cart").lore("&cClick to clear everything").build());
        b.put(SLOT_SUMMARY, buildSummary(p));
        b.put(SLOT_BUY,     buildBuyButton(p));
        b.put(SLOT_COUPON,  buildCouponButton(p));

        if (cart.hasGiftTarget())
            b.put(SLOT_CANCEL_GIFT, ItemBuilder.of(Material.REDSTONE)
                    .name("&c&lCancel Gift")
                    .lore("&7Currently gifting to: &f" + cart.getGiftTargetName(),
                          " ",
                          "&cClick to cancel gift mode",
                          "&7(Cart will revert to self-purchase)").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot, boolean right) {
        if (slot == SLOT_BACK)  { back.open(p); return; }
        if (slot == SLOT_CLEAR) { cart.clear(); p.sendMessage(Lang.get("cart_cleared")); back.open(p); return; }
        if (slot == SLOT_CANCEL_GIFT && cart.hasGiftTarget()) {
            String was = cart.getGiftTargetName();
            cart.clearGiftTarget();
            p.sendMessage(ChatColor.YELLOW + "Gift for " + ChatColor.WHITE + was + ChatColor.YELLOW + " cancelled.");
            open(p); return;
        }
        if (slot == SLOT_COUPON) { handleCouponClick(p); return; }
        if (slot == SLOT_BUY) {
            if (cart.getSize() == 0) { p.sendMessage(ChatColor.RED + "Your cart is empty!"); return; }
            // Open the final confirmation screen instead of buying immediately
            new ConfirmMenu(cart, this).open(p);
            return;
        }

        StoreItem item = slotMap.get(slot);
        if (item == null) return;

        int qty = cart.getItems().getOrDefault(item, 0);
        if (right) {
            if (qty <= 1) { cart.removeItem(item); p.sendMessage(ChatColor.RED + ShopProduct.cleanDisplayName(item.getDisplayName()) + " removed."); }
            else { cart.getItems().put(item, qty - 1); p.sendMessage(ChatColor.YELLOW + ShopProduct.cleanDisplayName(item.getDisplayName()) + " \u00bb " + (qty-1) + "x"); }
        } else {
            if (item.isPurchasableOneTime() && qty >= 1) { p.sendMessage(ChatColor.RED + "You can only add this item once."); return; }
            int max = item.getPurchasableMaxStack();
            if (max > 0 && item.getPurchaseCount(p) + qty + 1 > max) { p.sendMessage(ChatColor.RED + "Purchase limit of " + max + " reached."); return; }
            cart.getItems().put(item, qty + 1);
            p.sendMessage(ChatColor.GREEN + ShopProduct.cleanDisplayName(item.getDisplayName()) + " \u00bb " + (qty+1) + "x");
        }
        if (cart.getSize() == 0) back.open(p); else refresh(p);
    }

    // ── Coupon ────────────────────────────────────────────────────────────

    private void handleCouponClick(Player p) {
        if (StoreConfig.isCouponBlockedDuringSale() && SaleManager.isActive()) {
            p.sendMessage("§cCoupons cannot be used while a sale is active.");
            return;
        }
        Coupon applied = CouponManager.getApplied(p.getUniqueId());
        if (applied != null) {
            CouponManager.clearApplied(p.getUniqueId());
            p.sendMessage(ChatColor.YELLOW + "Coupon " + ChatColor.WHITE + applied.getCode() + ChatColor.YELLOW + " removed.");
            open(p); return;
        }
        EditorSession.start(p, "Enter coupon code", this, input -> {
            Coupon c = CouponManager.get(input.trim());
            if (c == null)            p.sendMessage(ChatColor.RED + "Invalid coupon code: " + input.trim().toUpperCase());
            else if (!c.isValid())    p.sendMessage(ChatColor.RED + "That coupon has expired or reached its usage limit.");
            else if (c.hasUsed(p.getUniqueId())) p.sendMessage(ChatColor.RED + "You have already used this coupon.");
            else {
                CouponManager.apply(p.getUniqueId(), c);
                p.sendMessage(ChatColor.GREEN + "\u2714 Coupon " + ChatColor.WHITE + c.getCode() + ChatColor.GREEN + " applied! (" + c.getDiscountPct() + "% off)");
            }
            open(p);
        });
    }

    private ItemStack buildCouponButton(Player p) {
        if (StoreConfig.isCouponBlockedDuringSale() && SaleManager.isActive()) {
            CouponManager.clearApplied(p.getUniqueId());
            return ItemBuilder.of(Material.BARRIER)
                    .name("&c&lCoupons Disabled")
                    .lore("&7Coupons cannot be used",
                          "&7while a sale is active.").build();
        }
        Coupon applied = CouponManager.getApplied(p.getUniqueId());
        if (applied != null) {
            int savings = cart.getCouponSavings(p);
            return ItemBuilder.of(Material.NAME_TAG)
                    .name("&a&lCoupon Applied!")
                    .lore("&7Code: &f" + applied.getCode(),
                          "&7Discount: &a" + applied.getDiscountPct() + "% off",
                          "&7You save: &a" + savings + " coins",
                          " ",
                          "&eClick &7to remove coupon").build();
        }
        return ItemBuilder.of(Material.NAME_TAG)
                .name("&e&lApply Coupon")
                .lore("&7Have a coupon code?",
                      "&7Click to enter it here!",
                      " ",
                      "&8Discount is applied at checkout.").build();
    }

    // ── Summary & buy button ──────────────────────────────────────────────

    private ItemStack buildSummary(Player p) {
        int subtotal  = cart.getTotal(p);
        int savings   = cart.getCouponSavings(p);
        int afterCoup = cart.getTotalWithCoupon(p);
        int giftFee   = cart.getGiftFeeTotal(p);
        int total     = cart.getFinalTotal(p);
        int coins     = PlayerData.get(p.getUniqueId()).getCoins();
        Coupon coupon = CouponManager.getApplied(p.getUniqueId());

        List<String> lore = new ArrayList<>();
        lore.add("&7Items: &f" + cart.getSize());
        lore.add("&7Subtotal: &f" + subtotal + " coins");
        if (coupon != null)
            lore.add("&7Coupon &f(" + coupon.getCode() + "&f): &a-" + savings + " coins");
        if (cart.hasGiftTarget() && giftFee > 0) {
            lore.add("&d\u25b8 Gift fee: &6+" + giftFee + " coins");
            lore.add("&d\u25b8 Gifting to: &f" + cart.getGiftTargetName());
        }
        lore.add("&7Total: &f" + (giftFee > 0 || savings > 0 ? "&a" : "") + total + " coins");
        lore.add("&7Your coins: &f" + coins);
        lore.add(" ");
        lore.add(coins >= total ? "&a\u2714 Enough coins" : "&c\u2718 Missing &f" + (total - coins) + " &ccoins");

        return ItemBuilder.of(Material.PAPER).name("&6&lSummary").lore(lore).build();
    }

    private ItemStack buildBuyButton(Player p) {
        int total  = cart.getFinalTotal(p);
        int coins  = PlayerData.get(p.getUniqueId()).getCoins();
        boolean blocked = cart.getItems().entrySet().stream().anyMatch(e -> !e.getKey().canPurchase(p, e.getValue()));
        if (blocked)
            return ItemBuilder.of(Material.WOOL, (short)14).name("&c&l\u2718 Restrictions found").lore("&7Check items in red.").build();
        if (coins < total)
            return ItemBuilder.of(Material.WOOL, (short)14).name("&c&l\u2718 Not enough coins")
                    .lore("&7Total: &f"+total+" coins","&7You have: &f"+coins+" coins","&7Missing: &c"+(total-coins)).build();

        List<String> lore = new ArrayList<>();
        int giftFee = cart.getGiftFeeTotal(p);
        int savings = cart.getCouponSavings(p);
        if (savings > 0) lore.add("&7Savings: &a-" + savings + " coins");
        if (giftFee > 0) lore.add("&7Gift fee: &6+" + giftFee + " coins");
        lore.add("&7Total: &f" + total + " coins");
        lore.add("&7Remaining: &f" + (coins - total));
        if (cart.hasGiftTarget()) lore.add("&d\u25b8 Gifting to: &a" + cart.getGiftTargetName());
        lore.add(" ");
        lore.add("&eClick to buy!");

        return ItemBuilder.of(Material.WOOL, (short)5)
                .name(cart.hasGiftTarget() ? "&a&l\u2714 Send Gift" : "&a&l\u2714 Confirm Purchase")
                .lore(lore).build();
    }

    // ── Item slot ─────────────────────────────────────────────────────────

    private ItemStack buildSlot(Player p, StoreItem item, int qty) {
        boolean blocked = !item.canPurchase(p, qty);
        int unitNet = item.getPrice(p) - item.getDiscount(p);
        boolean canAdd = !item.isPurchasableOneTime() || qty == 0;

        List<String> lore = new ArrayList<>();
        lore.add("&7Quantity: &f" + qty);
        lore.add("&7Unit price: &f" + unitNet + " coins");
        lore.add("&7Subtotal: &f" + (unitNet * qty) + " coins");
        if (cart.hasGiftTarget() && item.isGiftable()) {
            int feePct = item.getGiftFeePercent() >= 0 ? item.getGiftFeePercent() : StoreConfig.getGlobalGiftFee();
            if (StoreConfig.isGiftFeeEnabled())
                lore.add("&d\u25b8 Gift fee: &6+" + feePct + "%");
        }

        if (blocked) { lore.add(" "); lore.add(item.getPurchaseBlockedReason(p, qty)); }
        lore.add(" ");
        lore.add(canAdd ? "&aLeft click \u2192 +1" : "&7Left click \u2192 limit reached");
        lore.add(qty > 1 ? "&eRight click \u2192 -1" : "&cRight click \u2192 remove");

        // Use the real item icon (material + data) cloned from getDisplayItem
        ItemStack base = item.getDisplayItem(p, null);
        Material mat  = (base != null && !blocked) ? base.getType() : (blocked ? Material.REDSTONE_BLOCK : Material.PAPER);
        short    data = (base != null && !blocked) ? base.getDurability() : 0;

        // Stack size shows quantity visually; badge in name when > 64
        int displayAmt = Math.min(qty, 64);
        // Use the original colored name from config; strikethrough red if blocked
        String displayName = blocked
                ? "&c&m" + ShopProduct.cleanDisplayName(item.getDisplayName())
                : item.getDisplayName(); // already color-translated
        if (qty > 64) displayName += " &8(&ex" + qty + "&8)";

        return ItemBuilder.of(mat, data)
                .name(displayName)
                .lore(lore)
                .amount(displayAmt)
                .build();
    }
}
