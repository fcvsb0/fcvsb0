package dev.fcvsb.store.shop;

import dev.fcvsb.store.StorePlugin;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Logger;

/**
 * Carga la tienda desde plugins/Store/shop/ con estructura de carpetas tipo Dracma:
 *
 *   shop/
 *     Crates/
 *       Crates-shop.yml          ← define la categoría + sus productos directos
 *     Gkits/
 *       Gkits-shop.yml           ← define la categoría (puede tener productos o no)
 *       categories/
 *         gkit-one-use.yml       ← subcategoría con sus propios productos
 *         lifetime-gkits.yml
 *     Tags/
 *       Tags-shop.yml
 *       categories/
 *         Exclusives.yml
 *         Symbols.yml
 *
 * También soporta el formato antiguo: YAMLs planos directamente en shop/
 */
public class ShopLoader {

    private static final Map<String, ShopCategory> CATEGORIES = new LinkedHashMap<>();
    private static File shopDir;

    // ── Init / Reload ─────────────────────────────────────────────────────

    public static void init(StorePlugin plugin) {
        shopDir = new File(plugin.getDataFolder(), "shop");
        if (!shopDir.exists()) shopDir.mkdirs();
        if (isEmpty(shopDir)) writeExamples(plugin.getLogger());
        reload();
    }

    public static void reload() {
        CATEGORIES.clear();
        if (shopDir == null || !shopDir.exists()) return;
        Logger log = StorePlugin.getInstance().getLogger();

        // 1. Carpetas = categorías (estilo Dracma)
        File[] dirs = shopDir.listFiles(File::isDirectory);
        if (dirs != null) {
            for (File dir : dirs) {
                try {
                    ShopCategory cat = loadFromFolder(dir, log);
                    if (cat != null) {
                        CATEGORIES.put(cat.getId(), cat);
                    }
                } catch (Exception e) {
                    log.warning("Error loading folder " + dir.getName() + ": " + e.getMessage());
                }
            }
        }

        // 2. YAMLs sueltos en la raíz de shop/ (formato legado)
        File[] rootYmls = shopDir.listFiles((d, n) -> n.endsWith(".yml"));
        if (rootYmls != null) {
            for (File file : rootYmls) {
                try {
                    ShopCategory cat = loadFromFile(file, log);
                    if (cat != null && !CATEGORIES.containsKey(cat.getId())) {
                        CATEGORIES.put(cat.getId(), cat);
                    }
                } catch (Exception e) {
                    log.warning("Error loading " + file.getName() + ": " + e.getMessage());
                }
            }
        }

    }

    // ── Public API ────────────────────────────────────────────────────────

    public static Map<String, ShopCategory> getCategories() {
        return Collections.unmodifiableMap(CATEGORIES);
    }

    public static ShopCategory getCategory(String id) {
        return CATEGORIES.get(id);
    }

    // ── Folder loader (estilo Dracma) ─────────────────────────────────────

    /**
     * Carga una categoría desde una carpeta.
     *
     * Busca el YAML principal de la categoría:
     *   - Primero: <FolderName>-shop.yml  (ej: Crates-shop.yml)
     *   - Si no: cualquier .yml en la raíz de la carpeta
     *
     * Luego carga subcategorías desde la subcarpeta "categories/" si existe.
     */
    private static ShopCategory loadFromFolder(File dir, Logger log) {
        String folderName = dir.getName();

        // Buscar el YAML principal
        File mainYml = new File(dir, folderName + "-shop.yml");
        if (!mainYml.exists()) {
            // Buscar cualquier yml en la carpeta (excepto los de categories/)
            File[] ymls = dir.listFiles((d, n) -> n.endsWith(".yml"));
            if (ymls == null || ymls.length == 0) {
                log.warning("Carpeta '" + folderName + "' sin YAML principal — ignorada.");
                return null;
            }
            mainYml = ymls[0];
        }

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(mainYml);
        String id = folderName.toLowerCase();

        // Leer sección del menú (soporta tanto "menu:" como "category:")
        int      slot    = getInt(yml, "menu.slot", "category.slot", 22);
        String   name    = getString(yml, "menu.icon.name", "category.name", "&f" + folderName);
        Material mat     = parseMat(getString(yml, "menu.icon.material", "category.material", "CHEST"), Material.CHEST);
        short    matData = (short) getInt(yml, "menu.icon.data", "category.material-data", 0);
        List<String> lore = getStringList(yml, "menu.icon.description", "category.lore");

        ShopCategory category = new ShopCategory(id, slot, name, mat, matData, lore);

        // Productos directos en el YAML principal (sección "products:")
        ConfigurationSection prodSec = yml.getConfigurationSection("products");
        if (prodSec != null) {
            for (String pid : prodSec.getKeys(false)) {
                ConfigurationSection ps = prodSec.getConfigurationSection(pid);
                if (ps == null) continue;
                ShopProduct p = parseProduct(ps, id + ":" + pid, id);
                if (p != null) category.addProduct(p);
            }
        }

        // Subcategorías inline en el YAML principal (sección "categories:")
        ConfigurationSection inlineCats = yml.getConfigurationSection("categories");
        if (inlineCats != null) {
            for (String subId : inlineCats.getKeys(false)) {
                ConfigurationSection sub = inlineCats.getConfigurationSection(subId);
                if (sub == null) continue;
                ShopSubCategory subCat = parseSubCategory(sub, subId, id);
                if (subCat != null) category.addSubCategory(subCat);
            }
        }

        // Subcategorías en carpeta "categories/" (estilo Dracma)
        File categoriesFolder = new File(dir, "categories");
        if (categoriesFolder.exists() && categoriesFolder.isDirectory()) {
            File[] subFiles = categoriesFolder.listFiles((d, n) -> n.endsWith(".yml"));
            if (subFiles != null) {
                for (File subFile : subFiles) {
                    try {
                        ShopSubCategory subCat = loadSubCategoryFromFile(subFile, id, log);
                        if (subCat != null) category.addSubCategory(subCat);
                    } catch (Exception e) {
                        log.warning("Error loading subcategory " + subFile.getName() + ": " + e.getMessage());
                    }
                }
            }
        }

        return category;
    }

    /**
     * Carga una subcategoría desde un archivo en categories/.
     * El YAML puede tener tanto formato Dracma (menu: + products:) como
     * formato propio (category: + products:).
     */
    private static ShopSubCategory loadSubCategoryFromFile(File file, String parentId, Logger log) {
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        String subId = file.getName().replace(".yml", "").toLowerCase();

        int      slot    = getInt(yml, "menu.slot", "category.slot", 13);
        String   name    = getString(yml, "menu.icon.name", "category.name", "&f" + subId);
        Material mat     = parseMat(getString(yml, "menu.icon.material", "category.material", "PAPER"), Material.PAPER);
        short    matData = (short) getInt(yml, "menu.icon.data", "category.material-data", 0);
        List<String> lore = getStringList(yml, "menu.icon.description", "category.lore");

        // Intentar leer el slot del icono en el menú padre desde "categories.<id>.slot" si existe
        // (Dracma define esto en el archivo principal, pero acá lo omitimos — usamos el slot del menu)
        ShopSubCategory subCat = new ShopSubCategory(subId, parentId, slot, name, mat, matData, lore);

        ConfigurationSection prodSec = yml.getConfigurationSection("products");
        if (prodSec != null) {
            for (String pid : prodSec.getKeys(false)) {
                ConfigurationSection ps = prodSec.getConfigurationSection(pid);
                if (ps == null) continue;
                ShopProduct p = parseProduct(ps, parentId + ":" + subId + ":" + pid, parentId);
                if (p != null) subCat.addProduct(p);
            }
        }

        return subCat;
    }

    // ── Legacy flat-file loader ───────────────────────────────────────────

    private static ShopCategory loadFromFile(File file, Logger log) {
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        String id = file.getName().replace(".yml", "").toLowerCase();

        // Soporte para ambos formatos de sección
        int      slot    = getInt(yml, "menu.slot", "category.slot", 22);
        String   name    = getString(yml, "menu.icon.name", "category.name", "&f" + id);
        Material mat     = parseMat(getString(yml, "menu.icon.material", "category.material", "CHEST"), Material.CHEST);
        short    matData = (short) getInt(yml, "menu.icon.data", "category.material-data", 0);
        List<String> lore = getStringList(yml, "menu.icon.description", "category.lore");

        ShopCategory category = new ShopCategory(id, slot, name, mat, matData, lore);

        ConfigurationSection prodSec = yml.getConfigurationSection("products");
        if (prodSec != null) {
            for (String pid : prodSec.getKeys(false)) {
                ConfigurationSection ps = prodSec.getConfigurationSection(pid);
                if (ps == null) continue;
                ShopProduct p = parseProduct(ps, id + ":" + pid, id);
                if (p != null) category.addProduct(p);
            }
        }

        ConfigurationSection subsSec = yml.getConfigurationSection("subcategories");
        if (subsSec != null) {
            for (String subId : subsSec.getKeys(false)) {
                ConfigurationSection sub = subsSec.getConfigurationSection(subId);
                if (sub == null) continue;
                ShopSubCategory subCat = parseSubCategory(sub, subId, id);
                if (subCat != null) category.addSubCategory(subCat);
            }
        }

        return category;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static ShopSubCategory parseSubCategory(ConfigurationSection sec, String subId, String parentId) {
        int          slot    = sec.getInt("slot", 13);
        String       name    = sec.getString("name", "&f" + subId);
        Material     mat     = parseMat(sec.getString("material", "PAPER"), Material.PAPER);
        short        matData = (short) sec.getInt("material-data", 0);
        List<String> lore    = sec.getStringList("lore");

        ShopSubCategory subCat = new ShopSubCategory(subId, parentId, slot, name, mat, matData, lore);

        ConfigurationSection prodSec = sec.getConfigurationSection("products");
        if (prodSec != null) {
            for (String pid : prodSec.getKeys(false)) {
                ConfigurationSection ps = prodSec.getConfigurationSection(pid);
                if (ps == null) continue;
                ShopProduct p = parseProduct(ps, parentId + ":" + subId + ":" + pid, parentId);
                if (p != null) subCat.addProduct(p);
            }
        }
        return subCat;
    }

    private static ShopProduct parseProduct(ConfigurationSection p, String fullId, String categoryId) {
        int          pSlot    = p.getInt("slot", 22);
        // Soporta item.name (Dracma) y name (legado)
        String       pName    = p.getString("item.name", p.getString("name", "&f"));
        Material     pMat     = parseMat(p.getString("item.material", p.getString("material", "PAPER")), Material.PAPER);
        short        pMatData = (short) p.getInt("item.data", p.getInt("material-data", 0));
        boolean      enchant  = p.getBoolean("item.enchanted", p.getBoolean("enchanted", false));
        // Lore: Dracma usa item.description.no-discount / discount; legado usa lore: list
        List<String> pLore    = resolveDescription(p);
        int          price    = resolvePrice(p);
        boolean      oneTime  = p.getBoolean("one-time", p.getBoolean("purchasable_one_time", false));
        int          maxStack = p.getInt("quantity", p.getInt("purchasable_no_stack", 0));
        List<String> cmds     = p.getStringList("commands");
        boolean      bc       = p.getBoolean("broadcast", true);
        String       bcMsg    = p.getString("broadcast-message", null);
        // Gift system
        boolean      giftable    = p.getBoolean("giftable", false);
        boolean      wishlistAdd     = p.getBoolean("wishlist-add", true);
        boolean      dailyDealElig   = p.getBoolean("daily-deals", true);
        // Subscription
        boolean      isSub     = p.getBoolean("subscription.enabled", false);
        long         subDurMs  = 0L;
        if (isSub) {
            String durStr = p.getString("subscription.duration", "30d");
            subDurMs = dev.fcvsb.store.sale.SaleManager.parseDuration(durStr);
        }
        List<String> subExpCmds = p.getStringList("subscription.expire-commands");
        int          giftFeeOver = p.contains("extra-price") ? p.getInt("extra-price", -1) : -1;
        // Cart limit: max qty per transaction (0 = unlimited)
        // quantity: N in YAML only applies when one-time is false
        int          cartLimit   = (!oneTime && p.contains("quantity")) ? p.getInt("quantity", 0) : 0;
        // Stock: server-wide units available (-1 = disabled)
        int          stock       = p.getInt("stock", -1);
        String       reqRank     = p.getString("required-rank", "");
        boolean      isRank      = p.getBoolean("rank.enabled", false);
        String       rankNext    = p.getString("rank.next", "");

        return new ShopProduct(fullId, categoryId, pSlot, pName,
                pMat, pMatData, enchant, pLore, price, oneTime, maxStack,
                cartLimit, stock,
                cmds, bc, bcMsg, giftable, giftFeeOver, wishlistAdd, dailyDealElig,
                isSub, subDurMs, subExpCmds, reqRank, isRank, rankNext);
    }

    /**
     * Dracma usa item.description.no-discount / item.description.discount
     * El formato legado usa item.description o lore como lista directa.
     */
    private static List<String> resolveDescription(ConfigurationSection p) {
        // Intenta item.description.no-discount (Dracma)
        ConfigurationSection desc = p.getConfigurationSection("item.description");
        if (desc != null) {
            List<String> noDiscount = desc.getStringList("no-discount");
            if (!noDiscount.isEmpty()) return noDiscount;
            // Si solo hay discount, usar ese
            List<String> discount = desc.getStringList("discount");
            if (!discount.isEmpty()) return discount;
        }
        // Intenta item.description como lista directa
        List<String> direct = p.getStringList("item.description");
        if (!direct.isEmpty()) return direct;
        // Legado
        return p.getStringList("lore");
    }

    /**
     * Dracma usa currency.price; legado usa price directamente.
     */
    private static int resolvePrice(ConfigurationSection p) {
        if (p.contains("currency.price")) return p.getInt("currency.price", 0);
        return p.getInt("price", 0);
    }

    // ── YAML helpers (soporte dos claves alternativas) ────────────────────

    private static int getInt(YamlConfiguration yml, String key1, String key2, int def) {
        if (yml.contains(key1)) return yml.getInt(key1, def);
        return yml.getInt(key2, def);
    }

    private static String getString(YamlConfiguration yml, String key1, String key2, String def) {
        if (yml.contains(key1)) return yml.getString(key1, def);
        return yml.getString(key2, def);
    }

    private static List<String> getStringList(YamlConfiguration yml, String key1, String key2) {
        if (yml.contains(key1)) return yml.getStringList(key1);
        return yml.getStringList(key2);
    }

    private static boolean isEmpty(File dir) {
        String[] list = dir.list();
        return list == null || list.length == 0;
    }

    private static Material parseMat(String name, Material fallback) {
        if (name == null) return fallback;
        try { return Material.valueOf(name.toUpperCase()); }
        catch (IllegalArgumentException e) { return fallback; }
    }

    // ── Ejemplos por defecto ──────────────────────────────────────────────

    private static void writeExamples(Logger log) {

        // ── Crates ────────────────────────────────────────────────────────
        writeFolder("Crates", "Crates-shop.yml",
            "menu:\n"
          + "  title: \"&5&lCrates\"\n"
          + "  rows: 3\n"
          + "  slot: 22\n"
          + "  icon:\n"
          + "    material: \"CHEST\"\n"
          + "    data: 0\n"
          + "    name: \"&5&lCrates\"\n"
          + "    description:\n"
          + "      - \"\"\n"
          + "      - \"&7Buy crate keys here.\"\n"
          + "      - \"\"\n"
          + "      - \"&dClick to view.\"\n"
          + "\n"
          + "products:\n"
          + "\n"
          + "  Santo:\n"
          + "    slot: 11\n"
          + "    item:\n"
          + "      name: \"&d&lSanto &7Crate\"\n"
          + "      description:\n"
          + "        no-discount:\n"
          + "          - \"&5Visit spawn to preview the crate!\"\n"
          + "          - \"\"\n"
          + "          - \"&dPrice&7: &c\u26c3 &f<currency-price> <currency-name>\"\n"
          + "          - \"\"\n"
          + "          - \"&5Click to add to cart\"\n"
          + "      material: TRIPWIRE_HOOK\n"
          + "      enchanted: true\n"
          + "    currency:\n"
          + "      name: coins\n"
          + "      price: 100\n"
          + "    one-time: false\n"
          + "    giftable: yes\n" +
          "    wishlist-add: true\n"
          + "    extra-price: 10\n"
          + "    quantity: 10\n"
          + "    stock: 100\n"
          + "    broadcast: true\n"
          + "    commands:\n"
          + "      - \"crate giveKey Santo <player> 1\"\n"
          + "\n"
          + "  Especial:\n"
          + "    slot: 13\n"
          + "    item:\n"
          + "      name: \"&e&lEspecial &7Crate\"\n"
          + "      description:\n"
          + "        no-discount:\n"
          + "          - \"&5Visit spawn to preview the crate!\"\n"
          + "          - \"\"\n"
          + "          - \"&dPrice&7: &c\u26c3 &f<currency-price> <currency-name>\"\n"
          + "          - \"\"\n"
          + "          - \"&5Click to add to cart\"\n"
          + "      material: TRIPWIRE_HOOK\n"
          + "      enchanted: true\n"
          + "    currency:\n"
          + "      name: coins\n"
          + "      price: 100\n"
          + "    one-time: false\n"
          + "    giftable: yes\n" +
          "    wishlist-add: true\n"
          + "    extra-price: 10\n"
          + "    quantity: 10\n"
          + "    stock: 100\n"
          + "    broadcast: true\n"
          + "    commands:\n"
          + "      - \"crate giveKey Especial <player> 1\"\n",
        log);

        // ── Gkits ─────────────────────────────────────────────────────────
        writeFolder("Gkits", "Gkits-shop.yml",
            "menu:\n"
          + "  title: \"&5&lGkits\"\n"
          + "  rows: 5\n"
          + "  slot: 20\n"
          + "  icon:\n"
          + "    material: \"DIAMOND_HELMET\"\n"
          + "    data: 0\n"
          + "    name: \"&5&lGkits\"\n"
          + "    description:\n"
          + "      - \"\"\n"
          + "      - \"&7Buy Gkits and boost your game.\"\n"
          + "      - \"\"\n"
          + "      - \"&dClick to view.\"\n"
          + "\n"
          + "products: {}\n",
        log);

        writeCategoryFile("Gkits", "categories", "gkit-one-use.yml",
            "menu:\n"
          + "  title: \"&5&lGkit One-Use\"\n"
          + "  rows: 5\n"
          + "  slot: 21\n"
          + "  icon:\n"
          + "    material: \"DIAMOND_HELMET\"\n"
          + "    data: 0\n"
          + "    name: \"&5&lGkits Only-Use\"\n"
          + "    description:\n"
          + "      - \"\"\n"
          + "      - \"&dClick to view all products\"\n"
          + "\n"
          + "products:\n"
          + "\n"
          + "  EjemploGkit:\n"
          + "    slot: 13\n"
          + "    item:\n"
          + "      name: \"&4&lEjemplo &7Kit\"\n"
          + "      description:\n"
          + "        no-discount:\n"
          + "          - \"&dYou can preview with &f/kit preview Ejemplo\"\n"
          + "          - \"&dThis kit is delivered as a &5voucher &done-time use.\"\n"
          + "          - \"\"\n"
          + "          - \"&dPrice&7: &c\u26c3 &f<currency-price> <currency-name>\"\n"
          + "          - \"\"\n"
          + "          - \"&5Click to add to cart\"\n"
          + "      material: DIAMOND_HELMET\n"
          + "      enchanted: false\n"
          + "    currency:\n"
          + "      name: coins\n"
          + "      price: 500\n"
          + "    one-time: true\n"
          + "    giftable: no\n" +
          "    wishlist-add: true\n"
          + "    stock: -1\n"
          + "    broadcast: true\n"
          + "    commands:\n"
          + "      - \"lp user <player> permission set gkit.ejemplo\"\n",
        log);

        // ── Tags ──────────────────────────────────────────────────────────
        writeFolder("Tags", "Tags-shop.yml",
            "menu:\n"
          + "  title: \"&5&lTags\"\n"
          + "  rows: 5\n"
          + "  slot: 24\n"
          + "  icon:\n"
          + "    material: \"NAME_TAG\"\n"
          + "    data: 0\n"
          + "    name: \"&5&lTags\"\n"
          + "    description:\n"
          + "      - \"\"\n"
          + "      - \"&7Buy exclusive tags.\"\n"
          + "      - \"\"\n"
          + "      - \"&dClick to view.\"\n"
          + "\n"
          + "products: {}\n",
        log);

        writeCategoryFile("Tags", "categories", "Exclusives.yml",
            "menu:\n"
          + "  title: \"&5&lExclusives\"\n"
          + "  rows: 3\n"
          + "  slot: 21\n"
          + "  icon:\n"
          + "    material: \"NAME_TAG\"\n"
          + "    data: 0\n"
          + "    name: \"&5&lExclusives\"\n"
          + "    description:\n"
          + "      - \"\"\n"
          + "      - \"&dClick to view all products\"\n"
          + "\n"
          + "products:\n"
          + "\n"
          + "  Dark:\n"
          + "    slot: 13\n"
          + "    item:\n"
          + "      name: \"&4&lDark &7Tag\"\n"
          + "      description:\n"
          + "        no-discount:\n"
          + "          - \"&5To preview this tag use &f/tags\"\n"
          + "          - \"\"\n"
          + "          - \"&dPrice&7: &c\u26c3 &f<currency-price> <currency-name>\"\n"
          + "          - \"\"\n"
          + "          - \"&5Click to add to cart\"\n"
          + "      material: NAME_TAG\n"
          + "      enchanted: true\n"
          + "    currency:\n"
          + "      name: coins\n"
          + "      price: 200\n"
          + "    one-time: true\n"
          + "    giftable: yes\n" +
          "    wishlist-add: true\n"
          + "    extra-price: 10\n"
          + "    quantity: 5\n"
          + "    stock: 50\n"
          + "    broadcast: true\n"
          + "    commands:\n"
          + "      - \"lp user <player> permission set deluxetags.tag.dark\"\n",
        log);
    }

    private static void writeFolder(String folder, String filename, String content, Logger log) {
        File dir = new File(shopDir, folder);
        if (!dir.exists()) dir.mkdirs();
        writeFile(new File(dir, filename), content, log);
    }

    private static void writeCategoryFile(String folder, String subFolder, String filename, String content, Logger log) {
        File dir = new File(new File(shopDir, folder), subFolder);
        if (!dir.exists()) dir.mkdirs();
        writeFile(new File(dir, filename), content, log);
    }

    private static void writeFile(File f, String content, Logger log) {
        if (f.exists()) return;
        try {
            java.nio.file.Files.write(f.toPath(), content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            log.warning("Could not write " + f.getName() + ": " + e.getMessage());
        }
    }
}
