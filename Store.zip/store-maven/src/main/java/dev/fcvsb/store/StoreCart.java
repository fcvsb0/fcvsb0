package dev.fcvsb.store;

import dev.fcvsb.store.coupon.CouponManager;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class StoreCart {

    private final Map<StoreItem, Integer> items          = new LinkedHashMap<>();
    private final Map<StoreItem, Integer> priceOverrides = new HashMap<>();

    // ── Gift target ───────────────────────────────────────────────────────
    private UUID   giftTargetUUID;
    private String giftTargetName;
    private String giftMessage;

    public void setGiftTarget(UUID uuid, String name) {
        this.giftTargetUUID = uuid;
        this.giftTargetName = name;
    }

    public void clearGiftTarget() {
        this.giftTargetUUID = null;
        this.giftTargetName = null;
        this.giftMessage    = null;
    }

    public boolean hasGiftTarget()      { return giftTargetUUID != null; }
    public UUID    getGiftTargetUUID()  { return giftTargetUUID; }
    public String  getGiftTargetName()  { return giftTargetName; }
    public String  getGiftMessage()     { return giftMessage; }
    public void    setGiftMessage(String m) { this.giftMessage = m; }

    // ── Items ─────────────────────────────────────────────────────────────
    public boolean contains(StoreItem item) { return items.containsKey(item); }

    public void addItem(StoreItem item, int amount) {
        items.merge(item, amount, Integer::sum);
    }

    public void addItemWithPrice(StoreItem item, int amount, int overridePrice) {
        items.merge(item, amount, Integer::sum);
        priceOverrides.put(item, overridePrice);
    }

    public void clearPriceOverride(StoreItem item) { priceOverrides.remove(item); }
    public boolean hasPriceOverride(StoreItem item) { return priceOverrides.containsKey(item); }
    public int getPriceOverride(StoreItem item) { return priceOverrides.getOrDefault(item, -1); }

    public void removeItem(StoreItem item) {
        items.remove(item);
    }

    public Map<StoreItem, Integer> getItems() { return items; }

    // ── Price calculations ────────────────────────────────────────────────

    /** Base total after sale discounts, before coupon and gift fee. */
    public int getTotal(Player player) {
        int total = 0;
        for (Map.Entry<StoreItem, Integer> e : items.entrySet()) {
            int basePrice = priceOverrides.containsKey(e.getKey())
                    ? priceOverrides.get(e.getKey())
                    : e.getKey().getPrice(player);
            int discount = priceOverrides.containsKey(e.getKey()) ? 0 : e.getKey().getDiscount(player);
            int net = basePrice - discount;
            total += net * e.getValue();
        }
        return total;
    }

    /** Coupon discount amount. */
    public int getCouponSavings(Player player) {
        int total = getTotal(player);
        return CouponManager.getCouponDiscount(player.getUniqueId(), total);
    }

    /** Total after coupon, before gift fee. */
    public int getTotalWithCoupon(Player player) {
        return Math.max(0, getTotal(player) - getCouponSavings(player));
    }

    /**
     * Extra gift fee charged on giftable items when a gift target is set.
     * Uses per-product override if set, otherwise global config value.
     */
    public int getGiftFeeTotal(Player player) {
        if (!hasGiftTarget()) return 0;
        if (!StoreConfig.isGiftFeeEnabled()) return 0;
        int fee = 0;
        int globalFee = StoreConfig.getGlobalGiftFee();
        for (Map.Entry<StoreItem, Integer> e : items.entrySet()) {
            if (!e.getKey().isGiftable()) continue;
            int basePrice2 = priceOverrides.containsKey(e.getKey())
                    ? priceOverrides.get(e.getKey())
                    : e.getKey().getPrice(player);
            int disc2 = priceOverrides.containsKey(e.getKey()) ? 0 : e.getKey().getDiscount(player);
            int baseNet  = (basePrice2 - disc2) * e.getValue();
            int feePct   = e.getKey().getGiftFeePercent() >= 0
                             ? e.getKey().getGiftFeePercent()
                             : globalFee;
            fee += (int) Math.ceil(baseNet * feePct / 100.0);
        }
        return fee;
    }

    /** Final total: after coupon discount + gift fee. */
    public int getFinalTotal(Player player) {
        return getTotalWithCoupon(player) + getGiftFeeTotal(player);
    }

    public int getSize() {
        return items.values().stream().mapToInt(Integer::intValue).sum();
    }

    public int getOverridePrice(StoreItem item) {
        return priceOverrides.getOrDefault(item, 0);
    }

    public void clear() {
        items.clear();
        priceOverrides.clear();
        clearGiftTarget();
    }

    // ── Cache ─────────────────────────────────────────────────────────────
    private static final Map<UUID, StoreCart> CACHE = new HashMap<>();

    public static StoreCart of(UUID uuid) {
        return CACHE.computeIfAbsent(uuid, id -> new StoreCart());
    }
}
