package dev.fcvsb.store;

import org.bukkit.Bukkit;

import java.util.ArrayDeque;
import java.util.Queue;

public class StoreBroadcastQueue implements Runnable {

    private static final Queue<String> QUEUE = new ArrayDeque<>();

    public static void queue(String msg) { QUEUE.add(msg); }

    @Override
    public void run() {
        String msg = QUEUE.poll();
        if (msg != null) Bukkit.broadcastMessage(msg);
    }
}
