package dev.fcvsb.store.command;

import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.subscription.ActiveSubscription;
import dev.fcvsb.store.subscription.SubscriptionManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class MySubsCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
        Player p = (Player) sender;

        if (!StoreConfig.isSubscriptionsEnabled()) {
            p.sendMessage(ChatColor.RED + "Memberships are currently disabled.");
            return true;
        }

        List<ActiveSubscription> subs = SubscriptionManager.getForPlayer(p.getUniqueId());

        p.sendMessage(ChatColor.GOLD + "━━━━ " + ChatColor.YELLOW + "My Memberships" + ChatColor.GOLD + " ━━━━");
        if (subs.isEmpty()) {
            p.sendMessage(ChatColor.GRAY + "  You have no active memberships.");
        } else {
            for (ActiveSubscription sub : subs) {
                p.sendMessage(ChatColor.GREEN + "  ✔ " + ChatColor.WHITE + sub.getProductName()
                        + ChatColor.GRAY + " — expires in " + ChatColor.YELLOW + sub.formatTimeLeft());
            }
        }
        p.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━━━━━━");
        return true;
    }
}
