package dev.fcvsb.store.sale;

/**
 * Parses durations like "1d2h30m10s" and manages active sales.
 */
public class SaleManager {

    private static long startTime  = 0;
    private static long duration   = 0;
    private static int  percentage = 0;

    public static void start(long durationMs, int pct) {
        startTime  = System.currentTimeMillis();
        duration   = durationMs;
        percentage = pct;
    }

    public static void cancel() {
        startTime = 0; duration = 0; percentage = 0;
    }

    public static boolean isActive() {
        return startTime > 0 && (System.currentTimeMillis() - startTime) < duration;
    }

    public static int getPercentage() { return isActive() ? percentage : 0; }

    public static long getRemainingMs() {
        if (!isActive()) return 0;
        return duration - (System.currentTimeMillis() - startTime);
    }

    public static int applyDiscount(int price) {
        if (!isActive()) return 0;
        return (int) (price * (percentage / 100.0));
    }

    public static String formatRemaining() {
        return formatDuration(getRemainingMs());
    }

    /** Parse "1d2h30m10s" style string. Returns milliseconds. -1 on error. */
    public static long parseDuration(String input) {
        long total = 0;
        StringBuilder num = new StringBuilder();
        for (char c : input.toLowerCase().toCharArray()) {
            if (Character.isDigit(c)) {
                num.append(c);
            } else {
                if (num.length() == 0) return -1;
                long n = Long.parseLong(num.toString());
                num.setLength(0);
                switch (c) {
                    case 'd': total += n * 86_400_000L; break;
                    case 'h': total += n * 3_600_000L;  break;
                    case 'm': total += n * 60_000L;     break;
                    case 's': total += n * 1_000L;      break;
                    default: return -1;
                }
            }
        }
        return total > 0 ? total : -1;
    }

    public static String formatDuration(long ms) {
        if (ms <= 0) return "0s";
        long s = ms / 1000, m = s / 60, h = m / 60, d = h / 24;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h % 24 > 0) sb.append(h % 24).append("h ");
        if (m % 60 > 0) sb.append(m % 60).append("m ");
        if (s % 60 > 0) sb.append(s % 60).append("s");
        return sb.toString().trim();
    }
}
