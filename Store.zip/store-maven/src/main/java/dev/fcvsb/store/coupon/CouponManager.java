package dev.fcvsb.store.coupon;

import java.util.*;

public class CouponManager {

    private static final Map<String, Coupon> COUPONS = new LinkedHashMap<>();
    private static final Random RNG = new Random();
    private static final String CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    // ── Active coupon per player (applied at cart checkout) ───────────────
    private static final Map<UUID, Coupon> APPLIED = new HashMap<>();

    // ── Create / Remove ───────────────────────────────────────────────────

    public static Coupon create(String code, int discountPct, long expireAt, int maxUses) {
        return create(code, discountPct, expireAt, maxUses, 0);
    }
    public static Coupon create(String code, int discountPct, long expireAt, int maxUses, int playerMaxUses) {
        Coupon c = new Coupon(code.toUpperCase(), discountPct, expireAt, maxUses, playerMaxUses);
        COUPONS.put(c.getCode(), c);
        return c;
    }

    /** Generate a random code if none is specified */
    public static String generateCode(int len) {
        String code;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < len; i++) sb.append(CHARS.charAt(RNG.nextInt(CHARS.length())));
            code = sb.toString();
        } while (COUPONS.containsKey(code));
        return code;
    }

    public static boolean remove(String code) { return COUPONS.remove(code.toUpperCase()) != null; }

    // ── Query ─────────────────────────────────────────────────────────────

    public static Coupon get(String code)           { return COUPONS.get(code.toUpperCase()); }
    public static Collection<Coupon> getAll()       { return COUPONS.values(); }
    public static List<Coupon> getActive() {
        List<Coupon> active = new ArrayList<>();
        for (Coupon c : COUPONS.values()) if (c.isValid()) active.add(c);
        return active;
    }

    // ── Apply per player ──────────────────────────────────────────────────

    public static void apply(UUID uuid, Coupon c)  { APPLIED.put(uuid, c); }
    public static void clearApplied(UUID uuid)     { APPLIED.remove(uuid); }
    public static Coupon getApplied(UUID uuid)     { return APPLIED.get(uuid); }

    /** Returns discount amount for a price, considering the player's applied coupon. */
    public static int getCouponDiscount(UUID uuid, int price) {
        Coupon c = APPLIED.get(uuid);
        if (c == null || !c.isValid()) return 0;
        return (int) (price * (c.getDiscountPct() / 100.0));
    }
}
