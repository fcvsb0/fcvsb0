package dev.fcvsb.store.shop;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

/**
 * Registro legado — la carga real la hace ShopLoader.
 * Se mantiene solo por compatibilidad con el editor de precios.
 */
public class ShopRegistry {

    private static final Map<String, ShopCategory> CATEGORIES = new LinkedHashMap<>();
    private static final Map<String, File>         FILE_MAP   = new LinkedHashMap<>();
    private static File   shopFolder;
    private static Logger log;

    public static void init(JavaPlugin plugin) {
        log        = plugin.getLogger();
        shopFolder = new File(plugin.getDataFolder(), "shop");
        if (!shopFolder.exists()) shopFolder.mkdirs();
    }

    public static void reload() { CATEGORIES.clear(); FILE_MAP.clear(); }

    public static List<ShopCategory> getAll() {
        List<ShopCategory> list = new ArrayList<>(CATEGORIES.values());
        list.sort((a, b) -> Integer.compare(a.getSlot(), b.getSlot()));
        return Collections.unmodifiableList(list);
    }

    public static ShopCategory get(String id) { return CATEGORIES.get(id); }

    /** Guarda el precio de un producto en su archivo YAML (llamado por el editor). */
    public static void saveProductPrice(String catId, String prodId, int price) {
        File file = FILE_MAP.get(catId);
        if (file == null) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        yml.set("products." + prodId + ".currency.price", price);
        try { yml.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    private static Material mat(String s, Material fallback) {
        try { return Material.valueOf(s.toUpperCase()); } catch (Exception e) { return fallback; }
    }
}
