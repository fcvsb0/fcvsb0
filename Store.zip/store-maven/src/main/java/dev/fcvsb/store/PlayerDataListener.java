package dev.fcvsb.store;

import dev.fcvsb.store.storage.DataStorage;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerKickEvent;

import java.util.UUID;

public class PlayerDataListener implements Listener {

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        PlayerData data = PlayerData.get(uuid);
        DataStorage.loadPlayer(uuid, data);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        DataStorage.savePlayer(uuid, PlayerData.get(uuid));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKick(PlayerKickEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        DataStorage.savePlayer(uuid, PlayerData.get(uuid));
    }
}
