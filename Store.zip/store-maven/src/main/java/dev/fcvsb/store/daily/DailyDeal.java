package dev.fcvsb.store.daily;

public class DailyDeal {

    private final String productId;
    private final int    originalPrice;
    private final int    dealPrice;
    private final int    discountPct;

    public DailyDeal(String productId, int originalPrice, int dealPrice, int discountPct) {
        this.productId     = productId;
        this.originalPrice = originalPrice;
        this.dealPrice     = dealPrice;
        this.discountPct   = discountPct;
    }

    public String getProductId()   { return productId; }
    public int    getOriginalPrice() { return originalPrice; }
    public int    getDealPrice()   { return dealPrice; }
    public int    getDiscountPct() { return discountPct; }
    public int    getSavings()     { return originalPrice - dealPrice; }
}
