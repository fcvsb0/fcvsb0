package dev.fcvsb.store.command;

import dev.fcvsb.store.PlayerData;
import dev.fcvsb.store.StoreCart;
import dev.fcvsb.store.StoreConfig;
import dev.fcvsb.store.menu.EditorMenu;
import dev.fcvsb.store.menu.SetStockMenu;
import dev.fcvsb.store.menu.StatsMenu;
import dev.fcvsb.store.menu.LogsMenu;
import dev.fcvsb.store.menu.StoreMenu;
import dev.fcvsb.store.shop.ShopLoader;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class StoreCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (args.length == 0) {
            if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
            Player p = (Player) sender;
            if (!StoreConfig.isEnabled() && !p.isOp()) {
                p.sendMessage(ChatColor.RED + "The store is currently disabled.");
                return true;
            }
            new StoreMenu(StoreCart.of(p.getUniqueId())).open(p);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "add": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                if (args.length < 3) { sender.sendMessage(ChatColor.RED + "Usage: /store add <player> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
                int v = parseInt(sender, args[2]); if (v < 0) return true;
                PlayerData.get(t.getUniqueId()).addCoins(v);
                sender.sendMessage(ChatColor.GREEN + "+" + v + " coins to " + t.getName());
                t.sendMessage(ChatColor.GREEN + "You received " + v + " coins!");
                break;
            }
            case "remove": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                if (args.length < 3) { sender.sendMessage(ChatColor.RED + "Usage: /store remove <player> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
                int v = parseInt(sender, args[2]); if (v < 0) return true;
                PlayerData d = PlayerData.get(t.getUniqueId());
                d.setCoins(Math.max(0, d.getCoins() - v));
                sender.sendMessage(ChatColor.GREEN + "Removed " + v + " coins from " + t.getName());
                break;
            }
            case "set": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                if (args.length < 3) { sender.sendMessage(ChatColor.RED + "Usage: /store set <player> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
                int v = parseInt(sender, args[2]); if (v < 0) return true;
                PlayerData.get(t.getUniqueId()).setCoins(v);
                sender.sendMessage(ChatColor.GREEN + "Coins of " + t.getName() + " set to " + v);
                break;
            }
            case "enable":
            case "disable": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                boolean on = args[0].equalsIgnoreCase("enable");
                StoreConfig.setEnabled(on);
                sender.sendMessage(ChatColor.GOLD + "Store " + (on ? ChatColor.GREEN + "enabled" : ChatColor.RED + "disabled"));
                break;
            }
            case "reload": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                StoreConfig.reload();
                ShopLoader.reload();
                sender.sendMessage(ChatColor.GREEN + "Config and shop reloaded. ("
                        + ShopLoader.getCategories().size() + " categories)");
                break;
            }
            case "editor": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
                new EditorMenu().open((Player) sender);
                break;
            }
            case "logs": {
                if (!sender.hasPermission("store.admin")) { noPerms(sender); return true; }
                if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
                Player p = (Player) sender;
                if (args.length < 2) { new LogsMenu().open(p); break; }
                Player online = Bukkit.getPlayerExact(args[1]);
                UUID uuid; String name;
                if (online != null) { uuid = online.getUniqueId(); name = online.getName(); }
                else {
                    @SuppressWarnings("deprecation") OfflinePlayer off = Bukkit.getOfflinePlayer(args[1]);
                    uuid = off.getUniqueId(); name = off.getName() != null ? off.getName() : args[1];
                }
                new LogsMenu(name, uuid).open(p);
                break;
            }
            case "stats": {
                if (!sender.isOp()) { noPerms(sender); return true; }
                if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
                new StatsMenu().open((Player) sender);
                break;
            }
            case "setstock": {
                if (!sender.isOp()) { noPerms(sender); return true; }
                if (!(sender instanceof Player)) { sender.sendMessage(ChatColor.RED + "Players only."); return true; }
                new SetStockMenu().open((Player) sender);
                break;
            }
            default:
                sender.sendMessage(ChatColor.YELLOW + "Usage: /store [add|remove|set|enable|disable|reload|editor|logs|stats|setstock]");
        }
        return true;
    }

    private void noPerms(CommandSender s) { s.sendMessage(ChatColor.RED + "You don't have permission."); }
    private int parseInt(CommandSender s, String str) {
        try {
            int v = Integer.parseInt(str);
            if (v < 0) { s.sendMessage(ChatColor.RED + "Must be positive."); return -1; }
            return v;
        } catch (NumberFormatException e) { s.sendMessage(ChatColor.RED + "Invalid number."); return -1; }
    }
}
