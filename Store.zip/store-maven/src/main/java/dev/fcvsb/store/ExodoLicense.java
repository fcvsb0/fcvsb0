package dev.fcvsb.store;

import org.bukkit.plugin.Plugin;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Enumeration;
import java.util.Scanner;

public class ExodoLicense {

    private final Plugin plugin;
    private final String licenseKey;
    private final String serverURL;
    private final String apiKey;

    private static final String OS = System.getProperty("os.name").toLowerCase();

    public ExodoLicense(Plugin plugin, String licenseKey, String serverURL, String apiKey) {
        this.plugin = plugin;
        this.licenseKey = licenseKey;
        this.serverURL = serverURL;
        this.apiKey = apiKey;
    }

    public boolean verify() {
        String[] result = isValid();
        char cc = org.bukkit.ChatColor.COLOR_CHAR;
        String SEP   = cc + "8--------------------------------------------";
        String TITLE = "         " + cc + "e*  " + cc + "6EXODO LICENSE SYSTEM  " + cc + "e*";

        org.bukkit.Bukkit.getConsoleSender().sendMessage(SEP);
        org.bukkit.Bukkit.getConsoleSender().sendMessage(TITLE);
        org.bukkit.Bukkit.getConsoleSender().sendMessage(SEP);
        org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Plugin:   " + cc + "f" + plugin.getName() + " v" + plugin.getDescription().getVersion());

        if (result[0].equals("2")) {
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Status:   " + cc + "a[OK] ACTIVE");
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Expires:  " + cc + "f" + (result.length > 2 ? result[2] : "Never"));
            org.bukkit.Bukkit.getConsoleSender().sendMessage(SEP);
            return true;
        } else if (result[0].equals("3")) {
            String latest = result[1].split("#")[1];
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Status:   " + cc + "a[OK] ACTIVE");
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Expires:  " + cc + "f" + (result.length > 2 ? result[2] : "Never"));
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Version:  " + cc + "eOutdated (latest: " + latest + ")");
            org.bukkit.Bukkit.getConsoleSender().sendMessage(SEP);
            return true;
        } else {
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Status:   " + cc + "c[X] INVALID LICENSE");
            org.bukkit.Bukkit.getConsoleSender().sendMessage(cc + "b>  " + cc + "3Reason:   " + cc + "c" + result[1]);
            org.bukkit.Bukkit.getConsoleSender().sendMessage(SEP);
            return false;
        }
    }

    private String[] isValid() {
        try {
            String response = sendRequest();

            if (response == null || !response.contains("{")) {
                return new String[]{"1", "NO_RESPONSE"};
            }

            String status  = extractJson(response, "status");
            String msg     = extractJson(response, "msg");
            String version = extractJson(response, "version");
            String neekeri = extractJson(response, "neekeri");
            String expires = extractJson(response, "expires");

            if (status == null) return new String[]{"1", msg != null ? msg : "UNKNOWN_ERROR"};

            if (status.equals("success")) {
                if (version != null && !version.equals(plugin.getDescription().getVersion())) {
                    return new String[]{"3", "OUTDATED_VERSION#" + version, expires != null ? expires : "Never"};
                }
                if (neekeri != null) {
                    String[] parts = neekeri.split("694201337");
                    if (parts.length >= 1) {
                        String decoded = new String(Base64.getDecoder().decode(parts[0]));
                        String expected = licenseKey.substring(0, 2) + licenseKey.substring(licenseKey.length() - 2) + apiKey.substring(0, 2);
                        if (!decoded.equals(expected)) {
                            return new String[]{"1", "FAILED_AUTHENTICATION"};
                        }
                    }
                }
                return new String[]{"2", "SUCCESS", expires != null ? expires : "Never"};
            } else {
                return new String[]{"1", msg != null ? msg : "INVALID_LICENSE"};
            }

        } catch (Exception e) {
            return new String[]{"1", "CONNECTION_ERROR: " + e.getMessage()};
        }
    }

    private String sendRequest() throws IOException {
        URL url = new URL(serverURL);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        con.setRequestProperty("Authorization", apiKey);
        con.setRequestProperty("User-Agent", "ExodoLicense");
        con.setDoOutput(true);
        con.setDoInput(true);
        con.setConnectTimeout(5000);
        con.setReadTimeout(5000);

        String body = "{\"hwid\":\"" + getHWID() + "\",\"license\":\"" + licenseKey + "\",\"plugin\":\"" + plugin.getName() + "\",\"version\":\"" + plugin.getDescription().getVersion() + "\"}";
        byte[] out = body.getBytes(StandardCharsets.UTF_8);
        con.setFixedLengthStreamingMode(out.length);
        con.connect();

        try (OutputStream os = con.getOutputStream()) {
            os.write(out);
        }

        try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private String extractJson(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start == -1) return null;
        start += search.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return null;
        return json.substring(start, end);
    }

    public static String getHWID() {
        try {
            if (OS.contains("win")) return getWindowsIdentifier();
            else if (OS.contains("mac")) return getMacOsIdentifier();
            else return getLinuxMacAddress();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static String getLinuxMacAddress() throws IOException, NoSuchAlgorithmException {
        File machineId = new File("/var/lib/dbus/machine-id");
        if (!machineId.exists()) machineId = new File("/etc/machine-id");
        if (!machineId.exists()) return getMacAddress();
        try (Scanner scanner = new Scanner(machineId)) {
            return hexStringify(sha256Hash(scanner.useDelimiter("\\A").next().getBytes()));
        }
    }

    private static String getMacOsIdentifier() throws SocketException, NoSuchAlgorithmException {
        NetworkInterface ni = NetworkInterface.getByName("en0");
        return hexStringify(sha256Hash(ni.getHardwareAddress()));
    }

    private static String getWindowsIdentifier() throws IOException, NoSuchAlgorithmException {
        Process process = Runtime.getRuntime().exec(new String[]{"wmic", "csproduct", "get", "UUID"});
        try (Scanner sc = new Scanner(process.getInputStream())) {
            while (sc.hasNext()) {
                String next = sc.next();
                if (next.contains("UUID")) return hexStringify(sha256Hash(sc.next().trim().getBytes()));
            }
        }
        return "unknown";
    }

    private static String getMacAddress() throws SocketException {
        Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
        while (nis.hasMoreElements()) {
            NetworkInterface ni = nis.nextElement();
            byte[] mac = ni.getHardwareAddress();
            if (mac != null) {
                StringBuilder sb = new StringBuilder();
                for (byte b : mac) sb.append(String.format("%02X", b));
                return sb.toString();
            }
        }
        return "unknown";
    }

    private static byte[] sha256Hash(byte[] data) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance("SHA-256").digest(data);
    }

    private static String hexStringify(byte[] data) {
        StringBuilder sb = new StringBuilder();
        for (byte b : data) sb.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
        return sb.toString();
    }
}
