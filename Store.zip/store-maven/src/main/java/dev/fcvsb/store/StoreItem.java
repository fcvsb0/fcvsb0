package dev.fcvsb.store;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface StoreItem {
    String    getId();
    String    getDisplayName();
    String    getCategory();
    ItemStack getDisplayItem(Player player, StoreCart cart);

    String  getRequiredRank();

    int       getPrice(Player player);
    int       getDiscount(Player player);
    boolean   playerOwns(Player player);
    void      grant(Player player);
    String    getBroadcastMessage(Player player, int amount);

    /** true → can only be purchased once per player (lifetime). */
    default boolean isPurchasableOneTime() { return false; }

    /**
     * Max total lifetime purchases per player (0 = unlimited).
     * Only used when one-time is false.
     */
    default int getPurchasableMaxStack() { return 0; }

    /**
     * Max quantity a player can add to their cart per transaction.
     * 0 = unlimited. Independent from lifetime purchase tracking.
     */
    default int getCartLimit() { return 0; }

    /**
     * Total server-wide stock remaining. -1 = stock system disabled.
     */
    default int getStock() { return -1; }

    /** How many times this player has purchased this item (lifetime). */
    default int getPurchaseCount(Player player) {
        return PlayerData.get(player.getUniqueId()).getPurchaseCount(getId());
    }

    /** Returns true if this item can be gifted to another player. */
    default boolean isGiftable() { return false; }

    /** Extra gift fee %. -1 = use global config. */
    default int getGiftFeePercent() { return -1; }

    /** Returns true if the player can purchase qty more units right now. */
    default boolean canPurchase(Player player, int qty) {
        String reqRank = getRequiredRank();
        if (reqRank != null && !reqRank.isEmpty())
            if (!dev.fcvsb.store.rank.RankManager.hasRank(player.getUniqueId(), reqRank)) return false;
        if (isPurchasableOneTime() && playerOwns(player)) return false;
        int max = getPurchasableMaxStack();
        if (max > 0) {
            int bought = getPurchaseCount(player);
            if (bought + qty > max) return false;
        }
        int stock = getStock();
        if (stock >= 0 && qty > stock) return false;
        return true;
    }

    /** Human-readable reason why purchase is blocked. */
    default String getPurchaseBlockedReason(Player player, int qty) {
        String reqRank = getRequiredRank();
        if (reqRank != null && !reqRank.isEmpty() &&
                !dev.fcvsb.store.rank.RankManager.hasRank(player.getUniqueId(), reqRank)) {
            dev.fcvsb.store.shop.ShopProduct r = dev.fcvsb.store.rank.RankManager.getById(reqRank);
            String display = r != null ? org.bukkit.ChatColor.translateAlternateColorCodes('&', r.getDisplayName()) : reqRank;
            return org.bukkit.ChatColor.RED + "✗ Requires rank " + display + org.bukkit.ChatColor.RED + " to purchase.";
        }
        if (isPurchasableOneTime() && playerOwns(player))
            return Lang.get("purchase_one_time");
        int max = getPurchasableMaxStack();
        if (max > 0) {
            int bought = getPurchaseCount(player);
            if (bought + qty > max)
                return Lang.get("purchase_limit", "%max%", max, "%bought%", bought);
        }
        int stock = getStock();
        if (stock == 0) return Lang.get("purchase_out_stock", "%item%", getDisplayName());
        if (stock > 0 && qty > stock)
            return Lang.get("purchase_no_stock", "%item%", getDisplayName(), "%stock%", stock);
        return null;
    }
}
