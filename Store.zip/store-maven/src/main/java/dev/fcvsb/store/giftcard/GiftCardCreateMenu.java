package dev.fcvsb.store.giftcard;

import dev.fcvsb.store.editor.EditorSession;
import dev.fcvsb.store.menu.Borders;
import dev.fcvsb.store.menu.Menu;
import dev.fcvsb.store.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GiftCardCreateMenu extends Menu {

    private final UUID   targetUUID;
    private final String targetName;

    private int    coins  = 0;
    private String reason = "";
    private String expiry = "never";

    public GiftCardCreateMenu(UUID targetUUID, String targetName) {
        this.targetUUID = targetUUID;
        this.targetName = targetName;
    }

    @Override public String title(Player p) { return "\u00a78[\u00a7aGiftCard\u00a78] \u00a7fCreate \u00a77\u00bb \u00a7f" + targetName; }
    @Override public int    size (Player p) { return 45; }

    @Override
    public Map<Integer, ItemStack> buttons(Player p) {
        Map<Integer, ItemStack> b = new HashMap<>();
        Borders.fill(b, 45);

        b.put(11, ItemBuilder.of(Material.GOLD_NUGGET)
                .name("&6&lCoins Amount")
                .lore("&7Current: &f" + (coins > 0 ? coins : "&cNot set"),
                      " ", "&eClick to set").build());

        b.put(13, ItemBuilder.of(Material.BOOK_AND_QUILL)
                .name("&b&lReason")
                .lore("&7Current: &f" + (reason.isEmpty() ? "&cNot set" : reason),
                      " ", "&eClick to set").build());

        b.put(15, ItemBuilder.of(Material.WATCH)
                .name("&e&lExpiry")
                .lore("&7Current: &f" + expiry,
                      " ", "&7Format: &f1d, 2h, 30m, never",
                      "&eClick to set").build());

        boolean ready = coins > 0 && !reason.isEmpty();
        b.put(31, ready
                ? ItemBuilder.of(Material.WOOL, (short) 5)
                        .name("&a&l\u2714 Create GiftCard")
                        .lore("&7Player: &f" + targetName,
                              "&7Coins:  &f" + coins,
                              "&7Reason: &f" + reason,
                              "&7Expiry: &f" + expiry,
                              " ", "&aClick to confirm").build()
                : ItemBuilder.of(Material.WOOL, (short) 14)
                        .name("&c&l\u2718 Cannot Create")
                        .lore("&7Set coins and reason first.").build());

        return b;
    }

    @Override
    public void onClick(Player p, int slot) {
        switch (slot) {
            case 11:
                EditorSession.start(p, "Enter coin amount (number)", this, input -> {
                    try {
                        int v = Integer.parseInt(input.trim());
                        if (v <= 0) { p.sendMessage("\u00a7cMust be positive."); open(p); return; }
                        coins = v; open(p);
                    } catch (NumberFormatException e) { p.sendMessage("\u00a7cInvalid number."); open(p); }
                }); break;

            case 13:
                EditorSession.start(p, "Enter reason for GiftCard", this, input -> {
                    reason = input; open(p);
                }); break;

            case 15:
                EditorSession.start(p, "Enter expiry (e.g. 1d, 2h30m, never)", this, input -> {
                    long exp = GiftCardManager.parseExpiry(input);
                    if (exp == -1) { p.sendMessage("\u00a7cInvalid format. Use: 1d, 2h, 30m, never"); open(p); return; }
                    expiry = input.toLowerCase(); open(p);
                }); break;

            case 31:
                if (coins <= 0 || reason.isEmpty()) return;
                long expireAt = GiftCardManager.parseExpiry(expiry);
                GiftCard gc = GiftCardManager.create(p.getUniqueId(), targetUUID, reason, coins, expireAt);
                dev.fcvsb.store.storage.DataStorage.saveGiftCards();
                p.sendMessage("\u00a7a\u2714 GiftCard created for \u00a7f" + targetName + "\u00a7a!");
                p.sendMessage("\u00a77ID: \u00a7f" + gc.getId() + " \u00a77| Coins: \u00a7f" + coins + " \u00a77| Expiry: \u00a7f" + expiry);
                p.closeInventory();
                break;
        }
    }
}
